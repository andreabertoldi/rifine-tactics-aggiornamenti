"""Attivazione: il programma funziona solo sul Mac per cui è stata creata la chiave.

Come funziona
- Ogni Mac ha un numero dell'hardware (IOPlatformUUID). Da quello il programma ricava il «codice di
  questo Mac», per esempio AV-7F3A-91C2-5B0E: è sempre lo stesso su quel Mac, anche reinstallando.
- Andrea, con il suo generatore (cartella «chiavi», che non va mai data a nessuno), firma quel codice con la sua
  chiave privata e ottiene la chiave di attivazione. Dentro il programma c'è solo la chiave PUBBLICA, che serve a
  controllare la firma ma non a crearne di nuove: copiando il programma non si possono fabbricare chiavi.
- La chiave vale solo per quel codice: su un altro Mac non funziona. Può avere una scadenza.

Il controllo si fa solo nell'applicazione costruita (Analisi Video.app): avviato da Python, come sul Mac di
Andrea, il programma non chiede niente.
"""
import base64
import datetime
import hashlib
import os
import subprocess
import sys

# chiave pubblica di Andrea (32 byte, esadecimale) — la privata sta solo nella sua cartella «chiavi»
PUBLIC_KEY = "493f0937951fb6e3f91cfe927227b9951421bb2ae808667d195d4217d5ca1cd7"
EPOCH = datetime.date(2026, 1, 1)        # le scadenze si contano in giorni da qui
SUPPORT = os.path.join(os.path.expanduser("~/Library/Application Support"), "AnalisiVideoCalcio")
LIC_FILE = os.path.join(SUPPORT, "attivazione.txt")


# ---------------------------------------------------------------------------------------------------------
# Ed25519 (RFC 8032), versione corta in Python puro: serve solo a controllare una firma all'avvio.
# ---------------------------------------------------------------------------------------------------------
_p = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _inv(x):
    return pow(x, _p - 2, _p)


def _xrecover(y):
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p:
        x = x * _I % _p
    if x % 2:
        x = _p - x
    return x


_By = 4 * _inv(5) % _p
_B = (_xrecover(_By), _By, 1, _xrecover(_By) * _By % _p)


def _add(P, Q):
    x1, y1, z1, t1 = P
    x2, y2, z2, t2 = Q
    A = (y1 - x1) * (y2 - x2) % _p
    B = (y1 + x1) * (y2 + x2) % _p
    C = t1 * 2 * _d * t2 % _p
    D = z1 * 2 * z2 % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _enc(P):
    x, y, z, _t = P
    zi = _inv(z)
    x, y = x * zi % _p, y * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _dec(s):
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _xrecover(y)
    if (x & 1) != sign:
        x = _p - x
    P = (x, y, 1, x * y % _p)
    if (-x * x + y * y - 1 - _d * x * x * y * y) % _p:
        raise ValueError("punto non valido")
    return P


def _h(m):
    return int.from_bytes(hashlib.sha512(m).digest(), "little")


def _eq(P, Q):
    x1, y1, z1, _ = P
    x2, y2, z2, _ = Q
    return (x1 * z2 - x2 * z1) % _p == 0 and (y1 * z2 - y2 * z1) % _p == 0


def verify(pub, msg, sig):
    try:
        if len(sig) != 64 or len(pub) != 32:
            return False
        R, A = _dec(sig[:32]), _dec(pub)
        S = int.from_bytes(sig[32:], "little")
        if S >= _L:
            return False
        k = _h(sig[:32] + pub + msg)
        return _eq(_mul(S, _B), _add(R, _mul(k, A)))
    except Exception:
        return False


def sign(seed, msg):
    """Usato solo dal generatore di Andrea (seed = 32 byte della chiave privata)."""
    h = hashlib.sha512(seed).digest()
    a = (int.from_bytes(h[:32], "little") & ((1 << 254) - 8)) | (1 << 254)
    pub = _enc(_mul(a, _B))
    r = _h(h[32:] + msg)
    R = _enc(_mul(r, _B))
    S = (r + _h(R + pub + msg) * a) % _L
    return R + int.to_bytes(S, 32, "little")


def public_from_seed(seed):
    h = hashlib.sha512(seed).digest()
    a = (int.from_bytes(h[:32], "little") & ((1 << 254) - 8)) | (1 << 254)
    return _enc(_mul(a, _B))


# ---------------------------------------------------------------------------------------------------------
# codice del Mac e chiavi
# ---------------------------------------------------------------------------------------------------------
def _hardware_id():
    try:
        out = subprocess.run(["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], capture_output=True,
                             text=True, timeout=10).stdout
        for line in out.splitlines():
            if "IOPlatformUUID" in line:
                return line.split("=")[-1].strip().strip('"')
    except Exception:
        pass
    try:   # non è un Mac (prove): un numero della macchina
        with open("/etc/machine-id") as f:
            return f.read().strip()
    except OSError:
        return ""


def machine_code(hw=None):
    """«AV-XXXX-XXXX-XXXX»: 12 caratteri ricavati dal numero dell'hardware (non lo rivela)."""
    hw = _hardware_id() if hw is None else hw
    d = hashlib.sha256(("AnalisiVideoCalcio|" + hw).encode()).digest()[:8]
    s = base64.b32encode(d).decode().rstrip("=")[:12]
    return "AV-" + "-".join(s[i:i + 4] for i in range(0, 12, 4))


def _norm_code(code):
    return "".join(ch for ch in code.upper() if ch.isalnum())


def _message(code, days):
    return b"AV1|" + _norm_code(code).encode() + b"|" + int(days).to_bytes(2, "big")


def make_key(seed, code, expires=None):
    """Chiave per il codice di un Mac. expires = datetime.date o None (senza scadenza)."""
    days = 0 if expires is None else max(1, (expires - EPOCH).days)
    sig = sign(seed, _message(code, days))
    raw = int(days).to_bytes(2, "big") + sig
    s = base64.b32encode(raw).decode().rstrip("=")
    return "-".join(s[i:i + 6] for i in range(0, len(s), 6))


def check_key(key, code=None):
    """Ritorna (True, scadenza o None) se la chiave vale per questo Mac, altrimenti (False, motivo)."""
    code = machine_code() if code is None else code
    try:
        s = "".join(ch for ch in key.upper() if ch.isalnum())
        s += "=" * (-len(s) % 8)
        raw = base64.b32decode(s)
    except Exception:
        return False, "La chiave non è scritta giusta: copiala di nuovo tutta, senza toccarla."
    if len(raw) != 66:
        return False, "La chiave non è completa: copiala di nuovo tutta."
    days = int.from_bytes(raw[:2], "big")
    if not verify(bytes.fromhex(PUBLIC_KEY), _message(code, days), raw[2:]):
        return False, ("Questa chiave non è per questo Mac.\n\nOgni chiave funziona su un solo Mac: chiedi la tua "
                       "mandando il codice di questo Mac.")
    exp = EPOCH + datetime.timedelta(days=days) if days else None
    if exp is not None and datetime.date.today() > exp:
        return False, f"La chiave è scaduta il {exp.strftime('%d/%m/%Y')}. Chiedine una nuova."
    return True, exp


def saved_key():
    try:
        with open(LIC_FILE, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def save_key(key):
    os.makedirs(SUPPORT, exist_ok=True)
    with open(LIC_FILE, "w", encoding="utf-8") as f:
        f.write(key.strip())


def needed():
    """Il controllo vale solo nell'applicazione costruita."""
    return bool(getattr(sys, "frozen", False)) or os.environ.get("ANALISI_LICENZA") == "1"


def ensure(app):
    """All'avvio: True se si può usare il programma (chiave valida già salvata o inserita adesso)."""
    if not needed():
        return True
    ok, info = check_key(saved_key()) if saved_key() else (False, "")
    if ok:
        return True
    from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                                   QPushButton, QTextEdit, QVBoxLayout)
    code = machine_code()
    dlg = QDialog()
    dlg.setWindowTitle("Attiva Rifine Tactics")
    dlg.resize(560, 360)
    v = QVBoxLayout(dlg)
    msg = ("<b style='font-size:16px'>Attiva Rifine Tactics</b><br><br>"
           "1. Manda ad Andrea il <b>codice di questo Mac</b> (qui sotto, con «Copia»).<br>"
           "2. Lui ti risponde con la <b>chiave di attivazione</b>: incollala nel riquadro e premi «Attiva».<br><br>"
           "<span style='color:#8a93a3'>La chiave funziona solo su questo Mac.</span>")
    if info:
        msg = f"<span style='color:#ff8a80'>{info}</span><br><br>" + msg
    lab = QLabel(msg)
    lab.setWordWrap(True)
    v.addWidget(lab)
    row = QHBoxLayout()
    cf = QLineEdit(code)
    cf.setReadOnly(True)
    f = cf.font()
    f.setPointSize(f.pointSize() + 4)
    f.setBold(True)
    cf.setFont(f)
    row.addWidget(cf, 1)
    b = QPushButton("Copia")
    b.clicked.connect(lambda: (QApplication.clipboard().setText(code), b.setText("Copiato ✓")))
    row.addWidget(b)
    v.addLayout(row)
    v.addWidget(QLabel("Chiave di attivazione:"))
    kf = QTextEdit()
    kf.setAcceptRichText(False)
    kf.setPlaceholderText("incolla qui la chiave che ti ha mandato Andrea")
    v.addWidget(kf, 1)
    row = QHBoxLayout()
    row.addStretch()
    q = QPushButton("Esci")
    q.clicked.connect(dlg.reject)
    row.addWidget(q)
    a = QPushButton("Attiva")
    a.setDefault(True)
    row.addWidget(a)
    v.addLayout(row)

    def activate():
        key = kf.toPlainText().strip()
        good, why = check_key(key, code)
        if not good:
            QMessageBox.warning(dlg, "Attivazione", why)
            return
        save_key(key)
        QMessageBox.information(dlg, "Attivazione", "Fatto, il programma è attivato su questo Mac." +
                                (f"\nLa chiave vale fino al {why.strftime('%d/%m/%Y')}." if why else ""))
        dlg.accept()
    a.clicked.connect(activate)
    return dlg.exec() == QDialog.Accepted
