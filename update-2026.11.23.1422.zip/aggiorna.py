"""Aggiornamenti senza rifare l'app: scarica il codice nuovo (firmato da Andrea), lo mette in
~/Library/Application Support/AnalisiVideoCalcio/aggiornamenti e al prossimo avvio il programma parte da lì.
Se un aggiornamento non parte, al riavvio successivo viene scartato da solo e si torna alla versione precedente.
Gli aggiornamenti cambiano solo il codice (non Python, PyTorch o i modelli: per quelli serve un nuovo .dmg).
"""
import hashlib
import io
import json
import os
import shutil
import urllib.request
import zipfile

import config
import licenza
import paths

DIR = os.path.join(paths.BASE, "aggiornamenti")
ACTIVE = os.path.join(DIR, "attiva.txt")
TRY = os.path.join(DIR, "tentativo.txt")


def _here():
    return os.path.dirname(os.path.abspath(__file__))


def current_version():
    try:
        with open(os.path.join(_here(), "versione.txt"), encoding="utf-8") as f:
            return f.read().strip() or "sviluppo"
    except OSError:
        return "sviluppo"


def current_note():
    """Cosa cambia nella versione che sta girando (scritto da Andrea quando ha preparato l'aggiornamento)."""
    try:
        with open(os.path.join(_here(), "note.txt"), encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def _vkey(v):
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def message(version, sha):
    return b"AVUPD1|" + version.encode() + b"|" + sha.encode()


def confirm_started():
    """Il programma è partito bene: l'aggiornamento resta."""
    try:
        os.remove(TRY)
    except OSError:
        pass


def check(timeout=8):
    """Ritorna le informazioni dell'aggiornamento nuovo, oppure None."""
    try:
        req = urllib.request.Request(config.UPDATE_URL, headers={"User-Agent": "RifineTactics"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            info = json.loads(r.read().decode("utf-8"))
    except Exception:
        return None
    try:
        if _vkey(info["version"]) > _vkey(current_version()):
            return info
    except (KeyError, TypeError):
        pass
    return None


def install(info, progress=None):
    """Scarica, controlla la firma e prepara l'aggiornamento. Ritorna (True, "") o (False, motivo)."""
    try:
        req = urllib.request.Request(info["url"], headers={"User-Agent": "RifineTactics"})
        with urllib.request.urlopen(req, timeout=60) as r:
            data = r.read()
    except Exception as e:
        return False, f"Non riesco a scaricare l'aggiornamento (serve internet): {e}"
    sha = hashlib.sha256(data).hexdigest()
    ok = sha == info.get("sha256") and licenza.verify(
        bytes.fromhex(licenza.PUBLIC_KEY), message(info["version"], sha), bytes.fromhex(info.get("firma", "00")))
    if not ok:
        return False, "L'aggiornamento non risulta firmato da Andrea: non lo installo."
    try:
        dest = os.path.join(DIR, info["version"])
        shutil.rmtree(dest, ignore_errors=True)
        os.makedirs(dest)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for n in z.namelist():
                if n.startswith("/") or ".." in n.split("/"):
                    return False, "Aggiornamento non valido."
            z.extractall(dest)
        with open(os.path.join(dest, "versione.txt"), "w", encoding="utf-8") as f:
            f.write(info["version"])
        with open(os.path.join(dest, "note.txt"), "w", encoding="utf-8") as f:
            f.write(str(info.get("note") or ""))
        with open(ACTIVE, "w", encoding="utf-8") as f:
            f.write(info["version"])
        confirm_started()
        # tengo solo l'aggiornamento attivo e uno precedente
        folders = sorted((d for d in os.listdir(DIR) if os.path.isdir(os.path.join(DIR, d))), key=_vkey)
        for d in folders[:-2]:
            shutil.rmtree(os.path.join(DIR, d), ignore_errors=True)
    except Exception as e:
        return False, f"Installazione non riuscita: {e}"
    return True, ""
