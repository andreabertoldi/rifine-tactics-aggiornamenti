"""Inseguimento «preciso» di un giocatore con SAM 2 (Meta, licenza Apache 2.0).

Invece di cercare le persone a ogni fotogramma, SAM 2 segue la SAGOMA del giocatore cliccato e se la
ricorda: nei contrasti sbaglia molto meno. Lavora su 5 fotogrammi al secondo, su un ritaglio che segue
la sagoma; le posizioni dei fotogrammi in mezzo vengono riempite a metà strada.

Serve PyTorch + il pacchetto sam2 + il file del modello: se mancano, il programma continua a usare
l'inseguimento normale.
"""
import os
import shutil
import tempfile
import threading

import cv2
import numpy as np
from PySide6.QtCore import QObject, Signal, Slot

from video import VideoReader

SUPPORT = os.path.join(os.path.expanduser("~/Library/Application Support"), "AnalisiVideoCalcio")
MODEL_NAME = "sam2.1_hiera_tiny.pt"
MODEL_URLS = ["https://dl.fbaipublicfiles.com/segment_anything_2/092824/sam2.1_hiera_tiny.pt",
              "https://github.com/ultralytics/assets/releases/download/v8.3.0/sam2.1_t.pt"]
CROP = 512          # lato del ritaglio attorno al giocatore (pixel del video)
RATE = 5.0          # fotogrammi al secondo su cui lavora SAM 2
LOST_AFTER = 1.2    # secondi senza sagoma dopo i quali si considera perso

_lock = threading.Lock()   # un solo calcolo SAM 2 alla volta
_pred = None


def model_path():
    import paths
    for p in (os.path.join(paths.models_dir(), MODEL_NAME), os.path.join(SUPPORT, MODEL_NAME)):
        if os.path.exists(p) and os.path.getsize(p) > 10_000_000:
            return p
    return None


def packages_ok():
    try:
        import importlib.util
        return all(importlib.util.find_spec(m) is not None for m in ("torch", "sam2"))
    except Exception:
        return False


def available():
    return packages_ok() and model_path() is not None


def install(progress, cancelled):
    """Installa PyTorch e SAM 2 nell'ambiente del programma e scarica il modello. Ritorna '' o l'errore."""
    import subprocess
    import sys
    import urllib.request
    if not packages_ok():
        if getattr(sys, "frozen", False):
            return "In questa versione del programma l'inseguimento preciso non è disponibile (Mac Intel)."
        progress(0.05, "Scarico e installo PyTorch e SAM 2 (qualche minuto)…")
        env = dict(os.environ, SAM2_BUILD_CUDA="0")
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "torch", "torchvision", "sam2"],
                           capture_output=True, env=env)
        if r.returncode != 0:
            return "Installazione non riuscita:\n" + r.stderr.decode("utf-8", "replace")[-800:]
    if model_path() is None:
        os.makedirs(SUPPORT, exist_ok=True)
        dst = os.path.join(SUPPORT, MODEL_NAME)
        err = ""
        for url in MODEL_URLS:
            try:
                progress(0.7, "Scarico il modello (circa 150 MB)…")
                with urllib.request.urlopen(url, timeout=60) as rsp, open(dst + ".tmp", "wb") as f:
                    tot = int(rsp.headers.get("Content-Length") or 0)
                    done = 0
                    while True:
                        if cancelled():
                            return "Annullato."
                        b = rsp.read(1 << 20)
                        if not b:
                            break
                        f.write(b)
                        done += len(b)
                        if tot:
                            progress(0.7 + 0.3 * done / tot, f"Scarico il modello… {done >> 20} di {tot >> 20} MB")
                os.replace(dst + ".tmp", dst)
                err = ""
                break
            except Exception as e:  # noqa
                err = f"Modello non scaricato: {e}"
        if err:
            return err
    import importlib
    importlib.invalidate_caches()
    progress(1.0, "Fatto")
    return "" if available() else "Qualcosa manca ancora dopo l'installazione."


def _predictor():
    global _pred
    if _pred is None:
        from sam2.build_sam import build_sam2_video_predictor
        _pred = build_sam2_video_predictor("configs/sam2.1/sam2.1_hiera_t.yaml", model_path(), device="cpu",
                                           hydra_overrides_extra=[f"++model.image_size={CROP}"])
    return _pred


class _Crops:
    """Fotogrammi ritagliati al momento: il centro del ritaglio è l'ultima posizione della sagoma (+ velocità)."""

    def __init__(self, rd, start, step, n, center):
        import torch
        self.rd, self.start, self.step, self.n = rd, start, step, n
        self.center = np.array(center, float)
        self.vel = np.zeros(2)
        self.off = {}
        self.cache = {}
        self.cs = int(min(CROP, rd.width, rd.height))
        self._mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
        self._std = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
        self._torch = torch

    def __len__(self):
        return self.n

    def __getitem__(self, i):
        if i not in self.cache:
            cs = self.cs
            c = self.center + (self.vel if i > 0 else 0)
            x0 = int(min(max(0, c[0] - cs / 2), self.rd.width - cs))
            y0 = int(min(max(0, c[1] - cs / 2), self.rd.height - cs))
            self.off[i] = (x0, y0)
            fr = self.rd.frame(self.start + i * self.step)
            im = cv2.cvtColor(np.ascontiguousarray(fr[y0:y0 + cs, x0:x0 + cs]), cv2.COLOR_BGR2RGB)
            if cs != CROP:
                im = cv2.resize(im, (CROP, CROP), interpolation=cv2.INTER_LINEAR)
            t = self._torch.from_numpy(im).permute(2, 0, 1).float() / 255.0
            self.cache = {i: (t - self._mean) / self._std}
        return self.cache[i]


class SamWorker(QObject):
    """Stessa interfaccia di FollowWorker: manda blocchi {fotogramma: [x_piedi, y_piedi, altezza, conf]}."""
    batch = Signal(str, object, bool, str)

    def __init__(self, vpath, tid, start, box, limit_frames, point=None):
        super().__init__()
        self.vpath, self.tid, self.start, self.box, self.limit, self.point = vpath, tid, start, box, limit_frames, point
        self._stop = False

    def stop(self):
        self._stop = True

    @Slot()
    def run(self):
        rd = None
        reason = "stop"
        tmp = None
        try:
            import torch
            rd = VideoReader(self.vpath)
            W, H = rd.width, rd.height
            end = min(rd.frame_count - 1, self.start + self.limit)
            step = max(1, int(round(rd.fps / RATE)))
            n = (end - self.start) // step + 1
            bx = self.box
            center = (self.point[0] * W, self.point[1] * H) if self.point else (bx[0] + bx[2] / 2, bx[1] + bx[3] / 2)
            crops = _Crops(rd, self.start, step, n, center)
            scale = crops.cs / float(CROP)
            tmp = tempfile.mkdtemp(prefix="sam2_")
            cv2.imwrite(os.path.join(tmp, "00000.jpg"), np.zeros((CROP, CROP, 3), np.uint8))
            with _lock, torch.inference_mode():
                if self._stop:
                    self.batch.emit(self.tid, {}, True, "stop")
                    return
                pred = _predictor()
                st = pred.init_state(video_path=tmp, offload_video_to_cpu=True, offload_state_to_cpu=True)
                st["images"] = crops
                st["num_frames"] = n
                st["cached_features"] = {}   # via le feature del fotogramma finto usato per l'avvio
                _ = crops[0]
                ox, oy = crops.off[0]
                b = np.array([(bx[0] - ox) / scale, (bx[1] - oy) / scale,
                              (bx[0] + bx[2] - ox) / scale, (bx[1] + bx[3] - oy) / scale], np.float32)
                # sempre il RIQUADRO dell'intero giocatore: un clic solo sulla pancia farebbe segmentare solo la maglia
                # (anello a metà corpo e troppo piccolo). Il clic serve solo a scegliere il giocatore giusto.
                pred.add_new_points_or_box(st, frame_idx=0, obj_id=1, box=b)
                prev_c = None
                last = None        # (indice fotogramma, valore)
                hs = float(bx[3])  # altezza lisciata (parte da quella del riquadro)
                miss = 0
                max_miss = max(2, int(round(LOST_AFTER * RATE)))
                reason = "end"
                for fi, _ids, logits in pred.propagate_in_video(st):
                    if self._stop:
                        reason = "stop"
                        break
                    m = (logits[0, 0] > 0).cpu().numpy()
                    ys, xs = np.nonzero(m)
                    idx = self.start + fi * step
                    if len(xs) < 20:
                        miss += 1
                        if miss >= max_miss:
                            reason = "lost"
                            break
                        continue
                    miss = 0
                    ox, oy = crops.off[fi]
                    y0, y1 = np.percentile(ys, 1), np.percentile(ys, 99)
                    h = max(8.0, (y1 - y0) * scale)
                    h = min(max(h, 0.8 * hs), 1.25 * hs)     # la sagoma a tratti perde pezzi: l'altezza cambia piano
                    hs = 0.6 * hs + 0.4 * h
                    cx, cy = xs.mean() * scale + ox, ys.mean() * scale + oy
                    v = [float(cx / W), float((y1 * scale + oy) / H), float(hs / H), 1.0]
                    c = np.array([cx, cy])
                    if prev_c is not None:
                        crops.vel = 0.5 * crops.vel + 0.5 * (c - prev_c)
                    prev_c = c
                    crops.center = c
                    out = {idx: v}
                    if last is not None and idx - last[0] <= 3 * step:
                        a = last[1]
                        for k in range(last[0] + 1, idx):
                            t = (k - last[0]) / (idx - last[0])
                            out[k] = [a[j] * (1 - t) + v[j] * t for j in range(3)] + [1.0]
                    last = (idx, v)
                    self.batch.emit(self.tid, out, False, "")
                pred.reset_state(st)
            self.batch.emit(self.tid, {}, True, reason)
        except Exception as e:  # noqa
            self.batch.emit(self.tid, {}, True, "errore: " + str(e))
        finally:
            if rd is not None:
                rd.close()
            if tmp:
                shutil.rmtree(tmp, ignore_errors=True)


def segment_box(rgb, box):
    """Sagoma di UNA persona in un'immagine (RGB), dato il suo riquadro [x0, y0, x1, y1]. Usa lo stesso SAM 2 che
    segue i giocatori (già provato su questo Mac), su un video di un solo fotogramma. Ritorna una maschera
    booleana grande come l'immagine, oppure None."""
    import torch
    h, w = rgb.shape[:2]
    side = max(h, w)
    sq = np.full((side, side, 3), 114, np.uint8)      # quadrato: l'immagine non si deforma
    sq[:h, :w] = rgb
    tmp = tempfile.mkdtemp(prefix="sam2i_")
    try:
        cv2.imwrite(os.path.join(tmp, "00000.jpg"), cv2.cvtColor(sq, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 95])
        m = None
        with _lock, torch.inference_mode():
            pred = _predictor()
            st = pred.init_state(video_path=tmp, offload_video_to_cpu=True, offload_state_to_cpu=True)
            pred.add_new_points_or_box(st, frame_idx=0, obj_id=1, box=np.array(box, np.float32))
            for _fi, _ids, logits in pred.propagate_in_video(st):
                m = (logits[0, 0] > 0).cpu().numpy()
                break
            pred.reset_state(st)
        if m is None:
            return None
        if m.shape != (side, side):
            m = cv2.resize(m.astype(np.uint8), (side, side), interpolation=cv2.INTER_NEAREST) > 0
        return m[:h, :w]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
