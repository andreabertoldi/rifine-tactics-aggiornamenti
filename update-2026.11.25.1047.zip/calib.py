"""Calibrazione del campo: abbina punti del video a punti noti del campo per avere metri e km/h."""
import math

import cv2
import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QImage, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QHBoxLayout, QLabel,
                               QMessageBox, QPushButton, QSizePolicy, QSplitter, QVBoxLayout, QWidget)

import calib_math as CM
from camera import apply
from dynamic import (PITCH_PRESETS, general_position, loo_error, pitch_landmarks, pitch_lines, ref_point,
                     solve_calibration)
import cvsafe

COLORS = ["#ff5252", "#40c4ff", "#ffeb3b", "#69f0ae", "#ff9100", "#e040fb", "#ffffff", "#00e5ff"]

# Calibrazione guidata: l'app chiede un segno alla volta (metà campo con la porta inquadrata).
# "lato A" = la parte del primo palo cliccato; basta essere coerenti, destra/sinistra non contano.
GUIDE = [
    ("il <b>primo palo</b> della porta, alla base (dove tocca terra) — questo è il «lato A»", "Palo sx alto"),
    ("l'<b>altro palo</b>, alla base (lato B)", "Palo sx basso"),
    ("<b>area piccola</b>: l'angolo sulla linea di fondo, lato A", "Area piccola sx fondo alto"),
    ("<b>area piccola</b>: l'angolo davanti, lato A", "Area piccola sx spigolo alto"),
    ("<b>area piccola</b>: l'angolo davanti, lato B", "Area piccola sx spigolo basso"),
    ("<b>area piccola</b>: l'angolo sulla linea di fondo, lato B", "Area piccola sx fondo basso"),
    ("<b>area di rigore</b>: l'angolo sulla linea di fondo, lato A", "Area sx fondo alto"),
    ("<b>area di rigore</b>: l'angolo davanti, lato A", "Area sx spigolo alto"),
    ("<b>area di rigore</b>: l'angolo davanti, lato B", "Area sx spigolo basso"),
    ("<b>area di rigore</b>: l'angolo sulla linea di fondo, lato B", "Area sx fondo basso"),
    ("il <b>dischetto del rigore</b>", "Rigore sx"),
    ("<b>lunetta</b> (l'arco fuori dall'area): dove tocca la linea dell'area, lato A", "Lunetta sx alto"),
    ("<b>lunetta</b>: dove tocca la linea dell'area, lato B", "Lunetta sx basso"),
    ("l'<b>angolo del campo</b> (bandierina) lato A", "Angolo alto sx"),
    ("l'<b>angolo del campo</b> (bandierina) lato B", "Angolo basso sx"),
    ("<b>metà campo</b>: dove la linea di metà campo incrocia la linea laterale, lato A", "Metà campo alto"),
    ("<b>cerchio di centrocampo</b>: dove incrocia la linea di metà campo, lato A", "Cerchio alto"),
    ("il <b>centro del campo</b>", "Centro"),
    ("<b>cerchio di centrocampo</b>: dove incrocia la linea di metà campo, lato B", "Cerchio basso"),
    ("<b>metà campo</b>: incrocio con la linea laterale, lato B", "Metà campo basso"),
    ("il <b>cerchio di centrocampo</b>: il punto più vicino a questa porta", "Cerchio sx"),
]


def on_grass(bgr, nx, ny):
    """Il punto (normalizzato) è sul campo? Attorno deve esserci erba: niente tribune, muri, cielo."""
    h, w = bgr.shape[:2]
    x, y = int(nx * w), int(ny * h)
    rad = max(8, int(0.012 * w))
    patch = bgr[max(0, y - rad):y + rad + 1, max(0, x - rad):x + rad + 1]
    if patch.size == 0:
        return False
    hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)
    green = (hsv[..., 0] >= 30) & (hsv[..., 0] <= 95) & (hsv[..., 1] > 40) & (hsv[..., 2] > 30)
    return float(green.mean()) > 0.2


def transfer_ok(bgr_a, bgr_b, M, pts_a):
    """La matrice M (fotogramma a -> b, coordinate normalizzate) porta davvero i punti calibrati in a
    sugli stessi segni in b? Controlli: i punti che cadono dentro b devono stare sull'erba, e l'immagine
    a spostata con M deve somigliare a b dove si sovrappongono."""
    q = apply(M, pts_a)
    inside = [(x, y) for x, y in q if 0 <= x <= 1 and 0 <= y <= 1]
    if any(not on_grass(bgr_b, x, y) for x, y in inside):
        return False
    h, w = bgr_b.shape[:2]
    s = 320 / w
    ga = cvsafe.resize(cv2.cvtColor(bgr_a, cv2.COLOR_BGR2GRAY), (320, int(h * s)))
    gb = cvsafe.resize(cv2.cvtColor(bgr_b, cv2.COLOR_BGR2GRAY), (320, int(h * s)))
    S = np.diag([ga.shape[1], ga.shape[0], 1.0])
    P = S @ M @ np.linalg.inv(S)
    warped = cv2.warpPerspective(ga, P, (gb.shape[1], gb.shape[0]))
    mask = cv2.warpPerspective(np.full_like(ga, 255), P, (gb.shape[1], gb.shape[0])) > 0
    if mask.mean() < 0.08:
        return len(inside) == 0  # quasi nessuna sovrapposizione: non verificabile
    err = float(np.mean(cv2.absdiff(warped, gb)[mask]))
    base = float(np.mean(cv2.absdiff(ga, gb)[mask]))
    return err < 8 or err < 0.55 * base


class FrameCanvas(QWidget):
    clicked = Signal(float, float)

    def __init__(self, frame_bgr):
        super().__init__()
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        self.img = QImage(rgb.data, w, h, w * 3, QImage.Format_RGB888).copy()
        self.bgr = frame_bgr.copy()
        self.src = (w, h)
        self.points = []  # [(x, y, n)]
        self.overlay = []  # linee del campo proiettate (normalizzate)
        self.mouse = None
        self.setMouseTracking(True)
        self.setCursor(Qt.CrossCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(560, 315)

    def rect_img(self):
        w, h = self.src
        s = min(self.width() / w, self.height() / h)
        return QRectF((self.width() - w * s) / 2, (self.height() - h * s) / 2, w * s, h * s)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#111317"))
        r = self.rect_img()
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.drawImage(r, self.img)
        p.setPen(QPen(QColor(0, 230, 255, 200), 2))
        for line in self.overlay:
            pts = [QPointF(r.x() + x * r.width(), r.y() + y * r.height()) for x, y in line]
            for a, b in zip(pts, pts[1:]):
                p.drawLine(a, b)
        f = QFont()
        f.setBold(True)
        f.setPointSize(11)
        p.setFont(f)
        for x, y, n in self.points:
            c = QPointF(r.x() + x * r.width(), r.y() + y * r.height())
            col = QColor(COLORS[(n - 1) % len(COLORS)])
            p.setPen(QPen(QColor("black"), 3))
            p.drawLine(c + QPointF(-9, 0), c + QPointF(9, 0))
            p.drawLine(c + QPointF(0, -9), c + QPointF(0, 9))
            p.setPen(QPen(col, 2))
            p.drawLine(c + QPointF(-9, 0), c + QPointF(9, 0))
            p.drawLine(c + QPointF(0, -9), c + QPointF(0, 9))
            p.drawText(c + QPointF(7, -7), str(n))
        # lente d'ingrandimento
        if self.mouse is not None and r.contains(self.mouse):
            m = self.mouse
            zoom = 4.0
            side = 150
            sx = (m.x() - r.x()) / r.width() * self.src[0]
            sy = (m.y() - r.y()) / r.height() * self.src[1]
            srcw = side / zoom * self.src[0] / r.width()
            src = QRectF(sx - srcw / 2, sy - srcw / 2, srcw, srcw)
            box = QRectF(self.width() - side - 10, 10, side, side)
            if box.contains(m):
                box = QRectF(10, 10, side, side)
            p.drawImage(box, self.img, src)
            p.setPen(QPen(QColor("white"), 2))
            p.drawRect(box)
            p.setPen(QPen(QColor("#ff5252"), 1))
            p.drawLine(box.center() + QPointF(-10, 0), box.center() + QPointF(10, 0))
            p.drawLine(box.center() + QPointF(0, -10), box.center() + QPointF(0, 10))

    def mouseMoveEvent(self, ev):
        self.mouse = ev.position()
        self.update()

    def leaveEvent(self, ev):
        self.mouse = None
        self.update()

    def on_grass(self, nx, ny):
        return on_grass(self.bgr, nx, ny)

    def mousePressEvent(self, ev):
        r = self.rect_img()
        pos = ev.position()
        if ev.button() == Qt.LeftButton and r.contains(pos):
            self.clicked.emit((pos.x() - r.x()) / r.width(), (pos.y() - r.y()) / r.height())


class PitchCanvas(QWidget):
    clicked = Signal(object)  # riferimento: ("name", nome) oppure ("rel", x/L, y/W)

    def __init__(self):
        super().__init__()
        self.spec = None
        self.points = []  # [(X, Y, n)]
        self.pending = False
        self.target = None  # (X, Y): il segno da cliccare adesso nel video (calibrazione guidata)
        self.setCursor(Qt.CrossCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(360, 240)

    def frect(self):
        L, W = self.spec["L"], self.spec["W"]
        m = 18
        aw, ah = self.width() - 2 * m, self.height() - 2 * m
        s = min(aw / L, ah / W)
        return QRectF((self.width() - L * s) / 2, (self.height() - W * s) / 2, L * s, W * s), s

    def to_w(self, X, Y):
        r, s = self.frect()
        return QPointF(r.x() + X * s, r.y() + Y * s)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#1a1d23"))
        r, s = self.frect()
        p.fillRect(r, QColor("#2e7d32"))
        p.setPen(QPen(QColor(255, 255, 255, 220), 1.5))
        for line in pitch_lines(self.spec):
            pts = [self.to_w(x, y) for x, y in line]
            for a, b in zip(pts, pts[1:]):
                p.drawLine(a, b)
        goals = self.spec.get("goals")
        if goals and (self.spec.get("goal_mode") or 0) > 0:
            # porte della partita (9c9) dentro il campo a 11
            gw = max(self.spec.get("gp", 6) or 6, 5)
            p.setPen(QPen(QColor("#ff9100"), 5))
            for x, y in goals:
                if y in (0, self.spec["W"]) or abs(y) < 1e-6 or abs(y - self.spec["W"]) < 1e-6:
                    p.drawLine(self.to_w(x - gw / 2, y), self.to_w(x + gw / 2, y))
                else:
                    p.drawLine(self.to_w(x, y - gw / 2), self.to_w(x, y + gw / 2))
        # punti notevoli cliccabili
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 230 if self.pending else 120))
        for name, (x, y) in pitch_landmarks(self.spec).items():
            p.drawEllipse(self.to_w(x, y), 3.5, 3.5)
        f = QFont()
        f.setBold(True)
        f.setPointSize(11)
        p.setFont(f)
        for X, Y, n in self.points:
            c = self.to_w(X, Y)
            p.setPen(QPen(QColor("black"), 1))
            p.setBrush(QColor(COLORS[(n - 1) % len(COLORS)]))
            p.drawEllipse(c, 7, 7)
            p.setPen(QColor("black"))
            p.drawText(QRectF(c.x() - 7, c.y() - 7, 14, 14), Qt.AlignCenter, str(n))
        if self.target is not None:
            c = self.to_w(*self.target)
            for rad, col, wd in ((16, QColor(0, 0, 0, 200), 6), (16, QColor("#ffeb3b"), 3)):
                p.setPen(QPen(col, wd))
                p.setBrush(Qt.NoBrush)
                p.drawEllipse(c, rad, rad)
            p.setPen(QColor("#ffeb3b"))
            p.drawText(QRectF(0, 0, self.width(), 18), Qt.AlignCenter, "Questo segno: cliccalo nel video")
        if self.pending:
            p.setPen(QColor("#ffeb3b"))
            p.drawText(QRectF(0, 0, self.width(), 18), Qt.AlignCenter, "Ora clicca lo stesso punto qui sul campo")

    def mousePressEvent(self, ev):
        if ev.button() != Qt.LeftButton:
            return
        r, s = self.frect()
        pos = ev.position()
        X, Y = (pos.x() - r.x()) / s, (pos.y() - r.y()) / s
        if not (-3 <= X <= self.spec["L"] + 3 and -3 <= Y <= self.spec["W"] + 3):
            return
        # aggancio al punto notevole più vicino
        best, bd = None, 1e9
        for name, (x, y) in pitch_landmarks(self.spec).items():
            d = math.hypot(x - X, y - Y)
            if d < bd:
                best, bd = name, d
        if best and bd * s < 16:
            self.clicked.emit(("name", best))
        else:
            self.clicked.emit(("rel", float(X / self.spec["L"]), float(Y / self.spec["W"])))


class CalibDialog(QDialog):
    def __init__(self, frame_bgr, spec=None, existing=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Calibra il campo")
        self.resize(1300, 720)
        self.pairs = []  # [(img(x,y), riferimento)]
        self.est = None  # (L, W, completo) stimati
        self.pending = None
        self.H = None
        self.err = None
        lay = QVBoxLayout(self)
        info = QLabel("Serve per misurare metri e km/h. <b>1)</b> Clicca un segno ben visibile del campo nel video "
                      "(spigolo dell'area, palo, dischetto, centro, incrocio di linee…) — usa la lente in alto. "
                      "<b>2)</b> Clicca lo stesso segno sullo schema a destra. Almeno <b>4 punti</b> non allineati. "
                      "Usa le <b>linee dipinte</b> (se il campo piccolo è fatto con i cinesini dentro un campo da 11, "
                      "scegli «11 contro 11» e clicca le sue linee). Lunghezza e larghezza le <b>calcola l'app</b> dai punti. Se conosci una misura vera del tuo campo "
                      "(es. larghezza dell'area misurata), scrivila sotto in <b>Misura nota</b>: tutti i metri si "
                      "basano su quella.")
        info.setWordWrap(True)
        self.info = info
        self.info_free = info.text()
        self.info_guided = ("Serve per misurare metri e km/h. <b>Calibrazione guidata:</b> l'app ti chiede <b>un segno "
                            "alla volta</b> (lo vedi evidenziato in giallo sullo schema a destra): <b>cliccalo nel "
                            "video</b>, aiutandoti con la lente. Se quel segno non si vede, premi <b>«Non si vede»</b>. "
                            "Clicca solo segni dipinti <b>a terra</b> (mai su muri, reti o tribune). Le linee azzurre "
                            "che compaiono devono cadere sulle linee vere del campo. Puoi anche <b>cliccare sullo schema</b> un "
                            "segno che vedi (puntino bianco) e poi cliccarlo nel video.")
        lay.addWidget(info)
        row0 = QHBoxLayout()
        row0.addWidget(QLabel("Come vuoi calibrare:"))
        self.mode = QComboBox()
        self.mode.addItems(["Guidata: l'app ti dice quale segno cliccare (consigliata)",
                            "Libera: scegli tu i punti, nel video e sullo schema"])
        row0.addWidget(self.mode)
        row0.addSpacing(24)
        row0.addWidget(QLabel("La porta che vedi nel video è, nello schema:"))
        self.side = QComboBox()
        self.side.addItems(["quella a sinistra", "quella a destra"])
        self.side.setToolTip("Scegli la porta dello schema che corrisponde a quella inquadrata: la guida ti chiederà "
                             "i segni di quella metà campo.")
        self.side.currentIndexChanged.connect(self.on_side)
        row0.addWidget(self.side)
        row0.addSpacing(24)
        row0.addWidget(QLabel("Porta della partita:"))
        self.goal_at = QComboBox()
        self.goal_at.addItems(["sulla linea di fondo delle linee che clicchi",
                               "sulla linea dell'area di rigore del campo a 11 (9c9 per lungo nel campo da 11)",
                               "9c9 di traverso nella metà SINISTRA dello schema (porte sulle laterali del campo a 11)",
                               "9c9 di traverso nella metà DESTRA dello schema (porte sulle laterali del campo a 11)"])
        self.goal_at.setToolTip("Serve per la «distanza dalla porta». Con un 9c9 giocato dentro un campo da 11 "
                                "calibra con le linee del campo da 11 («11 contro 11») e scegli dove stanno le porte "
                                "della partita: sulla linea dell'area di rigore (9c9 per lungo) oppure sulle linee "
                                "laterali, a metà di una metà campo (due partite 9c9 di traverso).")
        self.goal_at.currentIndexChanged.connect(self.on_goal_at)
        row0.addWidget(self.goal_at)
        row0.addStretch()
        lay.addLayout(row0)
        self.step = 0
        self.steps = []  # per ogni punto: passo della guida (None se messo in modo libero)
        row = QHBoxLayout()
        lbl = QLabel("Linee dipinte sul campo:")
        lbl.setToolTip("Scegli le linee DIPINTE che vedi nel video. Se la partita (9c9, 7c7…) è fatta con i cinesini "
                       "dentro un campo da 11, scegli «11 contro 11»: le sue linee sono precise.")
        row.addWidget(lbl)
        self.preset = QComboBox()
        for k in PITCH_PRESETS:
            self.preset.addItem(k)
        self.preset.addItem("Personalizzato")
        row.addWidget(self.preset)
        row.addWidget(QLabel("Lunghezza"))
        self.L = QDoubleSpinBox()
        self.L.setRange(20, 130)
        self.L.setSuffix(" m")
        row.addWidget(self.L)
        row.addWidget(QLabel("Larghezza"))
        self.W = QDoubleSpinBox()
        self.W.setRange(10, 100)
        self.W.setSuffix(" m")
        row.addWidget(self.W)
        self.auto = QCheckBox("Calcola lunghezza e larghezza dai punti")
        self.auto.setChecked(True)
        self.auto.setToolTip("Nei campi delle giovanili lunghezza e larghezza cambiano: l'app le ricava dai punti cliccati")
        self.auto.toggled.connect(lambda _v: self.refresh())
        row.addWidget(self.auto)
        self.snap = QCheckBox("Aggancia alle linee dipinte (più preciso)")
        self.snap.setChecked(True)
        self.snap.setToolTip("Dopo i tuoi clic l'app fa combaciare tutte le linee del campo che si vedono con le "
                             "linee bianche vere: corregge le piccole imprecisioni dei clic. Toglila solo se le "
                             "linee azzurre si agganciano a linee sbagliate (es. campo con tante linee diverse).")
        self.snap.toggled.connect(lambda _v: self.refresh())
        row.addWidget(self.snap)
        row.addStretch()
        lay.addLayout(row)
        # tutte le misure, per qualsiasi campo
        row2 = QHBoxLayout()
        row2.addWidget(QLabel("<span style='color:#8a93a3'>Misure (se il tuo campo è diverso, correggile):</span>"))
        self.dims = {}
        for key, label in (("pd", "area prof."), ("pw", "area largh."), ("gd", "area piccola prof."),
                           ("gw", "area piccola largh."), ("r", "raggio cerchio"), ("ps", "dischetto"),
                           ("gp", "porta")):
            row2.addWidget(QLabel(label))
            sp = QDoubleSpinBox()
            sp.setRange(0, 60)
            sp.setDecimals(2)
            sp.setSuffix(" m")
            sp.setMaximumWidth(92)
            self.dims[key] = sp
            row2.addWidget(sp)
        row2.addStretch()
        lay.addLayout(row2)
        # misura nota: la distanza vera tra due dei punti cliccati fissa la scala di tutto
        row3 = QHBoxLayout()
        row3.addWidget(QLabel("<b>Misura nota</b> (facoltativa, rende i metri esatti): tra il punto"))
        self.kn_a = QComboBox()
        self.kn_b = QComboBox()
        self.kn_d = QDoubleSpinBox()
        self.kn_d.setRange(0, 200)
        self.kn_d.setDecimals(2)
        self.kn_d.setSuffix(" m")
        self.kn_d.setSpecialValueText("—")
        row3.addWidget(self.kn_a)
        row3.addWidget(QLabel("e il punto"))
        row3.addWidget(self.kn_b)
        row3.addWidget(QLabel("ci sono"))
        row3.addWidget(self.kn_d)
        row3.addWidget(QLabel("<span style='color:#8a93a3'>(misurati con la rotella o su Google Maps)</span>"))
        row3.addStretch()
        lay.addLayout(row3)
        self.scale = 1.0
        sp = QSplitter(Qt.Horizontal)
        self.frame = FrameCanvas(frame_bgr)
        self.frame.clicked.connect(self.on_frame_click)
        self.pitch = PitchCanvas()
        self.pitch.clicked.connect(self.on_pitch_click)
        sp.addWidget(self.frame)
        sp.addWidget(self.pitch)
        sp.setSizes([860, 440])
        lay.addWidget(sp, 1)
        bot = QHBoxLayout()
        self.status = QLabel()
        bot.addWidget(self.status, 1)
        self.skip_btn = QPushButton("Non si vede →")
        self.skip_btn.setToolTip("Quel segno non è inquadrato o non si vede bene: passa al prossimo")
        self.skip_btn.clicked.connect(self.skip)
        bot.addWidget(self.skip_btn)
        b = QPushButton("Togli ultimo punto")
        b.clicked.connect(self.undo)
        bot.addWidget(b)
        b = QPushButton("Ricomincia")
        b.clicked.connect(self.reset)
        bot.addWidget(b)
        self.bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.bb.button(QDialogButtonBox.Ok).setText("Salva calibrazione")
        self.bb.button(QDialogButtonBox.Cancel).setText("Annulla")
        self.bb.accepted.connect(self.accept)
        self.bb.rejected.connect(self.reject)
        bot.addWidget(self.bb)
        lay.addLayout(bot)

        self.spec = dict(spec or PITCH_PRESETS["11 contro 11 (105×68)"])
        for k, v in PITCH_PRESETS["11 contro 11 (105×68)"].items():
            self.spec.setdefault(k, v)
        name = next((k for k, v in PITCH_PRESETS.items()
                     if all(abs(v[x] - self.spec.get(x, -1)) < 1e-6 for x in ("pd", "pw", "ps", "gp"))),
                    "Personalizzato")
        self.preset.setCurrentText(name)
        self.L.setValue(self.spec["L"])
        self.W.setValue(self.spec["W"])
        for k, sp in self.dims.items():
            sp.setValue(self.spec.get(k, 0))
            sp.valueChanged.connect(self.on_dims)
        self.preset.currentTextChanged.connect(self.on_preset)
        for w_ in (self.kn_a, self.kn_b):
            w_.currentIndexChanged.connect(lambda _i: self.refresh())
        self.kn_d.valueChanged.connect(lambda _v: self.refresh())
        self.L.valueChanged.connect(self.on_size)
        self.W.valueChanged.connect(self.on_size)
        self.mode.currentIndexChanged.connect(self.on_mode)
        if existing:
            if existing.get("refs"):
                self.pairs = [(tuple(a), tuple(r)) for a, r in zip(existing["img"], existing["refs"])]
            else:
                self.pairs = [(tuple(a), ("rel", b[0] / self.spec["L"], b[1] / self.spec["W"]))
                              for a, b in zip(existing["img"], existing["pitch_pts"])]
            kn = existing.get("known")
            if kn and kn[0] is not None and kn[1] is not None:
                self._sync_known()
                self.kn_a.setCurrentIndex(self.kn_a.findData(kn[0]))
                self.kn_b.setCurrentIndex(self.kn_b.findData(kn[1]))
                self.kn_d.setValue(kn[2])
            ep = existing.get("pitch") or {}
            if ep.get("goal_mode") is not None:
                self.goal_at.setCurrentIndex(int(ep["goal_mode"]))
            elif ep.get("goal_at"):
                self.goal_at.setCurrentIndex(1)
        self.steps = [None] * len(self.pairs)
        names = [r[1] for a, r in self.pairs if r[0] == "name"]
        if sum(" dx" in n for n in names) > sum(" sx" in n for n in names):
            self.side.blockSignals(True)
            self.side.setCurrentIndex(1)
            self.side.blockSignals(False)
        self.step = self._next_step(0)
        self.on_mode()

    # ---------- guida ----------
    def guided(self):
        return self.mode.currentIndex() == 0

    def gname(self, i):
        """Nome del segno del passo i, sulla porta che si vede (a sinistra o a destra nello schema)."""
        nm = GUIDE[i][1]
        return nm.replace(" sx", " dx") if self.side.currentIndex() == 1 else nm

    def on_side(self, *_):
        self.step = self._next_step(0)
        self.refresh()

    def _next_step(self, i):
        used = {r[1] for a, r in self.pairs if r[0] == "name"}
        lms = pitch_landmarks(self.spec)
        while i < len(GUIDE) and (self.gname(i) in used or self.gname(i) not in lms):
            i += 1
        return i

    def on_mode(self, *_):
        g = self.guided()
        self.info.setText(self.info_guided if g else self.info_free)
        self.skip_btn.setVisible(g)
        self.pending = None
        self.step = self._next_step(self.step if self.step < len(GUIDE) else 0)
        self.refresh()

    def on_goal_at(self, i):
        if i >= 1 and not self.preset.currentText().startswith("11"):
            # le linee dipinte sono quelle del campo a 11: misure giuste solo con quelle
            self.preset.setCurrentText("11 contro 11 (105×68)")
        self.refresh()

    def skip(self):
        if self.step < len(GUIDE):
            self.step = self._next_step(self.step + 1)
        self.refresh()

    def on_preset(self, name):
        if name in PITCH_PRESETS:
            self.spec = dict(PITCH_PRESETS[name])
            for w, v in [(self.L, self.spec["L"]), (self.W, self.spec["W"])] + \
                    [(sp, self.spec[k]) for k, sp in self.dims.items()]:
                w.blockSignals(True)
                w.setValue(v)
                w.blockSignals(False)
            self.refresh()

    def on_dims(self, *_):
        for k, sp in self.dims.items():
            self.spec[k] = sp.value()
        self.preset.blockSignals(True)
        self.preset.setCurrentText("Personalizzato")
        self.preset.blockSignals(False)
        self.refresh()

    def on_size(self):
        self.spec["L"], self.spec["W"] = self.L.value(), self.W.value()
        self.preset.blockSignals(True)
        self.preset.setCurrentText("Personalizzato")
        self.preset.blockSignals(False)
        self.refresh()

    def on_frame_click(self, x, y):
        if not self.frame.on_grass(x, y):
            self.status.setText("<span style='color:#ff7043'><b>Lì non c'è campo</b> (tribuna, muro, rete…): "
                                "clicca un segno dipinto <b>a terra</b>, sull'erba. Se il segno che ti chiedo non "
                                "si vede, premi «Non si vede →».</span>")
            return
        if self.guided():
            if self.step >= len(GUIDE):
                self.status.setText("<span style='color:#ffeb3b'>Punti guidati finiti. Per aggiungerne altri scegli "
                                    "«Libera» in alto.</span>")
                return
            self.pairs.append(((x, y), ("name", self.gname(self.step))))
            self.steps.append(self.step)
            self.step = self._next_step(self.step + 1)
            self.refresh()
            return
        self.pending = (x, y)
        self.refresh()

    def on_pitch_click(self, ref):
        if self.guided():
            if ref[0] == "name":
                nm = ref[1]
                if " dx" in nm and self.side.currentIndex() == 0:
                    self.side.blockSignals(True)
                    self.side.setCurrentIndex(1)
                    self.side.blockSignals(False)
                elif " sx" in nm and self.side.currentIndex() == 1:
                    self.side.blockSignals(True)
                    self.side.setCurrentIndex(0)
                    self.side.blockSignals(False)
                idx = next((i for i in range(len(GUIDE)) if self.gname(i) == nm), None)
                if idx is not None:
                    self.step = idx  # scelto sullo schema: ora va cliccato nel video
                    self.refresh()
                    return
            self.status.setText("<span style='color:#ffeb3b'>Sullo schema clicca uno dei puntini bianchi (un segno "
                                "che vedi nel video), poi cliccalo nel video.</span>")
            return
        if self.pending is None:
            self.status.setText("<span style='color:#ffeb3b'>Prima clicca il punto nel video, poi qui.</span>")
            return
        self.pairs.append((self.pending, tuple(ref)))
        self.steps.append(None)
        self.pending = None
        self.refresh()

    def undo(self):
        if self.pending is not None:
            self.pending = None
        elif self.pairs:
            self.pairs.pop()
            st = self.steps.pop() if self.steps else None
            if st is not None:
                self.step = st
        self.refresh()

    def reset(self):
        self.pairs = []
        self.steps = []
        self.pending = None
        self.step = self._next_step(0)
        self.refresh()

    def _precise(self):
        """Calibrazione precisa: modello di telecamera + affinamento sulle linee dipinte (calib_math)."""
        refs = [r for a, r in self.pairs]
        key = (tuple(tuple(a) for a, r in self.pairs), tuple(map(tuple, refs)),
               tuple(sorted((k, v) for k, v in self.spec.items() if isinstance(v, (int, float)))),
               self.auto.isChecked())
        if getattr(self, "_pcache", (None,))[0] == key:
            return self._pcache[1]
        out = (None, None, self.spec["L"], self.spec["W"], (False, False))
        self.line_px = self.m_per_px = None
        self.click_px = None
        try:
            from PySide6.QtWidgets import QApplication
            QApplication.setOverrideCursor(Qt.WaitCursor)
            if getattr(self, "dist_map", None) is None:
                self.dist_map, _ = CM.line_map(self.frame.bgr)
            size = self.frame.src
            img_px = np.asarray([a for a, r in self.pairs], float) * size
            spec = self.spec

            def ff(L, W):
                s2 = dict(spec, L=L, W=W)
                return [ref_point(r, s2) for r in refs]

            def lf(L, W):
                return pitch_lines(dict(spec, L=L, W=W))

            free = CM.free_dims(ff, (spec["L"], spec["W"])) if self.auto.isChecked() else (False, False)
            res = CM.calibrate(img_px, ff, lf, size, (spec["L"], spec["W"]), free=free, dist_map=self.dist_map,
                               size_from_lines=self.auto.isChecked())
            if res is not None:
                H = CM.h_img_to_field(res["P"], size)
                H = H / H[2, 2]
                pp = ff(res["L"], res["W"])
                proj = apply(H, [a for a, r in self.pairs])
                err = float(np.mean(np.linalg.norm(np.asarray(proj) - np.asarray(pp), axis=1)))
                known = (abs(res["L"] - spec["L"]) > 0.05, abs(res["W"] - spec["W"]) > 0.05)
                self.line_px, self.m_per_px = res.get("line_px"), res.get("m_per_px")
                q, _ = CM.project(res["P"], pp)
                self.click_px = [float(v) for v in np.linalg.norm(q - img_px, axis=1)]
                out = (H, err, res["L"], res["W"], known)
        except Exception:  # noqa: il ripiego resta il metodo semplice
            out = (None, None, self.spec["L"], self.spec["W"], (False, False))
        finally:
            from PySide6.QtWidgets import QApplication
            QApplication.restoreOverrideCursor()
        self._pcache = (key, out)
        return out

    def _spec_used(self):
        sp = dict(self.spec, L=self.est[0], W=self.est[1]) if self.est else dict(self.spec)
        gm = self.goal_at.currentIndex()
        sp["goal_mode"] = gm
        sp["goal_at"] = sp["pd"] if gm == 1 else 0.0
        if self.scale != 1.0:
            for k in ("L", "W", "pd", "pw", "gd", "gw", "r", "ps", "gp", "goal_at"):
                if k in sp:
                    sp[k] = sp[k] * self.scale
        L, W = sp["L"], sp["W"]
        if gm == 2:  # 9c9 di traverso nella metà sinistra: porte sulle due laterali, a metà della metà campo
            sp["goals"] = [[L / 4, 0.0], [L / 4, W]]
        elif gm == 3:
            sp["goals"] = [[3 * L / 4, 0.0], [3 * L / 4, W]]
        else:
            sp["goals"] = [[sp["goal_at"], W / 2], [L - sp["goal_at"], W / 2]]
        return sp

    def _sync_known(self):
        n = len(self.pairs)
        for cb in (self.kn_a, self.kn_b):
            cur = cb.currentData()
            cb.blockSignals(True)
            cb.clear()
            cb.addItem("—", None)
            for i in range(n):
                cb.addItem(str(i + 1), i)
            j = cb.findData(cur)
            cb.setCurrentIndex(j if j >= 0 else 0)
            cb.blockSignals(False)

    def refresh(self):
        n = len(self.pairs)
        self._sync_known()
        self.H, self.err, self.est = None, None, None
        self.frame.overlay = []
        self.badgeom = n >= 4 and not general_position([ref_point(r, self.spec) for a, r in self.pairs])
        if n >= 4 and not self.badgeom:
            H, err, L, W, known = self._precise() if self.snap.isChecked() else (None,) * 5
            if not self.snap.isChecked():
                self.line_px = self.m_per_px = self.click_px = None
            if H is None:  # ripiego: metodo semplice
                H, err, L, W, known = solve_calibration([a for a, r in self.pairs], [r for a, r in self.pairs],
                                                        self.spec, auto_size=self.auto.isChecked())
            if H is not None:
                self.H, self.err = H, err
                if self.auto.isChecked():
                    self.est = (L, W, known)
                # misura nota: corregge la scala di tutto il campo
                self.scale = 1.0
                ia, ib, dist = self.kn_a.currentData(), self.kn_b.currentData(), self.kn_d.value()
                if ia is not None and ib is not None and ia != ib and dist > 0 and ia < n and ib < n:
                    pa, pb = apply(H, [self.pairs[ia][0], self.pairs[ib][0]])
                    d0 = float(np.hypot(pa[0] - pb[0], pa[1] - pb[1]))
                    if d0 > 0.1:
                        self.scale = dist / d0
                        S = np.diag([self.scale, self.scale, 1.0])
                        self.H = S @ H
                        self.err = err * self.scale
        sp_used = self._spec_used()
        self.pitch.spec = sp_used
        self.frame.points = [(a[0], a[1], i + 1) for i, (a, r) in enumerate(self.pairs)
                             if -0.02 <= a[0] <= 1.02 and -0.02 <= a[1] <= 1.02]
        outside = sum(1 for a, r in self.pairs if not (-0.02 <= a[0] <= 1.02 and -0.02 <= a[1] <= 1.02))
        if self.pending is not None:
            self.frame.points.append((self.pending[0], self.pending[1], n + 1))
        self.pitch.points = [(*ref_point(r, sp_used), i + 1) for i, (a, r) in enumerate(self.pairs)]
        self.pitch.pending = self.pending is not None
        self.pitch.target = None
        if self.guided() and self.step < len(GUIDE):
            self.pitch.target = ref_point(("name", self.gname(self.step)), sp_used)
        if self.H is not None:
            from dynamic import _front_sign
            Hinv = _front_sign(self.H, np.linalg.inv(self.H))
            for line in pitch_lines(sp_used):
                dense = []
                for (x0, y0), (x1, y1) in zip(line, line[1:]):
                    for t in np.linspace(0, 1, 12):
                        dense.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
                q = apply(Hinv, dense)
                P = np.hstack([np.asarray(dense), np.ones((len(dense), 1))]) @ Hinv.T
                seg = []
                for (qx, qy), w in zip(q, P[:, 2]):
                    if w > 0 and -0.5 < qx < 1.5 and -0.5 < qy < 1.5:
                        seg.append((qx, qy))
                    else:
                        if len(seg) > 1:
                            self.frame.overlay.append(seg)
                        seg = []
                if len(seg) > 1:
                    self.frame.overlay.append(seg)
        self.loo = None
        if self.guided() and self.step < len(GUIDE):
            ask = (f"👉 <b>Punto {n + 1}</b> — clicca nel video {GUIDE[self.step][0]}. "
                   f"Se non si vede: «Non si vede →» (oppure clicca sullo schema un segno che vedi).<br>")
        elif self.guided():
            ask = "✓ Punti guidati finiti.<br>"
        else:
            ask = ""
        if self.pending is not None:
            msg = f"Punto {n + 1}: ora clicca lo stesso segno sullo schema del campo."
        elif n < 4 and self.guided():
            msg = f"Punti: {n} (ne servono almeno 4)."
        elif n < 4:
            msg = f"Punti: {n} di almeno 4. Clicca un segno del campo nel video."
        elif self.badgeom:
            msg = ("<span style='color:#ff7043'><b>Punti troppo allineati.</b></span> Servono almeno 4 punti di cui "
                   "<b>nessun gruppo di 3 sulla stessa linea</b> (es. non solo punti della linea di metà campo): "
                   "aggiungi punti in altre zone, come gli spigoli delle aree o un angolo.")
        elif self.H is None:
            msg = "I punti non bastano (forse allineati): aggiungine altri."
        else:
            pp = [ref_point(r, sp_used) for a, r in self.pairs]
            proj = apply(self.H, [a for a, r in self.pairs])
            errs = [float(np.hypot(px - b[0], py - b[1])) for (px, py), b in zip(proj, pp)]
            worst = int(np.argmax(errs))
            precise = getattr(self, "line_px", None) is not None and self.m_per_px and self.click_px
            if precise:
                # precisione dalla calibrazione precisa: quanto combaciano linee dipinte e clic
                med_click = float(np.median(self.click_px))
                loo = self.m_per_px * max(self.line_px * 1.5, med_click / 2.0, 1.0)
                worst_px = int(np.argmax(self.click_px))
            else:
                loo = loo_error([a for a, r in self.pairs], pp)
            self.loo = loo
            if precise:
                lines_ok = self.line_px < 2.0
                msg = ("✓ <b>Linee del campo agganciate</b> alle linee dipinte" if lines_ok else
                       "<span style='color:#ffb74d'><b>Le linee del campo combaciano solo in parte</b></span>") + \
                    f" (scarto medio {self.line_px:.1f} px). "
                if loo < 0.5 and lines_ok:
                    msg += f"Calibrazione ottima: <b>precisione stimata ±{loo:.1f} m</b>."
                elif loo < 1.0:
                    msg += f"Calibrazione buona: <b>precisione stimata ±{loo:.1f} m</b>."
                else:
                    msg += (f"<span style='color:#ff7043'><b>Calibrazione NON affidabile (±{loo:.1f} m).</b></span> "
                            f"Guarda le linee azzurre e rifai i punti che non tornano.")
                if self.click_px[worst_px] > 14:
                    msg += (f" <b>Il punto {worst_px + 1}</b> non combacia con le linee dipinte "
                            f"({self.click_px[worst_px]:.0f} px): forse è sul segno sbagliato, toglilo o rifallo.")
            elif loo is None:
                msg = (f"Calibrazione fatta con il minimo di punti: non posso stimarne la precisione. "
                       f"<b>Aggiungi almeno un altro punto</b> per controllarla.")
            else:
                if loo < 0.5:
                    msg = f"Calibrazione ottima: <b>precisione stimata ±{loo:.1f} m</b>."
                elif loo < 1.0:
                    msg = f"Calibrazione buona: <b>precisione stimata ±{loo:.1f} m</b>."
                else:
                    msg = (f"<span style='color:#ff7043'><b>Calibrazione NON affidabile (±{loo:.1f} m): km/h e "
                           f"distanze verrebbero sbagliati.</b></span> Di solito un punto è stato messo sul segno "
                           f"sbagliato: guarda le linee azzurre e rifai i punti che non tornano.")
            if not precise and errs[worst] > max(1.0, 3 * self.err):
                msg += f" Il punto {worst + 1} sembra sbagliato ({errs[worst]:.1f} m): toglilo o rifallo."
            if precise and self.est:
                L, W, (l_ok, w_ok) = self.est
                if l_ok or w_ok:
                    msg += (f" <b>Misure del campo ricavate dalle linee: {L:.1f} × {W:.1f} m</b> (se conosci "
                            f"quelle vere, scrivile e togli la spunta «Calcola…»).")
                else:
                    msg += f" Le misure impostate ({L:.0f} × {W:.0f} m) combaciano con le linee."
            elif self.est:
                L, W, (l_ok, w_ok) = self.est
                if l_ok and w_ok:
                    msg += f" <b>Campo calcolato: {L:.1f} × {W:.1f} m</b>."
                elif l_ok:
                    msg += (f" <b>Lunghezza calcolata: {L:.1f} m</b> (la larghezza non serve per le misure; "
                            f"per calcolarla clicca anche un punto sulla linea laterale).")
                else:
                    msg += (f" Lunghezza del campo non ricavabile (punti tutti nella stessa zona): uso {L:.0f} m. "
                            f"Le misure vicino a questi punti sono comunque giuste; per tutto il campo aggiungi "
                            f"un punto a centrocampo o nell'altra metà.")
            if self.scale != 1.0:
                spu = self._spec_used()
                msg += (f" <b>Misura nota applicata</b>: scala corretta del {(self.scale - 1) * 100:+.1f}% "
                        f"→ campo {spu['L']:.1f} × {spu['W']:.1f} m.")
            if outside:
                msg += f" ({outside} punt{'o' if outside == 1 else 'i'} dell'altra inquadratura, fuori schermo: valgono lo stesso.)"
            msg += " Controlla che le linee azzurre stiano sulle linee del campo."
        self.status.setText(ask + msg)
        self.status.setWordWrap(True)
        self.bb.button(QDialogButtonBox.Ok).setEnabled(self.H is not None)
        self.frame.update()
        self.pitch.update()

    def accept(self):
        if self.loo is not None and self.loo >= 1.0:
            r = QMessageBox.question(
                self, "Calibrazione imprecisa",
                f"La calibrazione ha un errore stimato di ±{self.loo:.1f} m: velocità e distanze verrebbero "
                f"sbagliate.\n\nVuoi salvarla lo stesso?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if r != QMessageBox.Yes:
                return
        super().accept()

    def result(self, idx):
        sp = self._spec_used()
        sp.pop("range", None)
        return {"idx": int(idx), "H": [float(x) for x in self.H.flatten()],
                "img": [list(a) for a, r in self.pairs], "refs": [list(r) for a, r in self.pairs],
                "pitch_pts": [list(ref_point(r, sp)) for a, r in self.pairs],
                "pitch": sp, "err": round(float(self.err), 3),
                "known": [self.kn_a.currentData(), self.kn_b.currentData(), self.kn_d.value()]}
