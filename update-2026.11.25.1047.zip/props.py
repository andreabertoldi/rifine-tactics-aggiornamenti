"""Pannello «Proprietà»: le opzioni del disegno selezionato, tutte in un posto.

Ogni opzione è un interruttore indipendente e cambia subito il disegno sul video. Compaiono solo le
opzioni che hanno senso per quel disegno (per esempio scia e velocità solo per un giocatore seguito).
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QHBoxLayout, QLabel,
                               QLineEdit, QPushButton, QScrollArea, QSlider, QVBoxLayout, QWidget)

from model import DRAWING_KINDS, fmt_time

GREY = "color:#8a93a3"


def _tracked(d):
    return any(a and a.get("type") == "track" for a in (d.get("anchors") or []))


class PropsPanel(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        self._d = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.title = QLabel()
        self.title.setWordWrap(True)
        lay.addWidget(self.title)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        lay.addWidget(self.scroll, 1)
        self.help = QLabel()
        self.help.setWordWrap(True)
        self.help.setStyleSheet(GREY)
        lay.addWidget(self.help)
        self.set_drawing(None, force=True)

    # ---------- costruzione ----------
    def set_drawing(self, d, force=False):
        if d is self._d and not force:
            return
        self._d = d
        body = QWidget()
        self.form = QFormLayout(body)
        self.form.setContentsMargins(4, 4, 4, 4)
        self.form.setVerticalSpacing(5)
        if d is None:
            self.title.setText("<b>Proprietà</b>")
            self.form.addRow(QLabel("<span style='%s'>Clicca un disegno sul video (o nell'elenco qui sopra) per "
                                    "vedere e cambiare le sue opzioni.</span>" % GREY))
            self.form.itemAt(0).widget().setWordWrap(True)
            self.help.setText("")
        else:
            kind = d.get("kind")
            name = DRAWING_KINDS.get(kind, kind)
            if kind == "spotlight":
                name = "Giocatore seguito" if _tracked(d) else "Cono / anello fisso (non segue)"
            self.title.setText(f"<b>Proprietà · {name}</b> <span style='{GREY}'>a {fmt_time(d.get('t', 0), True)}</span>")
            getattr(self, "_build_" + str(kind), self._build_other)(d)
            self._build_common(d)
            self.help.setText(self._help(d))
        self.scroll.setWidget(body)

    def refresh(self):
        self.set_drawing(self._d, force=True)

    # ---------- mattoni ----------
    def _check(self, text, on, fn, tip=""):
        cb = QCheckBox(text)
        cb.setChecked(bool(on))
        cb.setFocusPolicy(Qt.NoFocus)
        if tip:
            cb.setToolTip(tip)
        cb.toggled.connect(fn)
        return cb

    def _slider(self, lo, hi, val, fn):
        s = QSlider(Qt.Horizontal)
        s.setRange(lo, hi)
        s.setValue(int(round(val)))
        s.setFocusPolicy(Qt.NoFocus)
        s.valueChanged.connect(fn)
        return s

    def _combo(self, items, cur, fn):
        c = QComboBox()
        for txt, data in items:
            c.addItem(txt, data)
        c.setCurrentIndex(max(0, c.findData(cur)))
        c.setFocusPolicy(Qt.NoFocus)
        c.currentIndexChanged.connect(lambda _i: fn(c.currentData()))
        return c

    def _section(self, text):
        lab = QLabel(f"<b>{text}</b>")
        lab.setContentsMargins(0, 6, 0, 0)
        self.form.addRow(lab)

    def _set(self, key, value):
        """Cambia un'opzione del disegno (passa dal programma: salva «da salvare», ridisegna, registra)."""
        if self._d is not None:
            self.win._set_data(self._d, key, value)
            if key in ("trail", "speed", "goal", "run") and self._d.get("kind") == "spotlight":
                self.win.remember_data(self._d)

    def _live(self, key, value):
        """Cursori: cambia subito senza ricostruire niente."""
        d = self._d
        if d is None:
            return
        d[key] = value
        self.win.mark_dirty()
        self.win.view.update()
        if d.get("kind") == "spotlight":
            self.win.remember_cone(d)

    # ---------- giocatore (seguito o segnato in un fermo immagine) ----------
    def _build_spotlight(self, d):
        """Una riga per interruttore; i dettagli (cursori, scelte) compaiono solo se l'interruttore è acceso."""
        f = self.form
        tracked = _tracked(d)

        def detail(label, widget, on):
            f.addRow(label, widget)
            lab = f.labelForField(widget)
            for x in (widget, lab):
                x.setVisible(bool(on))
            return lambda v: [x.setVisible(bool(v)) for x in (widget, lab)]

        # anello
        ring_c = self._combo([("tratteggiato", "tratteggiato"), ("pieno", "pieno")], d.get("ring", "pieno"),
                             lambda v: (self._set("ring", v), self.win.remember_cone(d)))
        row = QHBoxLayout()
        ring_cb = self._check("Anello a terra", d.get("ring_on", True), lambda v: None)
        row.addWidget(ring_cb)
        row.addWidget(ring_c)
        row.addStretch()
        f.addRow(row)
        ring_c.setVisible(bool(d.get("ring_on", True)))
        show_w = detail("   larghezza", self._slider(40, 300, 100 * d.get("size", 1.0),
                                                     lambda v: self._live("size", v / 100)), True)
        ring_cb.toggled.connect(lambda v: (self._set("ring_on", bool(v)), ring_c.setVisible(bool(v))))

        # cono di luce
        cone_cb = self._check("Cono di luce dall'alto", d.get("cone_on", True), lambda v: None)
        f.addRow(cone_cb)
        on = bool(d.get("cone_on", True))
        show_h = detail("   altezza", self._slider(5, 100, max(5, 10 * d.get("cone", 3.0)),
                                                   lambda v: self._live("cone", v / 10)), on)
        show_l = detail("   luce", self._slider(5, 100, 100 * d.get("light", 0.35),
                                                lambda v: self._live("light", v / 100)), on)
        show_s = detail("   tipo", self._combo([("colorato", ""), ("riflettore (luce bianca)", "riflettore")],
                                               d.get("cone_style") or "",
                                               lambda v: (self._set("cone_style", v), self.win.remember_cone(d))), on)
        cone_cb.toggled.connect(lambda v: (self._set("cone_on", bool(v)), show_h(v), show_l(v), show_s(v),
                                           self.win.remember_cone(d)))

        # nome
        name = QLineEdit(d.get("name", ""))
        name.setPlaceholderText("nome o numero (vuoto = niente)")
        f.addRow("Nome", name)
        show_p = detail("   posizione", self._combo([("automatica", ""), ("sopra il giocatore", "sopra"),
                                                     ("sotto l'anello", "sotto")], d.get("name_pos") or "",
                                                    lambda v: self._set("name_pos", v)), bool(d.get("name")))

        def name_done():
            t = name.text().strip()
            if t != (d.get("name") or ""):
                self._set("name", t)
                show_p(bool(t))
        name.editingFinished.connect(name_done)

        if tracked:
            trail = QDoubleSpinBox()
            trail.setRange(1, 15)
            trail.setDecimals(0)
            trail.setSuffix(" s")
            trail.setValue(float(d.get("trail") or self.win.trail_sp.value() or 3))
            trail.setVisible((d.get("trail") or 0) > 0)
            row = QHBoxLayout()
            row.addWidget(self._check("Scia del percorso", (d.get("trail") or 0) > 0,
                                      lambda v: (self._set("trail", trail.value() if v else 0),
                                                 trail.setVisible(bool(v)))))
            row.addWidget(trail)
            row.addStretch()
            trail.valueChanged.connect(lambda v: self._set("trail", v) if (d.get("trail") or 0) > 0 else None)
            f.addRow(row)
            f.addRow(self._check("   scia morbida", d.get("trail_smooth", True),
                                 lambda v: self._set("trail_smooth", bool(v)),
                                 "Toglie lo zig-zag dovuto al tremolio della posizione. Spenta: la scia passa da ogni punto"))
            for key, text in (("speed", "Velocità (km/h)"), ("run", "Metri percorsi"), ("goal", "Distanza dalla porta")):
                f.addRow(self._check(text, d.get(key), lambda v, k=key: self._set(k, bool(v))))
            if not self.win.project.calibrations:
                lab = QLabel("<span style='color:#ffb74d'>km/h e metri: serve 📐 Calibra campo</span>")
                lab.setWordWrap(True)
                f.addRow(lab)
            f.addRow(self._check("Spazio libero (cerchio fino all'avversario più vicino)", d.get("space"),
                                 lambda v: self.win._set_space(d, bool(v)),
                                 "Cerchio trasparente a terra: più è largo, più spazio ha il giocatore"))
            if True:
                f.addRow(self._check("   ↳ scrivi anche i metri di spazio libero", d.get("space_m"),
                                     lambda v: self._set("space_m", bool(v)),
                                     "Scrive accanto al nome la distanza dall'avversario più vicino (serve «Spazio libero» acceso e il campo calibrato)"))
            row = QHBoxLayout()
            b1 = QPushButton("🔄 È un altro: correggi")
            b1.setToolTip("Porta il video nel punto in cui l'anello passa al giocatore sbagliato, premi qui e poi "
                          "clicca il giocatore giusto")
            b1.clicked.connect(lambda: self.win.correct_here(d))
            b2 = QPushButton("Smetti di seguirlo da qui")
            b2.clicked.connect(lambda: self.win.stop_following_here(d))
            for b in (b1, b2):
                b.setFocusPolicy(Qt.NoFocus)
                row.addWidget(b)
            f.addRow(row)
        else:
            sp_cb = self._check("Spazio libero (cerchio attorno al giocatore)", d.get("space"), lambda v: None,
                                "Qui il raggio lo scegli tu con il cursore")
            f.addRow(sp_cb)
            show_r = detail("   raggio", self._slider(10, 150, 10 * float(d.get("space_r") or 4.0),
                                                      lambda v: self._live("space_r", v / 10)), bool(d.get("space")))

            def space_on(v):
                if v and not d.get("space_r"):
                    d["space_r"] = 4.0
                self._set("space", bool(v))
                show_r(v)
            sp_cb.toggled.connect(space_on)

    # ---------- fantasma ----------
    def _build_fantasma(self, d):
        f = self.form
        f.addRow(self._check("Figura del giocatore", d.get("figure", True), lambda v: self._set("figure", bool(v))))
        if d.get("cutout"):
            f.addRow(self._check("   usa il giocatore vero (ritaglio) invece della sagoma", d.get("use_cut", True),
                                 lambda v: self._set("use_cut", bool(v)),
                                 f"Ritagliato con {d['cutout'].get('method', '')}"))
            f.addRow("   trasparenza", self._slider(30, 100, 100 * d.get("cut_op", 0.8),
                                                    lambda v: self._live("cut_op", v / 100)))
        f.addRow(self._check("Freccia da dove sta a dove doveva stare", d.get("arrow", True),
                             lambda v: self._set("arrow", bool(v))))
        f.addRow(self._check("Metri di distanza", d.get("metrics", True), lambda v: self._set("metrics", bool(v))))
        if not self.win.project.calibrations:
            lab = QLabel("<span style='color:#ffb74d'>I metri e l'anello in prospettiva: serve 📐 Calibra campo</span>")
            lab.setWordWrap(True)
            f.addRow(lab)
        f.addRow("Grandezza del giocatore", self._slider(30, 250, 100 * d.get("fig_scale", 1.0),
                                                         lambda v: self._live("fig_scale", v / 100)))
        f.addRow("   grandezza anello", self._slider(40, 300, 100 * d.get("size", 1.0),
                                                     lambda v: self._live("size", v / 100)))
        name = QLineEdit(d.get("name", ""))
        name.setPlaceholderText("nome o numero (vuoto = niente)")
        name.editingFinished.connect(lambda: self._set("name", name.text().strip())
                                     if name.text().strip() != (d.get("name") or "") else None)
        f.addRow("Nome", name)

    # ---------- per tutti i disegni ----------
    def _build_common(self, d):
        """Intensità del disegno, e per le forme riempite forza del riempimento e bordo sì/no."""
        f = self.form
        kind = d.get("kind")
        self._section("Aspetto")
        f.addRow("Intensità", self._slider(5, 100, 100 * float(d.get("opacity", 1.0)),
                                           lambda v: self._live("opacity", v / 100)))
        filled = kind in ("zona", "area") or (kind == "collega" and (d.get("fill") or d.get("behind")
                                                                    or d.get("gap_fill")))
        if filled:
            f.addRow("Riempimento (forza)", self._slider(10, 250, 100 * float(d.get("fill_k", 1.0)),
                                                         lambda v: self._live("fill_k", v / 100)))
        if kind in ("zona", "area") or (kind == "collega" and d.get("fill")):
            f.addRow(self._check("Bordo", d.get("edge", True), lambda v: self._set("edge", bool(v)),
                                 "Spento: resta solo la forma riempita, senza linea attorno"))
        if kind == "collega":
            f.addRow("Intensità anelli", self._slider(5, 100, 100 * float(d.get("ring_k", 1.0)),
                                                      lambda v: self._live("ring_k", v / 100)))

    # ---------- palla ----------
    def _build_palla(self, d):
        f = self.form
        f.addRow(self._check("Sfuma la parte vecchia", d.get("fade", True), lambda v: self._set("fade", bool(v))))
        f.addRow(self._check("Pallino sulla palla", d.get("ball_dot", False), lambda v: self._set("ball_dot", bool(v))))
        f.addRow(self._check("Alone luminoso", d.get("glow", False), lambda v: self._set("glow", bool(v))))
        f.addRow(self._check("Tratteggiata", d.get("dashed", False), lambda v: self._set("dashed", bool(v))))
        f.addRow(self._check("Punta della freccia alla fine", d.get("head", False), lambda v: self._set("head", bool(v))))
        f.addRow(self._check("Mostra subito tutta la traiettoria", d.get("ball_whole", False),
                             lambda v: self._set("ball_whole", bool(v)),
                             "Spento: la riga si allunga mentre la palla viaggia"))
        lab = QLabel(f"<span style='{GREY}'>Se in un punto ha preso un'altra cosa, fermati lì e trascina il pallino "
                     "sulla palla: da quel punto la segue di nuovo.</span>")
        lab.setWordWrap(True)
        f.addRow(lab)

    # ---------- visuale ----------
    def _build_visuale(self, d):
        f = self.form
        if not self.win.project.calibrations:
            lab = QLabel("<span style='color:#ffb74d'>Per il ventaglio disteso sul prato: 📐 Calibra campo</span>")
            lab.setWordWrap(True)
            f.addRow(lab)
        f.addRow("Ampiezza (gradi)", self._slider(15, 150, d.get("vis_angle", 50), lambda v: self._live("vis_angle", v)))
        ln_on = bool(d.get("vis_len"))
        ln_sl = self._slider(3, 60, d.get("vis_len") or 20, lambda v: self._live("vis_len", v))
        ln_cb = self._check("Lunghezza fissa (metri)", ln_on, lambda v: None,
                            "Spenta: il ventaglio arriva fino al punto (o al compagno) che hai cliccato")
        f.addRow(ln_cb)
        f.addRow("   metri", ln_sl)
        ln_sl.setVisible(ln_on)
        lab_ = f.labelForField(ln_sl)
        if lab_ is not None:
            lab_.setVisible(ln_on)
        ln_cb.toggled.connect(lambda v: (self._set("vis_len", ln_sl.value() if v else 0), ln_sl.setVisible(bool(v)),
                                         lab_.setVisible(bool(v)) if lab_ is not None else None))
        f.addRow("Gira (gradi)", self._slider(-90, 90, d.get("vis_rot", 0), lambda v: self._live("vis_rot", v)))
        f.addRow("Riempimento (forza)", self._slider(10, 200, 100 * d.get("vis_strength", 1.6),
                                           lambda v: self._live("vis_strength", v / 100)))
        f.addRow(self._check("Bordo", d.get("vis_edge", True), lambda v: self._set("vis_edge", bool(v))))
        tip = QLabel(f"<span style='{GREY}'>Per cambiare direzione trascina il pallino bianco (il punto verso cui "
                     "guarda). Senza «lunghezza fissa» il ventaglio arriva fino a lì.</span>")
        tip.setWordWrap(True)
        f.addRow(tip)
        f.addRow("Riempimento", self._combo([("schiarisce l'erba", "schiarisci"), ("scurisce l'erba", "scurisci"),
                                             ("colore", "")], d.get("fill_style", "schiarisci"),
                                            lambda v: self._set("fill_style", v)))
        if _tracked(d):
            b = QPushButton("Smetti di seguirli da qui")
            b.setFocusPolicy(Qt.NoFocus)
            b.clicked.connect(lambda: self.win.stop_following_here(d))
            f.addRow(b)

    # ---------- collega giocatori ----------
    def _build_collega(self, d):
        f = self.form
        n = len(d.get("points") or [])
        items = [("➖ Linea (giocatori in fila)", "linea")]
        if n >= 3:
            items += [("⬡ Figura chiusa", "chiusa"), ("⬢ Figura riempita", "riempita")]
        f.addRow("Forma", self._combo(items, self.win._link_mode(d), lambda v: self.win._set_link_from_menu(d, v)))
        if n < 3:
            lab = QLabel(f"<span style='{GREY}'>Per chiudere o riempire la figura servono almeno 3 giocatori.</span>")
            lab.setWordWrap(True)
            f.addRow(lab)
        f.addRow(self._check("Mostra i metri tra i giocatori", d.get("metrics", True),
                             lambda v: self._set("metrics", bool(v))))
        f.addRow(self._check("Scritta dei metri lungo la linea", d.get("label_along", False),
                             lambda v: self._set("label_along", bool(v))))
        if d.get("fill") and n >= 3:
            f.addRow("   riempimento", self._combo([("colore", ""), ("schiarisce l'erba", "schiarisci"), ("scurisce l'erba", "scurisci")], d.get("fill_style") or "",
                                                  lambda v: self._set("fill_style", v)))
            f.addRow(self._check("Righe diagonali (invece del colore pieno)", d.get("hatch"),
                                 lambda v: self._set("hatch", bool(v))))
        # anelli di un altro colore e sigle dei giocatori
        f.addRow("Colore anelli", self._combo([("come la riga", ""), ("blu", "#2f80ff"), ("rosso", "#ff5252"),
                                               ("bianco", "#ffffff"), ("giallo", "#ffeb3b"), ("azzurro", "#40c4ff"),
                                               ("verde", "#69f0ae"), ("nero", "#000000")],
                                              d.get("ring_color") or "", lambda v: self._set("ring_color", v or None)))
        tg = QLineEdit(", ".join(d.get("tags") or []))
        tg.setPlaceholderText("es. CM, RB (nell'ordine dei clic)")
        tg.setToolTip("Sigla o nome sopra ogni giocatore collegato, nell'ordine in cui li hai cliccati. "
                      "Lascia vuoto un posto con due virgole: «CM,,RB»")

        def tags_done():
            v = [x.strip() for x in tg.text().replace(";", ",").split(",")]
            while v and not v[-1]:
                v.pop()
            if v != (d.get("tags") or []):
                self._set("tags", v)

        tg.editingFinished.connect(tags_done)
        f.addRow("Sigle", tg)
        # distanza da un altro reparto (un altro collegamento)
        others = [o for o in self.win.project.drawings if o.get("kind") == "collega" and o.get("id") != d.get("id")]
        if others:
            from model import fmt_time
            items = [("nessuno", "")] + [(f"{fmt_time(o['t'], True)} · {len(o.get('points') or [])} giocatori"
                                          + (f" · {o['name']}" if o.get("name") else ""), o["id"]) for o in others]
            gc = self._combo(items, d.get("gap_to") or "", lambda v: self._set("gap_to", v or None))
            gc.setToolTip("Righello in profondità (verso la porta) tra questo reparto e quello scelto, con i metri. "
                          "Si vede quando i due collegamenti sono sul video insieme. Serve il campo calibrato")
            f.addRow("Distanza dal reparto", gc)
            gl_cb = self._check("   riga della distanza", d.get("gap_line", True),
                                lambda v: self._set("gap_line", bool(v)), "Spenta: resta solo la scritta con i metri")
            f.addRow(gl_cb)
            gl_cb.setVisible(bool(d.get("gap_to")))
            gc.currentIndexChanged.connect(lambda _i: gl_cb.setVisible(bool(gc.currentData())))
            gf_col = self._combo([("giallo", "#ffeb3b"), ("azzurro", "#40c4ff"), ("bianco", "#ffffff"),
                                  ("verde", "#69f0ae"), ("rosso", "#ff5252")], d.get("gap_color") or "#ffeb3b",
                                 lambda v: self._set("gap_color", v))
            gf_cb = self._check("   colora lo spazio tra i due reparti", d.get("gap_fill", False), lambda v: None)
            gf_sty = self._combo([("colore", ""), ("schiarisce l'erba", "schiarisci"), ("scurisce l'erba", "scurisci")], d.get("gap_style") or "", lambda v: self._set("gap_style", v))
            f.addRow(gf_cb)
            f.addRow("   riempimento", gf_sty)
            f.addRow("   colore", gf_col)
            gf_rows = [gf_cb, gf_sty, f.labelForField(gf_sty), gf_col, f.labelForField(gf_col)]

            def show_gf(on_gap, on_fill):
                gf_cb.setVisible(on_gap)
                for x in gf_rows[1:]:
                    if x is not None:
                        x.setVisible(on_gap and on_fill)

            show_gf(bool(d.get("gap_to")), bool(d.get("gap_fill")))
            gf_cb.toggled.connect(lambda v: (self._set("gap_fill", bool(v)), show_gf(True, bool(v))))
            gc.currentIndexChanged.connect(lambda _i: show_gf(bool(gc.currentData()), gf_cb.isChecked()))
        # spazio dietro l'ultimo uomo
        bh_cb = self._check("Spazio dietro l'ultimo uomo", d.get("behind", False), lambda v: None,
                            "Colora il campo dal giocatore collegato più vicino alla sua porta fino alla linea di fondo. "
                            "Segue i giocatori. Serve il campo calibrato vicino a questo momento")
        f.addRow(bh_cb)
        bh_col = self._combo([("azzurro", "#40c4ff"), ("bianco", "#ffffff"), ("giallo", "#ffeb3b"),
                              ("verde", "#69f0ae"), ("rosso", "#ff5252")], d.get("behind_color") or "#40c4ff",
                             lambda v: self._set("behind_color", v))
        bh_side = self._combo([("riconosciuta in automatico", "auto"), ("quella a sinistra nel video", "left"),
                               ("quella a destra nel video", "right")], d.get("behind_side") or "auto",
                              lambda v: self._set("behind_side", v))
        bh_lab = self._check("Scrivi i metri dello spazio", d.get("behind_label", True),
                             lambda v: self._set("behind_label", bool(v)))
        bh_sty = self._combo([("colore", ""), ("schiarisce l'erba", "schiarisci"), ("scurisce l'erba", "scurisci")], d.get("behind_style") or "", lambda v: self._set("behind_style", v))
        f.addRow("   riempimento", bh_sty)
        f.addRow("   colore", bh_col)
        f.addRow("   porta da difendere", bh_side)
        f.addRow(bh_lab)
        bh_rows = [bh_sty, f.labelForField(bh_sty), bh_col, f.labelForField(bh_col), bh_side,
                   f.labelForField(bh_side), bh_lab]

        def show_bh(v):
            for x in bh_rows:
                if x is not None:
                    x.setVisible(bool(v))

        show_bh(d.get("behind", False))
        bh_cb.toggled.connect(lambda v: (self._set("behind", bool(v)), show_bh(v)))
        if _tracked(d):
            # anelli ai piedi di tutti i giocatori collegati
            ring_c = self._combo([("tratteggiato", "tratteggiato"), ("pieno", "pieno")], d.get("ring", "pieno"),
                                 lambda v: self._set("ring", v))
            row = QHBoxLayout()
            ring_cb = self._check("Anello a terra", d.get("ring_on", True), lambda v: None)
            row.addWidget(ring_cb)
            row.addWidget(ring_c)
            row.addStretch()
            f.addRow(row)
            ring_c.setVisible(bool(d.get("ring_on", True)))
            sl = self._slider(40, 300, 100 * d.get("size", 1.0), lambda v: self._live("size", v / 100))
            f.addRow("   larghezza", sl)
            lab = f.labelForField(sl)
            for x in (sl, lab):
                x.setVisible(bool(d.get("ring_on", True)))
            ring_cb.toggled.connect(lambda v: (self._set("ring_on", bool(v)), ring_c.setVisible(bool(v)),
                                               sl.setVisible(bool(v)), lab.setVisible(bool(v))))
            b = QPushButton("Smetti di seguirli da qui")
            b.setFocusPolicy(Qt.NoFocus)
            b.clicked.connect(lambda: self.win.stop_following_here(d))
            f.addRow(b)

    def _build_distanza(self, d):
        self.form.addRow(self._check("Mostra i metri", d.get("metrics", True), lambda v: self._set("metrics", bool(v))))
        self.form.addRow(self._check("Scritta dei metri lungo la linea", d.get("label_along", False),
                                     lambda v: self._set("label_along", bool(v))))
        if _tracked(d):
            b = QPushButton("Smetti di seguirli da qui")
            b.setFocusPolicy(Qt.NoFocus)
            b.clicked.connect(lambda: self.win.stop_following_here(d))
            self.form.addRow(b)

    # ---------- zone ----------
    def _build_zona(self, d):
        f = self.form
        lab = QLineEdit(d.get("label", ""))
        lab.setPlaceholderText("scritta della zona (vuoto = niente)")
        lab.editingFinished.connect(lambda: self._set("label", lab.text().strip())
                                    if lab.text().strip() != (d.get("label") or "") else None)
        f.addRow("Scritta", lab)
        f.addRow("Posizione", self._combo([("Sotto la zona", "sotto"), ("Sopra la zona", "sopra"),
                                           ("Dentro la zona", "dentro")], d.get("label_pos", "sotto"),
                                          lambda v: self._set("label_pos", v)))
        f.addRow("Riempimento", self._combo([("colore", ""), ("schiarisce l'erba", "schiarisci"), ("scurisce l'erba", "scurisci")], d.get("fill_style") or "",
                                            lambda v: self._set("fill_style", v)))
        f.addRow(self._check("Righe diagonali (invece del colore pieno)", d.get("hatch"),
                             lambda v: self._set("hatch", bool(v))))

    _build_area = _build_zona

    # ---------- testo ----------
    def _build_testo(self, d):
        f = self.form
        t = QLabel(f"«{d.get('text', '')}»")
        t.setWordWrap(True)
        f.addRow(t)
        b = QPushButton("✏️ Modifica testo (carattere, grandezza, colore)…")
        b.setFocusPolicy(Qt.NoFocus)
        b.clicked.connect(lambda: (self.win.edit_text(d), self.refresh()))
        f.addRow(b)
        f.addRow(self._check("Stesa sul campo, in prospettiva", d.get("ground"),
                             lambda v: self.win._set_ground_text(d, bool(v))))

    # ---------- freccia curva ----------
    def _build_curva(self, d):
        self.form.addRow(self._check("Punta della freccia", d.get("head", True), lambda v: self._set("head", bool(v))))
        self.form.addRow(self._check("Tratteggiata (corsa senza palla)", d.get("dashed"),
                                     lambda v: self._set("dashed", bool(v))))
        self.form.addRow(self._check("Passaggio alto (ombra a terra)", d.get("lob"),
                                     lambda v: self._set("lob", bool(v)),
                                     "La freccia è la palla in aria, sotto resta l'ombra dritta sul prato. "
                                     "Per alzare l'arco tira il pallino in mezzo verso l'alto"))

    def _build_other(self, d):
        lab = QLabel(f"<span style='{GREY}'>Questo disegno non ha opzioni sue.</span>")
        lab.setWordWrap(True)
        self.form.addRow(lab)

    # ---------- riga di aiuto ----------
    def _help(self, d):
        base = "Colore e spessore: barra in alto. Durata: qui sotto. Spostarlo: trascinalo sul video."
        kind = d.get("kind")
        if kind == "spotlight" and _tracked(d):
            return "Ogni interruttore è indipendente: accendi solo quello che ti serve. " + base
        if kind == "spotlight":
            return "Resta fermo dove l'hai messo: non segue nessuno. " + base
        if kind == "fantasma":
            return "Il giocatore vero resta com'è; il fantasma è dove doveva stare. " + base
        if kind == "curva":
            return "Per curvarla tira il pallino in mezzo alla freccia. " + base
        return base
