"""Finestra «I tuoi lavori»: a sinistra i lavori, a destra quello che c'è nel lavoro scelto.

Un clic su un lavoro mostra a destra solo le sue cose, in tre schede: i pezzi raccolti (con la miniatura),
i video e i disegni. Doppio clic = apri / vai in quel punto.
"""
import json
import os
import time

import cv2
from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QColor, QIcon, QImage, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QDialog, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox, QPushButton, QSplitter, QTabWidget,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

import progetti
from model import DRAWING_KINDS, fmt_time

GREY = "color:#8a93a3"
TH = (96, 54)   # miniatura


def _day(ts):
    return time.strftime("%d/%m/%y", time.localtime(ts)) if ts else ""


def _stem(path):
    return os.path.splitext(os.path.basename(path or ""))[0]


class HomeDialog(QDialog):
    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.action = None        # cosa fare alla chiusura: ("project", dir) | ("video", dir, id) | ...
        self.setWindowTitle("I tuoi lavori")
        self.resize(1080, 640)
        self._thumbs = {}         # (video, secondo) -> QIcon
        self._todo = []           # miniature ancora da fare
        self._caps = {}
        self._timer = QTimer(self)
        self._timer.setInterval(0)
        self._timer.timeout.connect(self._next_thumb)

        lay = QVBoxLayout(self)
        sp = QSplitter(Qt.Horizontal)
        lay.addWidget(sp, 1)

        # ---------- sinistra: i lavori ----------
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        row = QHBoxLayout()
        row.addWidget(QLabel("<b style='font-size:15px'>Lavori</b>"))
        self.search = QLineEdit()
        self.search.setPlaceholderText("cerca…")
        self.search.textChanged.connect(lambda _t: self._fill_projects())
        row.addWidget(self.search, 1)
        lv.addLayout(row)
        self.plist = QListWidget()
        self.plist.currentRowChanged.connect(lambda _r: self._show_project())
        self.plist.itemDoubleClicked.connect(lambda _it: self._open_project())
        lv.addWidget(self.plist, 1)
        row = QHBoxLayout()
        for txt, fn, tip in (("＋ Nuovo", self._new, "Crea un nuovo lavoro"),
                             ("Rinomina", self._rename, "Cambia nome al lavoro selezionato"),
                             ("Elimina", self._delete, "Mette nel Cestino il lavoro selezionato")):
            b = QPushButton(txt)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            row.addWidget(b)
        lv.addLayout(row)
        sp.addWidget(left)

        # ---------- destra: cosa c'è nel lavoro scelto ----------
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        self.head = QLabel()
        self.head.setWordWrap(True)
        rv.addWidget(self.head)
        self.tabs = QTabWidget()
        rv.addWidget(self.tabs, 1)
        self.t_clips = self._table(["N°", "", "Dal video", "Inizio", "Durata", "Titolo"], stretch=5)
        self.t_clips.setIconSize(QSize(*TH))
        self.t_clips.verticalHeader().setDefaultSectionSize(TH[1] + 6)
        self.t_clips.setColumnWidth(1, TH[0] + 10)
        self.t_vids = self._table(["N°", "Video", "Aggiunto il", "Analisi", "Pezzi", "Disegni"], stretch=1)
        self.t_draws = self._table(["N°", "", "Momento", "Disegno", "Video"], stretch=3)
        self.tabs.addTab(self.t_clips, "Pezzi raccolti")
        self.tabs.addTab(self.t_vids, "Video")
        self.tabs.addTab(self.t_draws, "Disegni")
        for t in (self.t_clips, self.t_vids, self.t_draws):
            t.cellDoubleClicked.connect(lambda r, _c, tt=t: self._go(tt, r))
        hint = QLabel(f"<span style='{GREY}'>Un clic su un lavoro mostra qui solo le sue cose. Doppio clic su una "
                      "riga = apri quel video / vai a quel pezzo o disegno.</span>")
        hint.setWordWrap(True)
        rv.addWidget(hint)
        sp.addWidget(right)
        sp.setStretchFactor(0, 0)
        sp.setStretchFactor(1, 1)
        sp.setSizes([290, 790])

        row = QHBoxLayout()
        self.b_open = QPushButton("Apri questo lavoro")
        self.b_open.setDefault(True)
        self.b_open.clicked.connect(self._open_project)
        row.addWidget(self.b_open)
        self.b_video = QPushButton("＋ Apri un video per creare pezzi…")
        self.b_video.setToolTip("Scegli un video dal computer: si apre nella pagina di lavoro. I pezzi che raccogli da lì\n"
                                "finiscono in questo lavoro, qualunque sia il video da cui vengono.")
        self.b_video.clicked.connect(lambda: self._act("addvideo"))
        row.addWidget(self.b_video)
        self.b_racc = QPushButton("Ordina ed esporta i pezzi…")
        self.b_racc.setToolTip("Metti in ordine i pezzi raccolti di questo lavoro, dai un titolo, esportali insieme o separati")
        self.b_racc.clicked.connect(lambda: self._act("raccolta"))
        row.addWidget(self.b_racc)
        row.addStretch()
        b = QPushButton("Chiudi")
        b.clicked.connect(self.reject)
        row.addWidget(b)
        lay.addLayout(row)

        self._fill_projects(win.prog.dir if win.prog else None)

    def _table(self, heads, stretch):
        t = QTableWidget(0, len(heads))
        t.setHorizontalHeaderLabels(heads)
        h = t.horizontalHeader()
        for c in range(len(heads)):
            h.setSectionResizeMode(c, QHeaderView.Stretch if c == stretch else QHeaderView.ResizeToContents)
        t.verticalHeader().setVisible(False)
        t.setSelectionBehavior(QAbstractItemView.SelectRows)
        t.setSelectionMode(QAbstractItemView.SingleSelection)
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.setAlternatingRowColors(True)
        return t

    # ---------- lavori ----------
    def _open_dir(self):
        return os.path.abspath(self.win.prog.dir) if self.win.prog else None

    def _fill_projects(self, sel_dir=None):
        if sel_dir is None and self._sel() is not None:
            sel_dir = self._sel().dir
        q = self.search.text().strip().lower()
        self.projects = [p for p in progetti.list_projects() if q in p.name.lower()]
        od = self._open_dir()
        self.plist.blockSignals(True)
        self.plist.clear()
        row = 0
        for i, p in enumerate(self.projects):
            is_open = os.path.abspath(p.dir) == od
            it = QListWidgetItem(f"{i + 1}.  {p.name}" + ("   (aperto)" if is_open else "") + f"\n      {_day(p.updated)}"
                                 f"  ·  {len(p.videos)} video  ·  {p.n_clips()} pezzi")
            if is_open:
                f = it.font()
                f.setBold(True)
                it.setFont(f)
            self.plist.addItem(it)
            if sel_dir and os.path.abspath(p.dir) == os.path.abspath(sel_dir):
                row = i
        self.plist.blockSignals(False)
        if self.projects:
            self.plist.setCurrentRow(row)
        self._show_project()

    def _sel(self):
        r = self.plist.currentRow()
        ps = getattr(self, "projects", [])
        return ps[r] if 0 <= r < len(ps) else None

    def _new(self):
        name, ok = QInputDialog.getText(self, "Nuovo lavoro", "Nome del lavoro (es. «Trento – Lavis 12 ottobre» "
                                        "o «Esercitazioni Under 12»):")
        if not ok or not name.strip():
            return
        try:
            p = progetti.Progetto.create(name)
        except OSError as e:
            QMessageBox.critical(self, "Nuovo lavoro", f"Non riesco a creare il lavoro:\n{e}")
            return
        self.action = ("project", p.dir)
        self.accept()

    def _rename(self):
        p = self._sel()
        if not p:
            return
        name, ok = QInputDialog.getText(self, "Rinomina", "Nuovo nome:", text=p.name)
        if ok and name.strip():
            p.rename(name)
            self._fill_projects(p.dir)

    def _delete(self):
        p = self._sel()
        if not p:
            return
        if os.path.abspath(p.dir) == self._open_dir():
            QMessageBox.information(self, "Elimina", "Questo lavoro è aperto adesso: apri prima un altro lavoro.")
            return
        copied = [e for e in p.videos if e.get("copied")]
        extra = (f"\n\nDentro ci sono {len(copied)} video copiati nel lavoro: vanno anche loro nel Cestino."
                 if copied else "\n\nI video originali non vengono toccati.")
        r = QMessageBox.question(self, "Elimina lavoro", f"Mettere nel Cestino il lavoro «{p.name}» con le sue "
                                 f"analisi e i pezzi raccolti?{extra}\n\nSi può recuperare dal Cestino.")
        if r != QMessageBox.Yes:
            return
        if not progetti.trash(p.dir):
            QMessageBox.warning(self, "Elimina", "Non sono riuscito a metterlo nel Cestino. La cartella è:\n" + p.dir)
        self._fill_projects()

    # ---------- contenuto del lavoro scelto ----------
    def _show_project(self):
        p = self._sel()
        self._todo = []
        for t in (self.t_clips, self.t_vids, self.t_draws):
            t.setRowCount(0)
        for b in (self.b_open, self.b_video, self.b_racc):
            b.setEnabled(p is not None)
        if p is None:
            self.head.setText("<b>Nessun lavoro.</b> Premi «＋ Nuovo» per crearne uno.")
            return
        is_open = os.path.abspath(p.dir) == self._open_dir()
        if is_open:
            p = self.win.prog
        self.b_open.setText("Torna a questo lavoro" if is_open else "Apri questo lavoro")
        try:
            with open(p.raccolta_path, encoding="utf-8") as f:
                clips = json.load(f).get("clips", []) or []
        except (OSError, ValueError):
            clips = []
        tot = sum(max(0.0, c["end"] - c["start"]) for c in clips)
        self.head.setText(f"<b style='font-size:15px'>{p.name}</b> <span style='{GREY}'> — {len(p.videos)} video, "
                          f"{len(clips)} pezzi raccolti (in tutto {fmt_time(tot)})</span>")
        # pezzi raccolti
        t = self.t_clips
        t.setRowCount(len(clips))
        for i, c in enumerate(clips):
            vals = [str(i + 1), "", _stem(c.get("video")), fmt_time(c["start"]),
                    f"{c['end'] - c['start']:.1f} s".replace(".", ","), c.get("title", "")]
            for col, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if col in (0, 3, 4):
                    it.setTextAlignment(Qt.AlignCenter)
                t.setItem(i, col, it)
            t.item(i, 0).setData(Qt.UserRole, ("clip", p.dir, c.get("video", ""), float(c["start"])))
            key = (c.get("video", ""), round(float(c["start"]), 2))
            if key in self._thumbs:
                t.item(i, 1).setIcon(self._thumbs[key])
            else:
                self._todo.append((i, key))
        # video
        cur = os.path.abspath(self.win.reader.path) if (is_open and self.win.reader) else None
        nclip = {}
        for c in clips:
            a = os.path.abspath(c.get("video", ""))
            nclip[a] = nclip.get(a, 0) + 1
        t = self.t_vids
        t.setRowCount(len(p.videos))
        draws = []
        for i, e in enumerate(p.videos):
            vp = p.video_path(e)
            live = cur == os.path.abspath(vp)
            ds = self.win.project.drawings if live else self.win._saved_drawings(p.analysis_path(e))
            draws += [(e, d) for d in ds]
            vals = [str(i + 1), _stem(vp) + ("   (aperto)" if live else "") + ("   ⚠ non trovato" if not os.path.exists(vp) else ""),
                    _day(e.get("added")), "salvata" if p.has_analysis(e) else "da fare",
                    str(nclip.get(os.path.abspath(vp), 0)), str(len(ds))]
            for col, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if col != 1:
                    it.setTextAlignment(Qt.AlignCenter)
                if live:
                    f = it.font()
                    f.setBold(True)
                    it.setFont(f)
                t.setItem(i, col, it)
            t.item(i, 0).setData(Qt.UserRole, ("video", p.dir, e["id"]))
        # disegni
        t = self.t_draws
        t.setRowCount(len(draws))
        for i, (e, d) in enumerate(draws):
            name = DRAWING_KINDS.get(d.get("kind"), d.get("kind"))
            if d.get("kind") == "testo":
                name += f" «{d.get('text', '')}»"
            if d.get("name"):
                name += f" «{d['name']}»"
            if any(a and a.get("type") == "track" for a in (d.get("anchors") or [])):
                name += "  (segue giocatore)"
            vals = [str(i + 1), "", fmt_time(d.get("t", 0), True), name, _stem(p.video_path(e))]
            for col, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if col in (0, 2):
                    it.setTextAlignment(Qt.AlignCenter)
                t.setItem(i, col, it)
            pm = QPixmap(14, 14)
            pm.fill(QColor(d.get("color", "#ffeb3b")))
            t.item(i, 1).setIcon(QIcon(pm))
            t.item(i, 0).setData(Qt.UserRole, ("draw", p.dir, e["id"], d.get("id"), float(d.get("t", 0))))
        self.tabs.setTabText(0, f"Pezzi raccolti ({len(clips)})")
        self.tabs.setTabText(1, f"Video ({len(p.videos)})")
        self.tabs.setTabText(2, f"Disegni ({len(draws)})")
        if not clips and self.tabs.currentIndex() == 0:
            self.tabs.setCurrentIndex(1)
        if self._todo:
            self._timer.start()

    # ---------- miniature (una alla volta, senza bloccare la finestra) ----------
    def _next_thumb(self):
        if not self._todo:
            self._timer.stop()
            return
        row, key = self._todo.pop(0)
        video, start = key
        icon = QIcon()
        try:
            cap = self._caps.get(video)
            if cap is None:
                cap = self._caps[video] = cv2.VideoCapture(video)
            cap.set(cv2.CAP_PROP_POS_MSEC, start * 1000.0)
            ok, fr = cap.read()
            if ok:
                fr = cv2.cvtColor(cv2.resize(fr, TH, interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
                img = QImage(fr.data, TH[0], TH[1], TH[0] * 3, QImage.Format_RGB888).copy()
                icon = QIcon(QPixmap.fromImage(img))
        except Exception:
            pass
        self._thumbs[key] = icon
        it = self.t_clips.item(row, 1)
        if it is not None:
            it.setIcon(icon)

    def done(self, r):
        self._timer.stop()
        for cap in self._caps.values():
            try:
                cap.release()
            except Exception:
                pass
        self._caps = {}
        super().done(r)

    # ---------- azioni ----------
    def _open_project(self):
        p = self._sel()
        if p:
            self.action = ("project", p.dir)
            self.accept()

    def _act(self, kind):
        p = self._sel()
        if p:
            self.action = (kind, p.dir)
            self.accept()

    def _go(self, table, row):
        it = table.item(row, 0)
        data = it.data(Qt.UserRole) if it else None
        if data:
            self.action = data
            self.accept()
