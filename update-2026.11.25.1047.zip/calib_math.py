"""Calibrazione precisa del campo.

Come nei metodi migliori per le riprese di calcio (PnLCalib, TVCalib):
1. un MODELLO VERO DI TELECAMERA (zoom, inclinazione, posizione) invece di una deformazione libera
   dell'immagine: con pochi punti sbaglia molto meno, soprattutto lontano dai punti cliccati;
2. l'AFFINAMENTO SULLE LINEE DIPINTE: dopo i clic, tutte le linee del campo che si vedono (laterali,
   aree, cerchio, lunetta...) vengono fatte combaciare con le linee bianche vere dell'immagine.
   I clic restano l'ancora, le linee correggono l'imprecisione dei clic.

Coordinate: immagine in pixel (u, v); campo in metri (X lungo la lunghezza, Y lungo la larghezza).
"""
import math

import cv2
import numpy as np


# ------------------------------------------------------------------ telecamera
def _P(params, size):
    """Matrice 3x3 campo (X, Y, 1) -> pixel per i parametri [f, rx, ry, rz, tx, ty, tz]."""
    f = params[0]
    K = np.array([[f, 0, size[0] / 2], [0, f, size[1] / 2], [0, 0, 1.0]])
    R = cv2.Rodrigues(np.asarray(params[1:4], float))[0]
    return K @ np.column_stack([R[:, 0], R[:, 1], params[4:7]])


def project(P, pts):
    pts = np.asarray(pts, float)
    if not len(pts):
        return np.zeros((0, 2)), np.zeros(0)
    q = np.column_stack([pts, np.ones(len(pts))]) @ P.T
    return q[:, :2] / q[:, 2:3], q[:, 2]


def _init_from_h(P0, size):
    """Parametri iniziali della telecamera da un'omografia campo->pixel (per diversi zoom)."""
    cx, cy = size[0] / 2, size[1] / 2
    C = np.array([[1, 0, -cx], [0, 1, -cy], [0, 0, 1.0]]) @ P0
    h1, h2 = C[:, 0], C[:, 1]
    fs = []
    d1 = h1[2] * h2[2]
    if abs(d1) > 1e-12:
        v = -(h1[0] * h2[0] + h1[1] * h2[1]) / d1
        if v > 0:
            fs.append(math.sqrt(v))
    d2 = h1[2] ** 2 - h2[2] ** 2
    if abs(d2) > 1e-12:
        v = -(h1[0] ** 2 + h1[1] ** 2 - h2[0] ** 2 - h2[1] ** 2) / d2
        if v > 0:
            fs.append(math.sqrt(v))
    fs += [size[0] * k for k in (0.5, 0.8, 1.2, 1.8, 2.7, 4.0, 6.0)]
    out = []
    for f in fs:
        if not (0.2 * size[0] < f < 20 * size[0]):
            continue
        G = np.linalg.inv(np.array([[f, 0, cx], [0, f, cy], [0, 0, 1.0]])) @ P0
        lam = 2.0 / (np.linalg.norm(G[:, 0]) + np.linalg.norm(G[:, 1]))
        for sgn in (1, -1):
            r1, r2, t = sgn * lam * G[:, 0], sgn * lam * G[:, 1], sgn * lam * G[:, 2]
            R = np.column_stack([r1, r2, np.cross(r1, r2)])
            U, _, Vt = np.linalg.svd(R)
            R = U @ Vt
            if np.linalg.det(R) < 0:
                continue
            if t[2] <= 0:
                continue
            rv = cv2.Rodrigues(R)[0].ravel()
            out.append(np.array([f, *rv, *t], float))
    return out


def _lm(fun, x0, iters=40, lam=1e-3, steps=None):
    """Levenberg-Marquardt semplice (Jacobiano numerico): niente librerie in più sul Mac."""
    x = np.asarray(x0, float).copy()
    r = fun(x)
    cost = float(r @ r)
    steps = steps if steps is not None else np.maximum(np.abs(x) * 1e-6, 1e-6)
    for _ in range(iters):
        J = np.empty((len(r), len(x)))
        for j in range(len(x)):
            d = np.zeros_like(x)
            d[j] = steps[j]
            J[:, j] = (fun(x + d) - r) / steps[j]
        A = J.T @ J
        g = J.T @ r
        improved = False
        for _try in range(8):
            try:
                dx = -np.linalg.solve(A + lam * np.diag(np.diag(A) + 1e-12), g)
            except np.linalg.LinAlgError:
                lam *= 10
                continue
            xn = x + dx
            rn = fun(xn)
            cn = float(rn @ rn)
            if np.isfinite(cn) and cn < cost:
                x, r, cost = xn, rn, cn
                lam = max(lam / 3, 1e-9)
                improved = True
                break
            lam *= 10
        if not improved or np.linalg.norm(dx) < 1e-9 * (1 + np.linalg.norm(x)):
            break
    return x, cost


# ------------------------------------------------------------------ linee bianche nell'immagine
def line_map(bgr):
    """Mappa delle distanze (in pixel) dalle linee bianche dipinte sull'erba."""
    h, w = bgr.shape[:2]
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    k = max(9, int(w / 120)) | 1
    th = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    grass = (hsv[..., 0] >= 30) & (hsv[..., 0] <= 95) & (hsv[..., 1] > 40)
    grass = cv2.dilate(grass.astype(np.uint8), np.ones((k, k), np.uint8)) > 0
    white = (th > 22) & (hsv[..., 1] < 90) & grass
    white = cv2.morphologyEx(white.astype(np.uint8), cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    # via i blob grossi (giocatori, cartelloni): le linee sono sottili
    n, lab, stats, _ = cv2.connectedComponentsWithStats(white, 8)
    keep = np.zeros(n, bool)
    for i in range(1, n):
        x, y, ww, hh, a = stats[i]
        fill = a / max(1, ww * hh)
        if a >= 12 and (max(ww, hh) > 4 * min(ww, hh) or fill < 0.35):
            keep[i] = True
    white = keep[lab]
    dt = cv2.distanceTransform((~white).astype(np.uint8), cv2.DIST_L2, 3)
    return dt.astype(np.float32), white


def _bilinear(img, pts):
    h, w = img.shape
    x = np.clip(pts[:, 0], 0, w - 1.001)
    y = np.clip(pts[:, 1], 0, h - 1.001)
    x0, y0 = np.floor(x).astype(int), np.floor(y).astype(int)
    fx, fy = x - x0, y - y0
    return (img[y0, x0] * (1 - fx) * (1 - fy) + img[y0, x0 + 1] * fx * (1 - fy) +
            img[y0 + 1, x0] * (1 - fx) * fy + img[y0 + 1, x0 + 1] * fx * fy)


def sample_spec(lines, step=0.5):
    """Posizioni dei campioni lungo le linee come (linea, tratto, t): restano valide se cambiano le misure."""
    out = []
    for li, line in enumerate(lines):
        for si, ((x0, y0), (x1, y1)) in enumerate(zip(line, line[1:])):
            n = max(1, int(math.hypot(x1 - x0, y1 - y0) / step))
            for t in np.linspace(0, 1, n, endpoint=False):
                out.append((li, si, t))
    return out


def eval_spec(lines, spec):
    out = np.empty((len(spec), 2))
    for k, (li, si, t) in enumerate(spec):
        (x0, y0), (x1, y1) = lines[li][si], lines[li][si + 1]
        out[k] = (x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)
    return out


def sample_lines(lines, step=0.5):
    out = []
    for line in lines:
        for (x0, y0), (x1, y1) in zip(line, line[1:]):
            n = max(1, int(math.hypot(x1 - x0, y1 - y0) / step))
            for t in np.linspace(0, 1, n, endpoint=False):
                out.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
        out.append(line[-1])
    return np.asarray(out, float)


# ------------------------------------------------------------------ calibrazione
def _robust(r, k=3.0):
    """Residui "alla Huber": oltre k contano sempre meno (un clic sbagliato non trascina tutto)."""
    a = np.abs(r)
    out = r.copy()
    big = a > k
    out[big] = np.sign(r[big]) * np.sqrt(2 * k * a[big] - k * k)
    return out


CLICK_SIGMA = 3.0  # precisione tipica di un clic (pixel), contro ~1 pixel delle linee bianche


def free_dims(field_fn, dims0):
    """Quali misure del campo (lunghezza, larghezza) i punti scelti permettono di ricavare.
    La lunghezza si ricava solo se ci sono punti che si spostano in modo diverso al cambiare
    della lunghezza (es. un'area + la metà campo); idem per la larghezza."""
    L, W = dims0
    p0 = np.asarray(field_fn(L, W), float)
    dl = np.round((np.asarray(field_fn(L + 1, W), float) - p0)[:, 0], 3)
    dw = np.round((np.asarray(field_fn(L, W + 1), float) - p0)[:, 1], 3)
    return len(set(dl.tolist())) > 1, len(set(dw.tolist())) > 1



def calibrate(img_px, field_fn, lines_fn, size, dims0, free=(False, False), dist_map=None,
              line_weight=1.0, cap=12.0, size_from_lines=True):
    """Calibrazione con modello di telecamera e (se c'è dist_map) affinamento sulle linee.

    img_px: punti cliccati in pixel; field_fn(L, W) -> punti del campo corrispondenti (metri);
    lines_fn(L, W) -> linee del campo (metri); dims0 = (L, W); free = quali misure ricavare.
    Ritorna dict con P (campo->pixel), L, W, err_px (clic), mirrored, line_px (distanza media dalle
    linee bianche), oppure None.
    """
    img_px = np.asarray(img_px, float)
    if len(img_px) < 4:
        return None
    L0, W0 = dims0
    if dist_map is not None and size_from_lines:
        free = (True, True)  # le linee che si vedono possono dire le misure vere (si tengono solo se migliorano)
    best = None
    for mirror in (False, True):
        def field(L, W):
            p = np.asarray(field_fn(L, W), float)
            if mirror:
                p = np.column_stack([p[:, 0], W - p[:, 1]])
            return p

        def lines(L, W):
            ls = lines_fn(L, W)
            return [[(x, W - y) for x, y in ln] for ln in ls] if mirror else ls

        fp = field(L0, W0)
        H0, _ = cv2.findHomography(fp, img_px, 0)
        if H0 is None:
            continue
        nfree = int(free[0]) + int(free[1])

        def unpack(x):
            L = x[7] if free[0] else L0
            W = x[7 + int(free[0])] if free[1] else W0
            return x[:7], L, W

        def res_pts(x):
            cam, L, W = unpack(x)
            q, z = project(_P(cam, size), field(L, W))
            r = (q - img_px).ravel()
            if (z <= 0).any():
                r = r + 1e4
            return r

        # 1) solo la telecamera, misure del campo fisse (più stabile)
        fixed = lambda x7: np.concatenate([x7, [L0] * int(free[0]), [W0] * int(free[1])])
        cands = []
        for x0 in _init_from_h(H0, size):
            x7, c = _lm(lambda v: res_pts(fixed(v)), x0, iters=60)
            cands.append((c, x7))
        if not cands:
            continue
        cands.sort(key=lambda t: t[0])
        x = fixed(cands[0][1])
        if dist_map is not None:
            # 2) linee con misure fisse, poi 3) misure libere (se i punti le permettono)
            x7, _ = _refine_lines(x[:7], lambda v: (v, L0, W0), field, lines, img_px, size, dist_map,
                                  line_weight, cap)
            x = fixed(x7)
            if nfree:
                # misure libere solo se le linee lo confermano chiaramente (altrimenti i piccoli errori
                # dei clic "allungano" o "accorciano" il campo)
                a_fix = line_alignment(_P(x[:7], size), lines(L0, W0), size, dist_map)
                xf, _ = _refine_lines(x, unpack, field, lines, img_px, size, dist_map, line_weight, cap,
                                      caps=(cap, cap * 0.6))
                cf, Lf, Wf = unpack(xf)
                a_free = line_alignment(_P(cf, size), lines(Lf, Wf), size, dist_map)
                plausible = 0.75 < Lf / L0 < 1.35 and 0.75 < Wf / W0 < 1.35
                if plausible and (a_fix is None or (a_free is not None and a_free < 0.85 * a_fix and
                                                    a_fix - a_free > 0.15)):
                    x = xf
        elif nfree:
            x, _ = _lm(res_pts, x, iters=60)
        cam, L, W = unpack(x)
        P = _P(cam, size)
        q, _ = project(P, field(L, W))
        err = float(np.sqrt(np.mean(np.sum((q - img_px) ** 2, 1))))
        if best is None or err < best["err_px"] - 1e-6:
            best = {"P": P, "L": float(L), "W": float(W), "err_px": err, "mirrored": mirror, "cam": cam,
                    "nfree": nfree}
    if best is None:
        return None
    if best["mirrored"]:
        # riporta al campo vero: Y -> W - Y
        Mr = np.array([[1, 0, 0], [0, -1, best["W"]], [0, 0, 1.0]])
        best["P"] = best["P"] @ Mr  # P'(X, W-Y) = P(X, Y)
    best["line_px"] = None
    best["m_per_px"] = None
    if dist_map is not None:
        lines_b = lines_fn(best["L"], best["W"])
        best["line_px"] = line_alignment(best["P"], lines_b, size, dist_map)
        s = sample_lines(lines_b, 0.5)
        ok = _visible_samples(best["P"], s, size)
        if ok.sum() > 10:
            q, _ = project(best["P"], s[ok])
            seg = np.linalg.norm(np.diff(q, axis=0), axis=1)
            dm = np.linalg.norm(np.diff(s[ok], axis=0), axis=1)
            good = (dm > 0.2) & (dm < 0.8) & (seg > 0.05)
            if good.any():
                best["m_per_px"] = float(np.median(dm[good] / seg[good]))
    return best


def _visible_samples(P, samples, size, margin=0.0):
    q, z = project(P, samples)
    ok = (z > 0) & (q[:, 0] >= -margin) & (q[:, 0] < size[0] + margin) & (q[:, 1] >= -margin) & \
        (q[:, 1] < size[1] + margin)
    return ok


def line_alignment(P, lines, size, dist_map, cap=12.0):
    """Distanza media (pixel) tra le linee del campo calcolate e le linee bianche vere."""
    s = sample_lines(lines, 0.5)
    ok = _visible_samples(P, s, size)
    if ok.sum() < 20:
        return None
    q, _ = project(P, s[ok])
    d = np.minimum(_bilinear(dist_map, q), cap)
    return float(np.mean(d))  # media (con tetto): la mediana non vede le linee "un po' fuori"


def _refine_lines(x, unpack, field, lines, img_px, size, dist_map, line_weight, cap, caps=None):
    """Avvicina le linee del campo calcolate alle linee bianche dell'immagine (chamfer robusto,
    da grossolano a fine: prima "vede" le linee da lontano, poi si aggancia con precisione)."""
    sm = cv2.GaussianBlur(dist_map, (0, 0), 1.0)
    cur = x
    for cap_i in (caps or (cap * 3.5, cap * 2, cap, cap * 0.6)):
        cam, L, W = unpack(cur)
        spec_all = sample_spec(lines(L, W), 0.5)
        samples = eval_spec(lines(L, W), spec_all)
        ok = _visible_samples(_P(cam, size), samples, size, margin=-4)
        if ok.sum() < 30:
            return cur, None
        idx = np.where(ok)[0]
        if len(idx) > 900:
            idx = idx[np.linspace(0, len(idx) - 1, 900).astype(int)]
        spec = [spec_all[i] for i in idx]  # campioni ricalcolati dalle misure a ogni passo
        n_pts = len(img_px)
        wl = line_weight * math.sqrt(max(1, 6 * n_pts) / len(idx))

        def res(xx):
            c, LL, WW = unpack(xx)
            P = _P(c, size)
            q, z = project(P, field(LL, WW))
            r1 = _robust((q - img_px).ravel() / CLICK_SIGMA)  # clic meno precisi delle linee; uno sbagliato pesa poco
            q2, z2 = project(P, eval_spec(lines(LL, WW), spec))
            d = np.minimum(_bilinear(sm, q2), cap_i)
            d[(z2 <= 0)] = cap_i
            r = np.concatenate([r1, wl * d])
            if (z <= 0).any():
                r = r + 1e4
            return r

        cur, _ = _lm(res, cur, iters=40)
    return cur, None


def h_img_to_field(P, size):
    """Omografia immagine NORMALIZZATA (0..1) -> campo (metri), come usata nel resto dell'app."""
    S = np.diag([size[0], size[1], 1.0])
    return np.linalg.inv(P) @ S


# ------------------------------------------------------------------ ri-aggancio alle linee
def refine_homography(Hn, bgr, lines, dm=None, caps=(24.0, 12.0, 6.0)):
    """Corregge la posizione del campo in un fotogramma (Hn: immagine normalizzata -> campo, presa
    seguendo il movimento della telecamera, che col tempo "scivola") agganciandola alle linee bianche
    dipinte. Ritorna (H corretta o None, scarto prima, scarto dopo) in pixel."""
    from scipy.optimize import least_squares

    def _ap(M, pts):
        p = np.c_[pts, np.ones(len(pts))] @ M.T
        return p[:, :2] / p[:, 2:3]

    h, w = bgr.shape[:2]
    if dm is None:
        dm, _ = line_map(bgr)
    S = np.diag([1.0 / w, 1.0 / h, 1.0])
    Hp = np.asarray(Hn, float) @ S
    field = sample_lines(lines, 0.5)
    try:
        img0 = _ap(np.linalg.inv(Hp), field)
    except np.linalg.LinAlgError:
        return None, None, None
    ok = (img0[:, 0] > 4) & (img0[:, 0] < w - 4) & (img0[:, 1] > 4) & (img0[:, 1] < h - 4)
    if ok.sum() < 40:
        return None, None, None
    field, img0 = field[ok], img0[ok]
    if len(field) > 500:
        sel = np.linspace(0, len(field) - 1, 500).astype(int)
        field, img0 = field[sel], img0[sel]
    T = np.array([[2.0 / w, 0, -1], [0, 2.0 / h, -1], [0, 0, 1]])
    Ti = np.linalg.inv(T)

    def H_of(x):
        C = np.eye(3) + np.array([[x[0], x[1], x[2]], [x[3], x[4], x[5]], [x[6], x[7], 0]])
        return Hp @ Ti @ C @ T

    def img_of(x):
        return _ap(np.linalg.inv(H_of(x)), field)

    def score(x):
        # le linee che nel campo vero non sono dipinte (o coperte) non devono contare: si guarda il
        # 60% dei punti meglio allineati
        d = np.sort(np.minimum(_bilinear(dm, img_of(x)), 12.0))
        return float(np.mean(d[: max(10, int(len(d) * 0.6))]))

    before = score(np.zeros(8))
    x = np.zeros(8)
    try:
        for cap in caps:
            sm = cv2.GaussianBlur(np.minimum(dm, cap).astype(np.float32), (0, 0), 1.0)
            r = least_squares(lambda xx: _bilinear(sm, img_of(xx)), x, loss="soft_l1", f_scale=cap / 3,
                              x_scale=0.01, max_nfev=30)
            x = r.x
        after = score(x)
        move = float(np.mean(np.linalg.norm(img_of(x) - img0, axis=1)))
    except (np.linalg.LinAlgError, ValueError):
        return None, before, None
    if after <= before and after < 1.5 and move < 0.04 * w:
        Hnew = H_of(x) @ np.linalg.inv(S)
        return Hnew / Hnew[2, 2], before, after
    return None, before, after
