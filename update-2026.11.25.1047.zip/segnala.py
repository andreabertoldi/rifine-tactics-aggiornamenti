"""«Segnala»: errori, miglioramenti e cambiamenti dei tester, con le informazioni utili già allegate.
Le segnalazioni vanno in un foglio Google (script in segnalazioni/LEGGIMI.txt). Se non c'è internet restano
in coda e partono alla prossima apertura del programma."""
import base64
import json
import os
import platform
import time
import urllib.request
import uuid

import aggiorna
import config
import licenza
import paths

QUEUE = os.path.join(paths.BASE, "segnalazioni_da_inviare")
FAULT = os.path.join(paths.BASE, "ultimo_errore.txt")
RUNNING = os.path.join(paths.BASE, "in_esecuzione.flag")
TYPES = ["🐞 Errore (qualcosa non funziona)", "💡 Miglioramento (si può fare meglio)",
         "🔁 Cambiamento (vorrei fosse diverso)", "❓ Altro"]


def tail(path, n=40):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-n:])
    except OSError:
        return ""


def info(include_actions=True):
    d = {"versione": aggiorna.current_version(), "mac": platform.mac_ver()[0] or platform.platform(),
         "chip": platform.machine(), "codice_mac": licenza.machine_code()}
    if include_actions:
        d["ultime_azioni"] = tail(os.path.join(paths.BASE, "registro_azioni.txt"))
        d["ultimo_errore"] = tail(FAULT, 30)
    return d


def _post(payload):
    if not config.FEEDBACK_URL:
        return False
    try:
        req = urllib.request.Request(config.FEEDBACK_URL, data=json.dumps(payload).encode("utf-8"),
                                     headers={"Content-Type": "text/plain;charset=utf-8"})
        with licenza.open_url(req, 25) as r:
            return r.status < 400
    except Exception:
        return False


def send(payload):
    """True se inviata; altrimenti la mette in coda e ritorna False."""
    if _post(payload):
        return True
    try:
        os.makedirs(QUEUE, exist_ok=True)
        with open(os.path.join(QUEUE, f"{int(time.time())}_{uuid.uuid4().hex[:4]}.json"), "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
    except OSError:
        pass
    return False


def flush_queue():
    """Rimanda le segnalazioni rimaste in coda (da chiamare in un thread: può metterci un po')."""
    try:
        files = sorted(os.listdir(QUEUE))
    except OSError:
        return
    for n in files:
        p = os.path.join(QUEUE, n)
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, ValueError):
            continue
        if _post(data):
            try:
                os.remove(p)
            except OSError:
                pass
        else:
            return


def mark_running():
    try:
        with open(RUNNING, "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass
    try:
        import faulthandler
        global _fh
        _fh = open(FAULT, "w")
        faulthandler.enable(_fh)
    except Exception:
        pass


def mark_clean_exit():
    try:
        os.remove(RUNNING)
    except OSError:
        pass


def crashed_last_time():
    return os.path.exists(RUNNING)


def dialog(parent, kind=0, text="", tester_name=""):
    """Finestra di segnalazione. Ritorna (nome inserito, inviata) oppure None se annullata."""
    from PySide6.QtCore import QBuffer, QByteArray, QIODevice, Qt
    from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                                   QPlainTextEdit, QPushButton, QVBoxLayout)
    dlg = QDialog(parent)
    dlg.setWindowTitle("Segnala ad Andrea")
    dlg.resize(560, 460)
    v = QVBoxLayout(dlg)
    v.addWidget(QLabel("<b style='font-size:15px'>Cosa vuoi segnalare?</b>"))
    cb = QComboBox()
    cb.addItems(TYPES)
    cb.setCurrentIndex(kind)
    v.addWidget(cb)
    nm = QLineEdit(tester_name)
    nm.setPlaceholderText("Il tuo nome")
    v.addWidget(nm)
    te = QPlainTextEdit(text)
    te.setPlaceholderText("Scrivi qui: cosa stavi facendo, cosa è successo, cosa ti aspettavi.\n"
                          "Se riguarda un punto del video, basta dirlo: il secondo lo ricavo dalle azioni.")
    v.addWidget(te, 1)
    c_act = QCheckBox("Allega le ultime azioni fatte nel programma (aiuta a capire cosa è successo)")
    c_act.setChecked(True)
    c_img = QCheckBox("Allega una foto di questa schermata")
    c_img.setChecked(True)
    v.addWidget(c_act)
    v.addWidget(c_img)
    note = QLabel("" if config.FEEDBACK_URL else
                  "<span style='color:#ff9100'>L'invio non è ancora attivo: la segnalazione resta salvata e "
                  "parte appena Andrea lo attiva.</span>")
    note.setWordWrap(True)
    v.addWidget(note)
    row = QHBoxLayout()
    row.addStretch()
    q = QPushButton("Annulla")
    q.clicked.connect(dlg.reject)
    row.addWidget(q)
    ok = QPushButton("Invia")
    ok.setDefault(True)
    row.addWidget(ok)
    v.addLayout(row)
    shot = None
    if parent is not None:
        try:
            pm = parent.grab().scaledToWidth(1100, Qt.SmoothTransformation)
            ba = QByteArray()
            buf = QBuffer(ba)
            buf.open(QIODevice.WriteOnly)
            pm.save(buf, "JPG", 70)
            shot = base64.b64encode(bytes(ba)).decode()
        except Exception:
            shot = None
    result = {}

    def go():
        t = te.toPlainText().strip()
        if not t:
            QMessageBox.information(dlg, "Segnala", "Scrivi due righe su cosa vuoi segnalare.")
            return
        d = info(c_act.isChecked())
        d.update({"tipo": TYPES[cb.currentIndex()], "nome": nm.text().strip() or "(senza nome)", "testo": t,
                  "data": time.strftime("%Y-%m-%d %H:%M:%S")})
        if c_img.isChecked() and shot:
            d["immagine"] = shot
        result["sent"] = send(d)
        result["name"] = d["nome"]
        dlg.accept()
    ok.clicked.connect(go)
    if dlg.exec() != QDialog.Accepted:
        return None
    QMessageBox.information(parent, "Segnala", "Grazie, segnalazione inviata." if result.get("sent") else
                            "Segnalazione salvata: partirà appena c'è internet (e l'invio è attivo).")
    return result.get("name", ""), result.get("sent", False)
