"""Impostazioni fisse del programma (indirizzi per aggiornamenti e segnalazioni)."""
GITHUB_USER = "andreabertoldi"
GITHUB_REPO = "rifine-tactics-aggiornamenti"
UPDATE_URL = f"https://raw.githubusercontent.com/{GITHUB_USER}/{GITHUB_REPO}/main/update.json"
# indirizzo dello script Google che riceve le segnalazioni (vedi segnalazioni/LEGGIMI.txt); vuoto = non ancora attivo
FEEDBACK_URL = "https://script.google.com/macros/s/AKfycbxbjlASMRmq10tqUK-e34TPEIIPrXNS0ZwLgTNmXMFmw37vFntGz18q3ykcxvj4zIYY4Q/exec"
