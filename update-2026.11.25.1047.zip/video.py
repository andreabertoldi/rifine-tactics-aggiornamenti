"""Lettura video fotogramma per fotogramma con OpenCV."""
import threading
from collections import OrderedDict

import cv2
import cvsafe


def _open(path):
    # niente decodifica hardware: con alcuni video sposta i salti di qualche fotogramma, e per seguire
    # i giocatori ogni fotogramma deve essere quello giusto
    return cv2.VideoCapture(path)


class VideoReader:
    def __init__(self, path):
        self.path = path
        self.cap = _open(path)
        if not self.cap.isOpened():
            raise IOError(f"Impossibile aprire il video:\n{path}")
        fps = self.cap.get(cv2.CAP_PROP_FPS) or 0
        if fps < 1 or fps > 240:
            fps = 25.0
        self.fps = float(fps)
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        n = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        if n <= 0:
            n = self._count_frames()
        self.frame_count = max(1, n)
        self.duration = self.frame_count / self.fps
        self.last_idx = -1
        self.last_frame = None
        # verifica lettura del primo fotogramma
        ok, fr = self.cap.read()
        if not ok or fr is None:
            raise IOError("Il video si apre ma non si riesce a leggere nessun fotogramma (formato non supportato?).")
        self.last_idx, self.last_frame = 0, fr
        if self.width <= 0 or self.height <= 0:
            self.height, self.width = fr.shape[:2]

    def _count_frames(self):
        n = 0
        while self.cap.grab():
            n += 1
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        return n

    def idx_for_time(self, t):
        return max(0, min(self.frame_count - 1, int(round(t * self.fps))))

    def time_for_idx(self, i):
        return i / self.fps

    def frame(self, idx):
        """Ritorna il fotogramma BGR di indice idx (o l'ultimo leggibile)."""
        idx = max(0, min(self.frame_count - 1, int(idx)))
        if idx == self.last_idx and self.last_frame is not None:
            return self.last_frame
        gap = idx - self.last_idx
        if 0 < gap <= 90:
            # avanti di poco: più veloce saltare che fare seek
            for _ in range(gap - 1):
                if not self.cap.grab():
                    break
            ok, fr = self.cap.read()
        else:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ok, fr = self.cap.read()
        if not ok or fr is None:
            # fine file o fotogramma illeggibile: restituisce l'ultimo buono
            if self.last_frame is not None:
                return self.last_frame
            return None
        self.last_idx, self.last_frame = idx, fr
        return fr

    def close(self):
        try:
            self.cap.release()
        except Exception:
            pass


class Prefetcher:
    """Durante la riproduzione decodifica i fotogrammi IN ANTICIPO, in sottofondo, e li prepara già
    alla misura dello schermo: la finestra deve solo mostrarli, così il video non scatta."""

    AHEAD = 24

    def __init__(self, path):
        self.reader = VideoReader(path)
        self.buf = OrderedDict()  # idx -> immagine RGB già ridotta
        self.cond = threading.Condition()
        self.next_idx = None
        self.size = None
        self.step = 1
        self.stop_flag = False
        self.th = threading.Thread(target=self._run, daemon=True)
        self.th.start()

    def start(self, idx, size, step=1):
        with self.cond:
            if self.next_idx is None or not (self.buf and min(self.buf) <= idx <= max(self.buf) + 2) \
                    or size != self.size or step != self.step:
                self.buf.clear()
                self.next_idx = idx
            self.size, self.step = size, step
            self.cond.notify_all()

    def pause(self):
        with self.cond:
            self.next_idx = None
            self.buf.clear()

    def get(self, idx, wait=0.04):
        with self.cond:
            fr = self.buf.get(idx)
            if fr is None and self.next_idx is not None and self.next_idx <= idx <= self.next_idx + 2:
                # sta per arrivare: aspettarlo un attimo costa meno che rileggerlo da capo
                self.cond.wait_for(lambda: idx in self.buf or self.next_idx is None or self.next_idx > idx,
                                   timeout=wait)
                fr = self.buf.get(idx)
            for k in [k for k in self.buf if k < idx]:
                del self.buf[k]
            self.cond.notify_all()
            return fr

    def close(self):
        with self.cond:
            self.stop_flag = True
            self.cond.notify_all()
        self.th.join(timeout=2)
        self.reader.close()

    def _run(self):
        while True:
            with self.cond:
                while not self.stop_flag and (self.next_idx is None or len(self.buf) >= self.AHEAD):
                    self.cond.wait(0.2)
                if self.stop_flag:
                    return
                idx, size, step = self.next_idx, self.size, self.step
            if idx >= self.reader.frame_count:
                with self.cond:
                    self.next_idx = None
                continue
            fr = self.reader.frame(idx)
            if fr is None:
                with self.cond:
                    self.next_idx = None
                continue
            h, w = fr.shape[:2]
            if size and (size[0] < w or size[1] < h):
                fr = cvsafe.resize(fr, size, interpolation=cv2.INTER_LINEAR)
            rgb = cv2.cvtColor(fr, cv2.COLOR_BGR2RGB)
            with self.cond:
                if self.next_idx == idx:  # nel frattempo non è cambiato niente
                    self.buf[idx] = rgb
                    self.next_idx = idx + step
                    self.cond.notify_all()
