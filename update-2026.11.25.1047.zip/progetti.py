"""Progetti: un lavoro con uno o più video, ciascuno con la sua analisi, e la sua raccolta di pezzi.

Ogni progetto è una cartella in ~/Documents/Analisi Video/Progetti/<nome>/ con:
  progetto.json   elenco dei video del progetto
  analisi/        l'analisi di ogni video (disegni, calibrazione, giocatori seguiti)
  video/          i video copiati nel progetto (solo se hai scelto «Copia nel progetto»)
  raccolta.json   i pezzi raccolti per questo progetto
"""
import json
import os
import shutil
import time
import uuid

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QDialog, QHBoxLayout, QHeaderView, QInputDialog, QLabel,
                               QMessageBox, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout)

ROOT = os.path.join(os.path.expanduser("~/Documents"), "Analisi Video", "Progetti")
FILE = "progetto.json"


def safe_name(s):
    s = "".join(c if c.isalnum() or c in " -_.()" else "_" for c in s).strip(" .")
    return s[:80] or "Progetto"


def trash(path):
    """Sposta nel Cestino del Mac (recuperabile)."""
    if not os.path.exists(path):
        return True
    try:
        from Foundation import NSFileManager, NSURL
        ok, _u, _e = NSFileManager.defaultManager().trashItemAtURL_resultingItemURL_error_(
            NSURL.fileURLWithPath_(path), None, None)
        if ok:
            return True
    except Exception:
        pass
    try:
        import subprocess
        p = path.replace('"', '\\"')
        r = subprocess.run(["osascript", "-e", f'tell application "Finder" to delete (POSIX file "{p}")'],
                           capture_output=True, timeout=20)
        return r.returncode == 0
    except Exception:
        return False


class Progetto:
    def __init__(self, folder, data):
        self.dir = folder
        self.name = data.get("name") or os.path.basename(folder)
        self.created = data.get("created", time.time())
        self.updated = data.get("updated", self.created)
        self.videos = list(data.get("videos", []))
        self.last = data.get("last")

    # ---------- file ----------
    @classmethod
    def load(cls, folder):
        with open(os.path.join(folder, FILE), encoding="utf-8") as f:
            return cls(folder, json.load(f))

    @classmethod
    def create(cls, name):
        os.makedirs(ROOT, exist_ok=True)
        base = safe_name(name)
        folder, k = os.path.join(ROOT, base), 2
        while os.path.exists(folder):
            folder = os.path.join(ROOT, f"{base} ({k})")
            k += 1
        os.makedirs(os.path.join(folder, "analisi"))
        p = cls(folder, {"name": name.strip() or base, "created": time.time()})
        p.save()
        return p

    def save(self, touch=True):
        if touch:
            self.updated = time.time()
        d = {"name": self.name, "created": self.created, "updated": self.updated, "videos": self.videos,
             "last": self.last}
        tmp = os.path.join(self.dir, FILE + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        os.replace(tmp, os.path.join(self.dir, FILE))

    @property
    def raccolta_path(self):
        return os.path.join(self.dir, "raccolta.json")

    def n_clips(self):
        try:
            with open(self.raccolta_path, encoding="utf-8") as f:
                return len(json.load(f).get("clips", []))
        except (OSError, ValueError):
            return 0

    # ---------- video ----------
    def video_path(self, e):
        p = e["path"]
        return p if os.path.isabs(p) else os.path.join(self.dir, p)

    def analysis_path(self, e):
        return os.path.join(self.dir, "analisi", e["id"] + ".analisi.json")

    def has_analysis(self, e):
        return os.path.exists(self.analysis_path(e))

    def find(self, path):
        ap = os.path.abspath(path)
        for e in self.videos:
            if os.path.abspath(self.video_path(e)) == ap:
                return e
        return None

    def add(self, path, copied=False):
        """Aggiunge un video (già copiato, se copied, in video/ del progetto). Ritorna la voce."""
        e = self.find(path)
        if e:
            return e
        base = os.path.splitext(os.path.basename(path))[0]
        vid = f"{len(self.videos) + 1:02d}_{safe_name(base)[:40]}_{uuid.uuid4().hex[:4]}"
        rel = os.path.relpath(path, self.dir) if copied else os.path.abspath(path)
        e = {"id": vid, "path": rel, "copied": bool(copied), "name": os.path.basename(path), "added": time.time()}
        self.videos.append(e)
        self.save()
        return e

    def remove(self, e):
        self.videos = [x for x in self.videos if x["id"] != e["id"]]
        if self.last == e["id"]:
            self.last = None
        self.save()

    def rename(self, name):
        self.name = name.strip() or self.name
        self.save()


def copy_target(prog, src, taken=()):
    d = os.path.join(prog.dir, "video")
    os.makedirs(d, exist_ok=True)
    name = os.path.basename(src)
    out, k = os.path.join(d, name), 2
    stem, ext = os.path.splitext(name)
    while os.path.exists(out) or out in taken:
        out = os.path.join(d, f"{stem} ({k}){ext}")
        k += 1
    return out


def copy_files(pairs, progress, cancelled):
    """Copia i video a pezzi (per mostrare l'avanzamento). pairs = [(origine, destinazione)]."""
    from export import Cancelled
    total = sum(os.path.getsize(s) for s, _d in pairs) or 1
    done = 0
    for s, d in pairs:
        try:
            with open(s, "rb") as fi, open(d, "wb") as fo:
                while True:
                    if cancelled():
                        raise Cancelled()
                    b = fi.read(8 << 20)
                    if not b:
                        break
                    fo.write(b)
                    done += len(b)
                    progress(done / total, f"Copio {os.path.basename(s)} nel progetto… "
                             f"{done / 1e9:.1f} di {total / 1e9:.1f} GB")
            shutil.copystat(s, d)
        except BaseException:
            try:
                os.remove(d)
            except OSError:
                pass
            raise
    return pairs


def list_projects():
    out = []
    if not os.path.isdir(ROOT):
        return out
    for n in os.listdir(ROOT):
        f = os.path.join(ROOT, n)
        if os.path.isfile(os.path.join(f, FILE)):
            try:
                out.append(Progetto.load(f))
            except (OSError, ValueError):
                pass
    out.sort(key=lambda p: -p.updated)
    return out


def fmt_date(ts):
    return time.strftime("%d/%m/%Y %H:%M", time.localtime(ts))


def folder_size(folder):
    tot = 0
    for r, _d, fs in os.walk(folder):
        for f in fs:
            try:
                tot += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
    return tot


class ProjectsDialog(QDialog):
    """Finestra iniziale: scegli il lavoro da portare avanti o creane uno nuovo."""

    def __init__(self, parent=None, current=None):
        super().__init__(parent)
        self.setWindowTitle("I tuoi lavori")
        self.resize(760, 460)
        self.chosen = None
        lay = QVBoxLayout(self)
        t = QLabel("<b style='font-size:16px'>Quale lavoro vuoi portare avanti?</b><br>"
                   "Un lavoro (progetto) contiene uno o più video, ognuno con i suoi disegni, la calibrazione e i "
                   "giocatori seguiti, più i pezzi che hai raccolto.")
        t.setWordWrap(True)
        lay.addWidget(t)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Lavoro", "Video", "Pezzi raccolti", "Ultima modifica"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for c in (1, 2, 3):
            self.table.horizontalHeader().setSectionResizeMode(c, QHeaderView.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.cellDoubleClicked.connect(lambda *_: self.open_sel())
        lay.addWidget(self.table, 1)
        self.empty = QLabel("Non hai ancora nessun lavoro: premi «➕ Nuovo lavoro».")
        self.empty.setStyleSheet("color:#8a93a3")
        lay.addWidget(self.empty)
        row = QHBoxLayout()
        b = QPushButton("➕ Nuovo lavoro…")
        b.clicked.connect(self.new)
        row.addWidget(b)
        self.b_open = QPushButton("📂 Apri")
        self.b_open.setDefault(True)
        self.b_open.clicked.connect(self.open_sel)
        row.addWidget(self.b_open)
        b = QPushButton("Rinomina…")
        b.clicked.connect(self.rename)
        row.addWidget(b)
        b = QPushButton("Elimina…")
        b.clicked.connect(self.delete)
        row.addWidget(b)
        row.addStretch()
        b = QPushButton("Chiudi")
        b.clicked.connect(self.reject)
        row.addWidget(b)
        lay.addLayout(row)
        self.current = current
        self.refresh()

    def refresh(self, sel_dir=None):
        self.projects = list_projects()
        self.table.setRowCount(len(self.projects))
        for i, p in enumerate(self.projects):
            name = p.name + ("   (aperto ora)" if self.current and os.path.abspath(self.current) == os.path.abspath(p.dir) else "")
            for c, v in enumerate((name, str(len(p.videos)), str(p.n_clips()), fmt_date(p.updated))):
                it = QTableWidgetItem(v)
                if c:
                    it.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, c, it)
        self.empty.setVisible(not self.projects)
        if self.projects:
            r = 0
            for i, p in enumerate(self.projects):
                if sel_dir and os.path.abspath(p.dir) == os.path.abspath(sel_dir):
                    r = i
            self.table.selectRow(r)

    def _sel(self):
        r = self.table.currentRow()
        return self.projects[r] if 0 <= r < len(self.projects) else None

    def open_sel(self):
        p = self._sel()
        if p:
            self.chosen = p.dir
            self.accept()

    def new(self):
        name, ok = QInputDialog.getText(self, "Nuovo lavoro", "Nome del lavoro (es. «Trento – Lavis 12 ottobre» "
                                        "o «Esercitazioni Under 12»):")
        if not ok or not name.strip():
            return
        try:
            p = Progetto.create(name)
        except OSError as e:
            QMessageBox.critical(self, "Nuovo lavoro", f"Non riesco a creare il lavoro:\n{e}")
            return
        self.chosen = p.dir
        self.accept()

    def rename(self):
        p = self._sel()
        if not p:
            return
        name, ok = QInputDialog.getText(self, "Rinomina", "Nuovo nome:", text=p.name)
        if ok and name.strip():
            p.rename(name)
            self.refresh(p.dir)

    def delete(self):
        p = self._sel()
        if not p:
            return
        if self.current and os.path.abspath(self.current) == os.path.abspath(p.dir):
            QMessageBox.information(self, "Elimina", "Questo lavoro è aperto adesso: apri prima un altro lavoro.")
            return
        copied = [e for e in p.videos if e.get("copied")]
        extra = (f"\n\nDentro ci sono {len(copied)} video copiati nel lavoro: vanno anche loro nel Cestino."
                 if copied else "\n\nI video originali non vengono toccati.")
        r = QMessageBox.question(self, "Elimina lavoro", f"Mettere nel Cestino il lavoro «{p.name}» con le sue "
                                 f"analisi e i pezzi raccolti?{extra}\n\nSi può recuperare dal Cestino.")
        if r != QMessageBox.Yes:
            return
        if not trash(p.dir):
            QMessageBox.warning(self, "Elimina", "Non sono riuscito a metterlo nel Cestino. La cartella è:\n" + p.dir)
        self.refresh()
