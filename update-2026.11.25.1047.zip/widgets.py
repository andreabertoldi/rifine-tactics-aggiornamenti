"""Timeline con eventi e campo da calcio per le posizioni."""
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QSizePolicy, QToolTip, QWidget

from model import fmt_time


class Timeline(QWidget):
    seek = Signal(float)
    cutMenu = Signal(float, object)  # tasto destro su un pezzo tolto

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(54)
        self.setMaximumHeight(54)
        self.setMouseTracking(True)
        self.duration = 0.0
        self.t = 0.0
        self.events = []
        self.drawings = []
        self.colors = {}
        self.selected = set()
        self.cuts = []  # pezzi tolti [inizio, fine]
        self._dragging = False

    def x_for(self, t):
        m = 8
        return m + (self.width() - 2 * m) * (t / self.duration if self.duration else 0)

    def t_for(self, x):
        m = 8
        if not self.duration:
            return 0.0
        return max(0.0, min(self.duration, (x - m) / max(1, self.width() - 2 * m) * self.duration))

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        W, H = self.width(), self.height()
        p.fillRect(self.rect(), QColor("#1a1d23"))
        if not self.duration:
            return
        # binario
        track = QRectF(8, 22, W - 16, 14)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#2b303a"))
        p.drawRoundedRect(track, 4, 4)
        # tacche minuti
        p.setPen(QPen(QColor("#565e6c"), 1))
        f = QFont()
        f.setPointSize(8)
        p.setFont(f)
        step = 60
        for cand in (60, 300, 600, 900):
            if self.duration / cand <= 18:
                step = cand
                break
        else:
            step = 900
        m = 0
        while m <= self.duration:
            x = self.x_for(m)
            p.drawLine(QPointF(x, 38), QPointF(x, 42))
            lx = min(max(x - 20, 0), W - 40)
            p.drawText(QRectF(lx, 41, 40, 12), Qt.AlignCenter, f"{int(m // 60)}'")
            m += step
        # clip degli eventi
        for e in self.events:
            c = QColor(self.colors.get(e["type"], "#bbbbbb"))
            c.setAlpha(110 if e["id"] in self.selected else 45)
            x1, x2 = self.x_for(e["start"]), self.x_for(e["end"])
            p.setPen(Qt.NoPen)
            p.setBrush(c)
            p.drawRect(QRectF(x1, 22, max(2, x2 - x1), 14))
        for e in self.events:
            c = QColor(self.colors.get(e["type"], "#bbbbbb"))
            x = self.x_for(e["t"])
            p.setPen(QPen(c, 3 if e["id"] in self.selected else 2))
            p.drawLine(QPointF(x, 20), QPointF(x, 38))
        # disegni
        p.setPen(Qt.NoPen)
        for d in self.drawings:
            x = self.x_for(d["t"])
            p.setBrush(QColor(d.get("color", "#ffeb3b")))
            path = QPainterPath()
            path.moveTo(x, 8)
            path.lineTo(x + 5, 13)
            path.lineTo(x, 18)
            path.lineTo(x - 5, 13)
            path.closeSubpath()
            p.drawPath(path)
        # pezzi tolti: grigio a righe
        for a, b in self.cuts:
            xa, xb = self.x_for(a), self.x_for(b)
            r = QRectF(xa, 18, max(2, xb - xa), 22)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(10, 10, 12, 210))
            p.drawRect(r)
            p.setBrush(QBrush(QColor(255, 82, 82, 150), Qt.BDiagPattern))
            p.drawRect(r)
        # pezzo da esportare (Inizio / Fine)
        pa, pb = getattr(self, "piece", (None, None))
        if pa is not None or pb is not None:
            xa = self.x_for(pa) if pa is not None else 8
            xb = self.x_for(pb) if pb is not None else self.width() - 8
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(61, 126, 255, 70))
            p.drawRect(QRectF(xa, 18, max(2, xb - xa), 22))
            p.setPen(QPen(QColor("#6d9dff"), 2))
            if pa is not None:
                p.drawLine(QPointF(xa, 14), QPointF(xa, 44))
            if pb is not None:
                p.drawLine(QPointF(xb, 14), QPointF(xb, 44))
        # cursore
        x = self.x_for(self.t)
        p.setPen(QPen(QColor("white"), 2))
        p.drawLine(QPointF(x, 4), QPointF(x, 40))
        p.setBrush(QColor("white"))
        p.setPen(Qt.NoPen)
        p.drawEllipse(QPointF(x, 4), 4, 4)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.RightButton and self.duration:
            t = self.t_for(ev.position().x())
            if any(a <= t < b for a, b in self.cuts):
                self.cutMenu.emit(t, ev.globalPosition().toPoint())
            return
        if ev.button() == Qt.LeftButton and self.duration:
            self._dragging = True
            self.seek.emit(self.t_for(ev.position().x()))

    def mouseMoveEvent(self, ev):
        if self._dragging:
            self.seek.emit(self.t_for(ev.position().x()))
            return
        x = ev.position().x()
        tt = self.t_for(x)
        for a, b in self.cuts:
            if a <= tt < b:
                QToolTip.showText(ev.globalPosition().toPoint(),
                                  f"✂ Pezzo tolto {fmt_time(a)} – {fmt_time(b)} (tasto destro per rimetterlo)", self)
                return
        for e in self.events:
            if abs(self.x_for(e["t"]) - x) < 4:
                QToolTip.showText(ev.globalPosition().toPoint(), f"{fmt_time(e['t'])}  {e['type']}", self)
                return
        QToolTip.hideText()

    def mouseReleaseEvent(self, ev):
        self._dragging = False


class FieldWidget(QWidget):
    """Campo da calcio orizzontale. Noi attacchiamo verso destra."""
    clicked = Signal(float, float)

    def __init__(self, parent=None, interactive=True, compact=False):
        super().__init__(parent)
        self.interactive = interactive
        self.compact = compact
        self.points = []  # [(x, y, color, label, highlight)]
        self.hint = ""
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(200, 130) if compact else self.setMinimumSize(320, 210)
        if interactive:
            self.setCursor(Qt.CrossCursor)

    def field_rect(self):
        W, H = self.width(), self.height()
        top = 16 if not self.compact else 4
        bottom = 4
        avail_h = H - top - bottom
        ratio = 105 / 68
        fw, fh = W - 8, (W - 8) / ratio
        if fh > avail_h:
            fh = avail_h
            fw = fh * ratio
        return QRectF((W - fw) / 2, top + (avail_h - fh) / 2, fw, fh)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#1a1d23"))
        r = self.field_rect()
        p.setPen(Qt.NoPen)
        # strisce d'erba
        for i in range(10):
            p.setBrush(QColor("#2e7d32") if i % 2 == 0 else QColor("#33873a"))
            p.drawRect(QRectF(r.x() + r.width() * i / 10, r.y(), r.width() / 10 + 0.5, r.height()))
        lw = 1.4
        p.setPen(QPen(QColor(255, 255, 255, 210), lw))
        p.setBrush(Qt.NoBrush)
        p.drawRect(r)
        cx = r.center().x()
        p.drawLine(QPointF(cx, r.top()), QPointF(cx, r.bottom()))
        sx, sy = r.width() / 105, r.height() / 68
        p.drawEllipse(r.center(), 9.15 * sx, 9.15 * sy)
        for left in (True, False):
            x0 = r.left() if left else r.right()
            sgn = 1 if left else -1
            pa_w, pa_h = 16.5 * sx, 40.32 * sy
            ga_w, ga_h = 5.5 * sx, 18.32 * sy
            p.drawRect(QRectF(x0 if left else x0 - pa_w, r.center().y() - pa_h / 2, pa_w, pa_h))
            p.drawRect(QRectF(x0 if left else x0 - ga_w, r.center().y() - ga_h / 2, ga_w, ga_h))
            p.drawEllipse(QPointF(x0 + sgn * 11 * sx, r.center().y()), 1.2, 1.2)
            gw = 7.32 * sy
            p.setPen(QPen(QColor(255, 255, 255, 230), 3))
            p.drawLine(QPointF(x0, r.center().y() - gw / 2), QPointF(x0, r.center().y() + gw / 2))
            p.setPen(QPen(QColor(255, 255, 255, 210), lw))
        if not self.compact:
            f = QFont()
            f.setPointSize(9)
            p.setFont(f)
            p.setPen(QColor("#aab3c2"))
            p.drawText(QRectF(0, 0, self.width(), 16), Qt.AlignCenter, "Direzione d'attacco  →")
        # punti
        for x, y, col, label, hl in self.points:
            pt = QPointF(r.x() + x * r.width(), r.y() + y * r.height())
            rad = 6 if not self.compact else 4.5
            if hl:
                rad += 2
            p.setPen(QPen(QColor("white") if hl else QColor(0, 0, 0, 160), 2 if hl else 1))
            p.setBrush(QColor(col))
            p.drawEllipse(pt, rad, rad)
            if label and not self.compact:
                f = QFont()
                f.setPointSize(8)
                f.setBold(True)
                p.setFont(f)
                p.setPen(QColor("white"))
                p.drawText(QRectF(pt.x() - 20, pt.y() - 22, 40, 14), Qt.AlignCenter, label)
        if self.hint:
            f = QFont()
            f.setPointSize(10 if not self.compact else 9)
            f.setBold(True)
            p.setFont(f)
            fm = p.fontMetrics()
            tw = fm.horizontalAdvance(self.hint) + 16
            box = QRectF(r.center().x() - tw / 2, r.bottom() - 26, tw, 22)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 170))
            p.drawRoundedRect(box, 5, 5)
            p.setPen(QColor("#ffeb3b"))
            p.drawText(box, Qt.AlignCenter, self.hint)

    def mousePressEvent(self, ev):
        if not self.interactive or ev.button() != Qt.LeftButton:
            return
        r = self.field_rect()
        pos = ev.position()
        if r.adjusted(-6, -6, 6, 6).contains(pos):
            x = min(1, max(0, (pos.x() - r.x()) / r.width()))
            y = min(1, max(0, (pos.y() - r.y()) / r.height()))
            self.clicked.emit(x, y)
