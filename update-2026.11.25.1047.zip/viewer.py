import time
"""Area video: mostra il fotogramma, i disegni e gestisce gli strumenti di disegno."""
import paths
import math

import cv2
import numpy as np
from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QInputDialog, QSizePolicy, QWidget

from drawing import active_drawings, curve_mid, hit_test, label_hit, paint_drawing, paint_drawings
import cvsafe

MULTI_TOOLS = ("distanza", "collega", "visuale", "palla")


_paint_errors = 0


def _log_paint_error():
    global _paint_errors
    _paint_errors += 1
    if _paint_errors > 20:
        return
    try:
        import os
        import traceback
        f = os.path.join(paths.BASE, "errori_disegno.txt")
        with open(f, "a", encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n" + traceback.format_exc() + "\n")
    except Exception:
        pass


class VideoView(QWidget):
    drawingCreated = Signal(dict)
    drawingSelected = Signal(object)  # id o None
    drawingMoved = Signal(str, int, object)  # id, indice punto (-1 = tutto), spostamento/nuova posizione
    playerClicked = Signal(float, float)  # strumento "evidenzia giocatore"
    coneClicked = Signal(float, float)    # strumento "cono di luce fisso"
    ghostClicked = Signal(float, float)   # strumento "fantasma": primo clic sul giocatore
    multiCreated = Signal(str, list)  # distanza / collega: punti cliccati
    contextRequested = Signal(object, float, float, object)  # id disegno (o None), x, y, posizione globale
    fileDropped = Signal(str)
    drawingDouble = Signal(str)  # doppio clic su un disegno (es. modifica testo)
    scrubbed = Signal(int)  # due dita sul trackpad in orizzontale: avanti/indietro di n fotogrammi

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(480, 270)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.ClickFocus)
        self._img = None
        self._last_bgr = None
        self._src_size = None
        self.t = 0.0
        self.idx = 0
        self.drawings = []
        self.resolver = None
        self.selected_id = None
        self.use_pause = True
        self.hold_ids = set()
        self.tool = None
        self.color = "#ffeb3b"
        self.width_px = 4
        self._temp = None
        self._multi = []  # punti cliccati per distanza/collega
        self._poly = None  # area a punti: {"base": {...}, "pts": [[x, y], ...]} mentre la stai disegnando
        self._mouse = None
        self._drag = None
        self._scrub_acc = 0.0
        self._flash = None
        self._flash_timer = QTimer(self)
        self._flash_timer.setSingleShot(True)
        self._flash_timer.timeout.connect(self._clear_flash)
        self.placeholder = "Trascina qui un video  ·  oppure  ⌘O  per aprirlo"
        self.overlay_hint = ""
        self.mode_badge = None
        self.busy_text = ""
        self.lines_fn = None  # funzione(idx) -> linee del campo calibrate da disegnare (controllo)
        # "chi è?": l'inseguimento non è sicuro e chiede di cliccare il giocatore giusto
        self.perf = None
        self.playing_fn = None
        self.pick = None  # {"boxes": [[x,y,w,h] normalizzati], "color", "text", "cb": funzione(nx, ny)}
        self.lens_on = True  # lente d'ingrandimento quando si deve cliccare un giocatore

    # ---------- immagine ----------
    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        if self._last_bgr is not None:
            self.set_frame(self._last_bgr, self._src_size)

    def set_frame(self, frame_bgr, src_size):
        self._src_size = src_size
        self._last_bgr = frame_bgr
        if frame_bgr is None:
            self._img = None
            self.update()
            return
        dpr = self.devicePixelRatioF()
        target = self.video_rect()
        tw, th = int(target.width() * dpr), int(target.height() * dpr)
        h, w = frame_bgr.shape[:2]
        if tw > 0 and th > 0 and (tw < w or th < h):
            frame_bgr = cvsafe.resize(frame_bgr, (tw, th), interpolation=cv2.INTER_LINEAR)
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        h2, w2 = rgb.shape[:2]
        self._img = QImage(rgb.data, w2, h2, w2 * 3, QImage.Format_RGB888).copy()
        self.update()

    def set_rgb(self, rgb, src_size):
        """Fotogramma già pronto (RGB, già alla misura dello schermo): veloce, per la riproduzione."""
        self._src_size = src_size
        self._last_bgr = None
        h, w = rgb.shape[:2]
        self._img = QImage(rgb.data, w, h, w * 3, QImage.Format_RGB888).copy()
        self.update()

    def clear(self):
        self._img = None
        self._last_bgr = None
        self._src_size = None
        self.update()

    def video_rect(self):
        if not self._src_size:
            return QRectF(self.rect())
        w, h = self._src_size
        W, H = self.width(), self.height()
        s = min(W / w, H / h)
        vw, vh = w * s, h * s
        return QRectF((W - vw) / 2, (H - vh) / 2, vw, vh)

    def to_norm(self, pos):
        r = self.video_rect()
        return [min(1.0, max(0.0, (pos.x() - r.x()) / r.width())),
                min(1.0, max(0.0, (pos.y() - r.y()) / r.height()))]

    def to_widget(self, n):
        r = self.video_rect()
        return QPointF(r.x() + n[0] * r.width(), r.y() + n[1] * r.height())

    def flash(self, text, color="#2ecc71", ms=1200):
        self._flash = (text, color)
        self._flash_timer.start(ms)
        self.update()

    def _clear_flash(self):
        self._flash = None
        self.update()

    def cancel_multi(self):
        self._multi = []
        self._poly = None

    def _finish_poly(self):
        """Chiude l'area a punti: i punti cliccati vengono uniti da linee dritte."""
        po = self._poly
        self._poly = None
        if po and len(po["pts"]) >= 3:
            self.drawingCreated.emit(dict(po["base"], points=[list(q) for q in po["pts"]], straight=True))
        self.update()
        self.update()

    def _resolved(self, d):
        if self.resolver is not None and (d.get("anchors") or d.get("ground") or d.get("kind") in ("spotlight", "fantasma")):
            return self.resolver(d, self.idx)
        return d

    # ---------- disegno ----------
    def paintEvent(self, ev):
        t0 = time.perf_counter()
        try:
            self._paint(ev)
        except Exception:
            # un errore mentre si disegna lascerebbe il «pennello» aperto e farebbe chiudere il programma:
            # lo registro e vado avanti (al massimo manca un disegno in questo fotogramma)
            _log_paint_error()
        if self.perf is not None and self.playing_fn and self.playing_fn():
            self.perf.add("disegno finestra (con disegni e numeri)", time.perf_counter() - t0)

    def _paint(self, ev):
        p = QPainter(self)
        try:
            self._paint_body(p)
        finally:
            if p.isActive():
                p.end()

    def _paint_body(self, p):
        p.fillRect(self.rect(), QColor("#111317"))
        if self._img is None:
            p.setPen(QColor("#8a93a3"))
            f = QFont()
            f.setPointSize(15)
            p.setFont(f)
            p.drawText(self.rect(), Qt.AlignCenter, self.placeholder)
            return
        r = self.video_rect()
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.drawImage(r, self._img)
        if self.lines_fn is not None:
            lines = self.lines_fn(self.idx)
            if lines is None:
                p.setPen(QColor("#ffb74d"))
                f = QFont()
                f.setPointSize(11)
                p.setFont(f)
                p.drawText(QRectF(r.x() + 10, r.y() + 8, r.width() - 20, 22), Qt.AlignLeft,
                           "📐 qui il campo non è riconosciuto: calibra anche su questa scena")
            else:
                p.setRenderHint(QPainter.Antialiasing, True)
                p.setPen(QPen(QColor(0, 230, 255, 200), 2))
                for seg in lines:
                    pts = [self.to_widget(q) for q in seg]
                    for a_, b_ in zip(pts, pts[1:]):
                        p.drawLine(a_, b_)
        paint_drawings(p, r, self.drawings, self.t, self.use_pause, self.selected_id, force_full=self.hold_ids,
                       resolver=self.resolver, idx=self.idx)
        if self._temp:
            paint_drawing(p, r, self._temp, 1.0)
        if self._poly and self.tool != "area":
            self._poly = None
        if self._poly:
            pts = [self.to_widget(q) for q in self._poly["pts"]]
            col = QColor(self._poly["base"]["color"])
            p.setRenderHint(QPainter.Antialiasing, True)
            if len(pts) >= 3:
                prev = dict(self._poly["base"], points=self._poly["pts"] +
                            ([self.to_norm(self._mouse)] if self._mouse is not None else []), hatch=True)
                paint_drawing(p, r, prev, 0.6)
            else:
                p.setPen(QPen(col, 2))
                for a, b in zip(pts, pts[1:]):
                    p.drawLine(a, b)
                if self._mouse is not None:
                    p.setPen(QPen(col, 2, Qt.DashLine))
                    p.drawLine(pts[-1], self._mouse)
            for k, q in enumerate(pts):
                p.setPen(QPen(QColor(0, 0, 0, 200), 1.5))
                p.setBrush(QColor("#ffffff") if k else col)
                p.drawEllipse(q, 7 if k == 0 else 4.5, 7 if k == 0 else 4.5)
            self._paint_banner(p, r, "⬠ Clicca i punti dell'area · doppio clic, Invio o clic sul primo punto per "
                                     "chiudere · Esc annulla", col)
        if self._multi:
            pts = list(self._multi)
            if self._mouse is not None:
                pts.append(self.to_norm(self._mouse))
            tmp = {"kind": "collega", "points": pts, "color": self.color, "width": self.width_px}
            paint_drawing(p, r, tmp, 0.8)
        if self.pick:
            p.setRenderHint(QPainter.Antialiasing, True)
            col = QColor(self.pick.get("color", "#ffeb3b"))
            f = QFont()
            f.setBold(True)
            f.setPointSize(13)
            p.setFont(f)
            for k, bx in enumerate(self.pick.get("boxes") or [] if self.pick.get("idx") == self.idx else []):
                tl = self.to_widget((bx[0], bx[1]))
                br = self.to_widget((bx[0] + bx[2], bx[1] + bx[3]))
                rr = QRectF(tl, br).adjusted(-5, -5, 5, 5)
                p.setBrush(Qt.NoBrush)
                p.setPen(QPen(QColor(0, 0, 0, 170), 5))
                p.drawRoundedRect(rr, 6, 6)
                p.setPen(QPen(col, 2.5, Qt.DashLine))
                p.drawRoundedRect(rr, 6, 6)
                lab = QRectF(rr.center().x() - 12, rr.top() - 28, 24, 22)
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(0, 0, 0, 200))
                p.drawRoundedRect(lab, 5, 5)
                p.setPen(col)
                p.drawText(lab, Qt.AlignCenter, "?")
            self._paint_banner(p, r, self.pick.get("text", ""), self.pick.get("color", "#ffeb3b"), top=False)
        if self._lens_active():
            self._paint_lens(p, r)
        if self._flash:
            self._paint_banner(p, r, self._flash[0], self._flash[1])
        if self.busy_text:
            self._paint_banner(p, r, self.busy_text, "#3d7eff", top=False)
        if self.mode_badge and self._img is not None:
            f = QFont()
            f.setPointSize(11)
            f.setBold(True)
            p.setFont(f)
            fm = p.fontMetrics()
            txt, col = self.mode_badge
            box = QRectF(r.left() + 10, r.bottom() - 36, fm.horizontalAdvance(txt) + 20, 26)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 140))
            p.drawRoundedRect(box, 6, 6)
            p.setPen(QColor(col))
            p.drawText(box, Qt.AlignCenter, txt)
        if self.overlay_hint:
            f = QFont()
            f.setPointSize(11)
            p.setFont(f)
            fm = p.fontMetrics()
            tw = fm.horizontalAdvance(self.overlay_hint) + 20
            box = QRectF(r.right() - tw - 10, r.bottom() - 34, tw, 26)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 150))
            p.drawRoundedRect(box, 6, 6)
            p.setPen(QColor("#e8edf5"))
            p.drawText(box, Qt.AlignCenter, self.overlay_hint)
        if self.tool:
            p.setPen(QPen(QColor(self.color), 2))
            p.setBrush(Qt.NoBrush)
            p.drawRect(r.adjusted(1, 1, -1, -1))

    def _paint_banner(self, p, r, text, col, top=True):
        f = QFont()
        f.setBold(True)
        f.setPointSize(16)
        p.setFont(f)
        fm = p.fontMetrics()
        tw = fm.horizontalAdvance(text) + 36
        y = r.y() + 18 if top else r.bottom() - 60
        box = QRectF(r.center().x() - tw / 2, y, tw, 42)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(0, 0, 0, 190))
        p.drawRoundedRect(box, 9, 9)
        p.setBrush(QColor(col))
        p.drawRoundedRect(QRectF(box.x(), box.y(), 7, box.height()), 3, 3)
        p.setPen(QColor("white"))
        p.drawText(box, Qt.AlignCenter, text)

    # ---------- mouse ----------
    def wheelEvent(self, ev):
        """Due dita in orizzontale sul video: scorre i fotogrammi (come la linea del tempo, il video segue le dita)."""
        if self._temp or self._multi or self._poly or self._drag is not None:
            ev.ignore()   # mentre disegni non ti sposti per sbaglio
            return
        pd = ev.pixelDelta()
        dx, dy = (pd.x(), pd.y()) if not pd.isNull() else (ev.angleDelta().x() / 4, ev.angleDelta().y() / 4)
        if abs(dx) <= abs(dy) * 1.2:
            ev.ignore()
            return
        self._scrub_acc -= dx / 6.0      # 6 pixel di scorrimento = 1 fotogramma
        n = int(self._scrub_acc)
        if n:
            self._scrub_acc -= n
            self.scrubbed.emit(n)
        ev.accept()

    def mousePressEvent(self, ev):
        if self._img is None:
            return super().mousePressEvent(ev)
        pos = ev.position()
        if self.tool in MULTI_TOOLS and ev.button() == Qt.RightButton:
            self._finish_multi()
            return
        if self._poly and ev.button() == Qt.RightButton:
            self._finish_poly()
            return
        if self._poly and ev.button() == Qt.LeftButton and self.tool == "area" and self.video_rect().contains(pos):
            first = self.to_widget(self._poly["pts"][0])
            if len(self._poly["pts"]) >= 3 and math.hypot(first.x() - pos.x(), first.y() - pos.y()) < 14:
                self._finish_poly()
            else:
                self._poly["pts"].append(self.to_norm(pos))
                self.update()
            return
        if ev.button() == Qt.RightButton and self.video_rect().contains(pos):
            n = self.to_norm(pos)
            hit = None
            r = self.video_rect()
            for d, _a in reversed(active_drawings(self.drawings, self.t, self.use_pause)):
                rd = self._resolved(d)
                if rd is not None and hit_test(rd, r, pos):
                    hit = d["id"]
                    break
            self.contextRequested.emit(hit, n[0], n[1], ev.globalPosition().toPoint())
            return
        if ev.button() != Qt.LeftButton or not self.video_rect().contains(pos):
            return
        n = self.to_norm(pos)
        if self.pick:
            self.pick["cb"](n[0], n[1])
            return
        if self.tool == "spotlight":
            self.playerClicked.emit(n[0], n[1])
            return
        if self.tool == "cono":
            self.coneClicked.emit(n[0], n[1])
            return
        if self.tool == "fantasma":
            self.ghostClicked.emit(n[0], n[1])
            return
        if self.tool in MULTI_TOOLS:
            self._multi.append(n)
            if self.tool == "palla" or (self.tool in ("distanza", "visuale") and len(self._multi) >= 2):
                self._finish_multi()
            self.update()
            return
        if self.tool:
            base = {"kind": self.tool, "color": self.color, "width": self.width_px, "t": round(self.t, 3)}
            if self.tool == "testo":
                from textdlg import TextDialog
                dlg = TextDialog(self, color=self.color, d=dict(getattr(self, "text_defaults", {}) or {}))
                if dlg.exec() and dlg.values()["text"].strip():
                    v = dlg.values()
                    self.text_defaults = {k: v[k] for k in ("font", "fsize", "bold", "italic", "bg", "ground")}
                    self.drawingCreated.emit(dict(base, points=[n], **v))
                return
            self._temp = dict(base, points=[n] if self.tool in ("mano", "area") else
                              [n, n, n] if self.tool == "curva" else [n, n])
            self.update()
            return
        # selezione / spostamento
        r = self.video_rect()
        for d, _a in reversed(active_drawings(self.drawings, self.t, self.use_pause)):
            rd = self._resolved(d)
            key = label_hit(rd, r, pos) if rd is not None else None
            if key:
                # scritta spostabile: la trascini dove vuoi, poi resta lì rispetto al disegno
                self.selected_id = d["id"]
                off = (d.get("lab_off") or {}).get(key) or [0.0, 0.0]
                self._drag = {"id": d["id"], "label": key, "start": n, "orig": list(off), "moved": False}
                self.drawingSelected.emit(d["id"])
                self.update()
                return
        for d, _a in reversed(active_drawings(self.drawings, self.t, self.use_pause)):
            rd = self._resolved(d)
            if rd is None or not hit_test(rd, r, pos):
                continue
            self.selected_id = d["id"]
            point_i = -1
            if d.get("anchors"):
                best = 1e9
                for i, q in enumerate(rd["points"]):
                    dist = math.hypot(self.to_widget(q).x() - pos.x(), self.to_widget(q).y() - pos.y())
                    if dist < best:
                        best, point_i = dist, i
                if d["kind"] == "spotlight":
                    point_i = 0
                elif best > 22:
                    point_i = -1
            elif d["kind"] == "curva" and len(rd["points"]) >= 3:
                q = self.to_widget(rd["points"][1])
                if math.hypot(q.x() - pos.x(), q.y() - pos.y()) < 16:
                    point_i = 1  # il pallino in mezzo: cambia quanto curva
            self._drag = {"id": d["id"], "start": n, "i": point_i, "orig": [list(p) for p in d["points"]],
                          "res": [list(p) for p in rd["points"]], "moved": False}
            self.drawingSelected.emit(d["id"])
            self.update()
            return
        if self.selected_id:
            self.selected_id = None
            self.drawingSelected.emit(None)
            self.update()

    def mouseDoubleClickEvent(self, ev):
        if self.tool == "collega":
            self._finish_multi()
            return
        if self._poly:
            self._finish_poly()
            return
        pos = ev.position()
        if ev.button() == Qt.LeftButton and self.video_rect().contains(pos):
            r = self.video_rect()
            for d, _a in reversed(active_drawings(self.drawings, self.t, self.use_pause)):
                rd = self._resolved(d)
                if rd is not None and hit_test(rd, r, pos):
                    self.drawingDouble.emit(d["id"])
                    return
        super().mouseDoubleClickEvent(ev)

    def _finish_multi(self):
        pts = self._multi
        self._multi = []
        need = 1 if self.tool == "palla" else 2
        if len(pts) >= need:
            # doppio clic aggiunge due volte l'ultimo punto: toglie i doppioni
            clean = [pts[0]]
            for q in pts[1:]:
                if abs(q[0] - clean[-1][0]) + abs(q[1] - clean[-1][1]) > 0.004:
                    clean.append(q)
            if len(clean) >= need:
                self.multiCreated.emit(self.tool, clean)
        self.update()

    # ---------- lente ----------
    def _lens_active(self):
        if not self.lens_on or self._img is None or self._mouse is None or self._drag is not None:
            return False
        if not (self.pick or self.tool in ("spotlight", "distanza", "collega", "visuale", "palla", "fantasma")):
            return False
        return self.video_rect().contains(self._mouse)

    def _paint_lens(self, p, r):
        """Cerchio con il video ingrandito 3 volte attorno al puntatore, per cliccare il giocatore giusto."""
        R, zoom = 105.0, 3.0
        m = self._mouse
        n = self.to_norm(m)
        if self._last_bgr is not None:
            src = self._last_bgr
            sh, sw = src.shape[:2]
            half = R / zoom * sw / max(1.0, r.width())
            cx, cy = n[0] * sw, n[1] * sh
            x0, y0 = int(round(cx - half)), int(round(cy - half))
            side = max(2, int(round(2 * half)))
            crop = np.zeros((side, side, 3), np.uint8)
            xa, ya, xb, yb = max(0, x0), max(0, y0), min(sw, x0 + side), min(sh, y0 + side)
            if xb > xa and yb > ya:
                crop[ya - y0:yb - y0, xa - x0:xb - x0] = src[ya:yb, xa:xb]
            rgb = np.ascontiguousarray(crop[:, :, ::-1])
            img = QImage(rgb.data, side, side, side * 3, QImage.Format_RGB888).copy()
        else:
            iw, ih = self._img.width(), self._img.height()
            half = R / zoom * iw / max(1.0, r.width())
            img = self._img.copy(int(n[0] * iw - half), int(n[1] * ih - half), int(2 * half), int(2 * half))
        # la lente sta sopra a destra del puntatore; si sposta se esce dal video
        c = QPointF(m.x() + R + 30, m.y() - R - 30)
        if c.x() + R > r.right():
            c.setX(m.x() - R - 30)
        if c.y() - R < r.top():
            c.setY(m.y() + R + 30)
        box = QRectF(c.x() - R, c.y() - R, 2 * R, 2 * R)
        p.save()
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        clip = QPainterPath()
        clip.addEllipse(box)
        p.setClipPath(clip)
        p.drawImage(box, img)
        p.setClipping(False)
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(0, 0, 0, 200), 5))
        p.drawEllipse(box)
        p.setPen(QPen(QColor("#ffffff"), 2))
        p.drawEllipse(box)
        # mirino al centro: è il punto che clicchi
        for col, wd in ((QColor(0, 0, 0, 220), 3.5), (QColor("#00e5ff"), 1.5)):
            p.setPen(QPen(col, wd))
            p.drawLine(QPointF(c.x() - 14, c.y()), QPointF(c.x() - 4, c.y()))
            p.drawLine(QPointF(c.x() + 4, c.y()), QPointF(c.x() + 14, c.y()))
            p.drawLine(QPointF(c.x(), c.y() - 14), QPointF(c.x(), c.y() - 4))
            p.drawLine(QPointF(c.x(), c.y() + 4), QPointF(c.x(), c.y() + 14))
        p.restore()

    def leaveEvent(self, ev):
        self._mouse = None
        self.update()
        super().leaveEvent(ev)

    def mouseMoveEvent(self, ev):
        pos = ev.position()
        self._mouse = pos
        if self._poly or (self.lens_on and (self.pick or self.tool in ("spotlight", "distanza", "collega", "visuale", "palla", "fantasma"))):
            self.update()
        if self._temp is not None:
            n = self.to_norm(pos)
            if self._temp["kind"] in ("mano", "area"):
                last = self._temp["points"][-1]
                if abs(last[0] - n[0]) + abs(last[1] - n[1]) > 0.003:
                    self._temp["points"].append(n)
            elif self._temp["kind"] == "curva":
                a = self._temp["points"][0]
                self._temp["points"] = [a, curve_mid(a, n), n]
            else:
                self._temp["points"][-1] = n
            self.update()
        elif self._drag is not None and self._drag.get("label"):
            dr = self._drag
            n = self.to_norm(pos)
            dx, dy = n[0] - dr["start"][0], n[1] - dr["start"][1]
            dr["moved"] = dr["moved"] or abs(dx) + abs(dy) > 0.002
            for d in self.drawings:
                if d["id"] == dr["id"]:
                    lo = dict(d.get("lab_off") or {})
                    lo[dr["label"]] = [dr["orig"][0] + dx, dr["orig"][1] + dy]
                    d["lab_off"] = lo
            self.update()
        elif self._drag is not None:
            dr = self._drag
            n = self.to_norm(pos)
            dx, dy = n[0] - dr["start"][0], n[1] - dr["start"][1]
            dr["moved"] = abs(dx) + abs(dy) > 0.002
            for d in self.drawings:
                if d["id"] != dr["id"]:
                    continue
                if not d.get("anchors"):
                    if dr["i"] >= 0:
                        pts = [list(p) for p in dr["orig"]]
                        pts[dr["i"]] = [min(1, max(0, pts[dr["i"]][0] + dx)), min(1, max(0, pts[dr["i"]][1] + dy))]
                        d["points"] = pts
                    else:
                        d["points"] = [[min(1, max(0, x + dx)), min(1, max(0, y + dy))] for x, y in dr["orig"]]
                else:
                    # anteprima: disegno temporaneo nelle posizioni spostate
                    pts = [list(p) for p in dr["res"]]
                    if dr["i"] >= 0:
                        pts[dr["i"]] = [pts[dr["i"]][0] + dx, pts[dr["i"]][1] + dy]
                    else:
                        pts = [[x + dx, y + dy] for x, y in pts]
                    self._temp = dict(d, points=pts, anchors=None, _trail=None, _labels=[])
            self.update()
        else:
            if self.tool:
                self.setCursor(Qt.CrossCursor)
            else:
                self.unsetCursor()
            if self._multi:
                self.update()

    def mouseReleaseEvent(self, ev):
        if self._temp is not None and self._drag is None:
            d = self._temp
            self._temp = None
            pts = d["points"]
            big = len(pts) >= 2 and (abs(pts[0][0] - pts[-1][0]) + abs(pts[0][1] - pts[-1][1]) > 0.008 or len(pts) > 3)
            if d["kind"] == "area" and len(pts) <= 3:
                # un clic senza trascinare: area a punti (clicchi gli angoli, linee dritte)
                base = {k: v for k, v in d.items() if k != "points"}
                self._poly = {"base": base, "pts": [list(pts[0])]}
            elif big:
                self.drawingCreated.emit(d)
            self.update()
        elif self._drag is not None and self._drag.get("label"):
            dr = self._drag
            self._drag = None
            if dr["moved"]:
                self.drawingMoved.emit(dr["id"], -2, {})   # -2 = spostata solo una scritta
            self.update()
        elif self._drag is not None:
            dr = self._drag
            self._drag = None
            self._temp = None
            if dr["moved"]:
                n = self.to_norm(ev.position())
                delta = [n[0] - dr["start"][0], n[1] - dr["start"][1]]
                self.drawingMoved.emit(dr["id"], dr["i"], {"delta": delta, "res": dr["res"]})
            self.update()

    # ---------- drag & drop ----------
    def dragEnterEvent(self, ev):
        if ev.mimeData().hasUrls():
            ev.acceptProposedAction()

    def dropEvent(self, ev):
        urls = ev.mimeData().urls()
        if urls:
            self.fileDropped.emit(urls[0].toLocalFile())
