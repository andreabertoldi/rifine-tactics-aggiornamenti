"""Traiettoria della palla: parte da un clic sulla palla e la segue fotogramma per fotogramma.

Il rilevatore (YOLOX, classe «pallone») cerca la palla solo in un riquadro attorno a dove dovrebbe essere
(ultima posizione + velocità), ingrandito: così la trova anche se è piccola e non la confonde con i palloni
di riserva a bordo campo. Se la perde per qualche fotogramma allarga il riquadro; se la perde troppo a lungo
si ferma (nei contrasti, quando è tra i piedi, succede: si riprende con un altro clic).
Stessa interfaccia degli altri inseguimenti: manda blocchi {fotogramma: [x, y, altezza, conf]} (0-1).
"""
import os

import cv2
import numpy as np
from PySide6.QtCore import QObject, Signal, Slot

import tracking
from video import VideoReader

BALL = 32          # classe «sports ball» del rilevatore
MAX_MISS = 12      # fotogrammi di fila senza palla prima di fermarsi
S = 640


class _Net:
    _inst = None

    @classmethod
    def get(cls):
        if cls._inst is None:
            cls._inst = cls()
        return cls._inst

    def __init__(self):
        path = tracking.MODEL_PATH
        if not path or "yolox" not in os.path.basename(path):
            raise RuntimeError("serve il rilevatore YOLOX (yolox_s.onnx) nella cartella models")
        self.net = cv2.dnn.readNetFromONNX(path)
        g, st = [], []
        for s in (8, 16, 32):
            n = S // s
            yv, xv = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
            g.append(np.stack([xv, yv], 2).reshape(-1, 2))
            st.append(np.full((n * n, 1), s))
        self.grid = np.concatenate(g).astype(np.float32)
        self.stride = np.concatenate(st).astype(np.float32)

    def balls(self, img, conf=0.08):
        """Palloni nel ritaglio: [(x, y, diametro, punteggio)] in pixel del ritaglio."""
        h, w = img.shape[:2]
        r = min(S / h, S / w)
        can = np.full((S, S, 3), 114, np.uint8)
        can[:int(h * r), :int(w * r)] = cv2.resize(img, (int(w * r), int(h * r)))
        self.net.setInput(cv2.dnn.blobFromImage(can.astype(np.float32), 1.0, (S, S), swapRB=False))
        o = self.net.forward()[0]
        xy = (o[:, :2] + self.grid) * self.stride
        wh = np.exp(o[:, 2:4]) * self.stride
        sc = o[:, 4] * o[:, 5 + BALL]
        m = sc > conf
        return [(float(x / r), float(y / r), float(d / r), float(s))
                for (x, y), (d, _h), s in zip(xy[m], wh[m], sc[m])]


class BallWorker(QObject):
    batch = Signal(str, object, bool, str)

    def __init__(self, vpath, tid, start, p, limit_frames):
        super().__init__()
        self.vpath, self.tid, self.start, self.p, self.limit = vpath, tid, start, p, limit_frames
        self._stop = False

    def stop(self):
        self._stop = True

    @Slot()
    def run(self):
        rd = None
        reason = "end"
        try:
            net = _Net.get()
            rd = VideoReader(self.vpath)
            W, H = rd.width, rd.height
            k1 = min(rd.frame_count - 1, self.start + self.limit)
            p = np.array(self.p, float)
            v = np.zeros(2)
            miss = 0
            buf = {}
            for k in range(self.start + 1, k1 + 1):
                if self._stop:
                    reason = "stop"
                    break
                f = rd.frame(k)
                if f is None:
                    break
                q = p + v
                R = int(110 + 40 * min(miss, 4))
                x0 = int(min(max(0, q[0] - R), W - 2 * R))
                y0 = int(min(max(0, q[1] - R), H - 2 * R))
                c = f[y0:y0 + 2 * R, x0:x0 + 2 * R]
                ds = [(x + x0, y + y0, s) for x, y, dd, s in net.balls(c) if dd < 40]
                best = None
                if ds:
                    best = min(ds, key=lambda t: np.hypot(t[0] - q[0], t[1] - q[1]) / (0.3 + t[2]))
                    if np.hypot(best[0] - q[0], best[1] - q[1]) > min(R, 45 + 35 * miss):
                        best = None
                if best:
                    v = 0.5 * v + 0.5 * (np.array(best[:2]) - p) / (miss + 1)
                    p = np.array(best[:2])
                    miss = 0
                    buf[k] = [float(p[0] / W), float(p[1] / H), 0.012, float(best[2])]
                else:
                    miss += 1
                    p = q
                    if miss > MAX_MISS:
                        reason = "lost"
                        break
                if len(buf) >= 5:
                    self.batch.emit(self.tid, buf, False, "")
                    buf = {}
            if buf:
                self.batch.emit(self.tid, buf, False, "")
            self.batch.emit(self.tid, {}, True, reason)
        except Exception as e:  # noqa
            self.batch.emit(self.tid, {}, True, "errore: " + str(e))
        finally:
            if rd is not None:
                rd.close()
