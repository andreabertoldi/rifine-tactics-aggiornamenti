"""Finestre di dialogo: pannello di tagging, modifica evento, opzioni di esportazione."""
import copy

from PySide6.QtCore import QObject, QThread, Qt, Signal, Slot
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QColorDialog, QComboBox, QDialog,
                               QDialogButtonBox, QDoubleSpinBox, QFormLayout, QGroupBox, QHBoxLayout,
                               QHeaderView, QLabel, QLineEdit, QPushButton, QRadioButton, QSpinBox,
                               QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from export import PRESETS


class PanelDialog(QDialog):
    """Modifica eventi (nome, tasto, colore, secondi prima/dopo), rosa e nomi squadre."""

    def __init__(self, project, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pannello di tagging e rosa")
        self.resize(640, 520)
        self.project = project
        lay = QVBoxLayout(self)
        tabs = QTabWidget()
        lay.addWidget(tabs)

        # --- eventi
        w1 = QWidget()
        l1 = QVBoxLayout(w1)
        l1.addWidget(QLabel("Ogni riga è un pulsante. Il tasto è la scorciatoia da tastiera (una lettera).\n"
                            "«Prima» e «Dopo» sono i secondi di video salvati attorno al momento taggato."))
        self.ev_table = QTableWidget(0, 5)
        self.ev_table.setHorizontalHeaderLabels(["Evento", "Tasto", "Colore", "Prima (s)", "Dopo (s)"])
        self.ev_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.ev_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ev_table.cellDoubleClicked.connect(self._pick_color)
        for et in project.event_types:
            self._add_ev_row(et)
        l1.addWidget(self.ev_table)
        hb = QHBoxLayout()
        b_add = QPushButton("+ Aggiungi evento")
        b_add.clicked.connect(lambda: self._add_ev_row({"name": "Nuovo evento", "key": "", "color": "#ffffff",
                                                          "pre": 5, "post": 5}))
        b_del = QPushButton("– Rimuovi selezionato")
        b_del.clicked.connect(lambda: self._del_rows(self.ev_table))
        b_up = QPushButton("↑")
        b_up.clicked.connect(lambda: self._move(-1))
        b_dn = QPushButton("↓")
        b_dn.clicked.connect(lambda: self._move(1))
        for b in (b_add, b_del, b_up, b_dn):
            hb.addWidget(b)
        hb.addStretch()
        l1.addLayout(hb)
        l1.addWidget(QLabel("Doppio clic sul colore per cambiarlo."))
        tabs.addTab(w1, "Eventi")

        # --- rosa
        w2 = QWidget()
        l2 = QVBoxLayout(w2)
        form = QFormLayout()
        self.home_name = QLineEdit(project.teams.get("home", "Noi"))
        self.away_name = QLineEdit(project.teams.get("away", "Avversari"))
        form.addRow("Nome nostra squadra:", self.home_name)
        form.addRow("Nome avversari:", self.away_name)
        l2.addLayout(form)
        l2.addWidget(QLabel("Rosa (durante il tagging digita il numero di maglia per selezionare il giocatore):"))
        self.ro_table = QTableWidget(0, 2)
        self.ro_table.setHorizontalHeaderLabels(["Numero", "Nome"])
        self.ro_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        for pl in sorted(project.roster, key=lambda x: int(x["num"])):
            self._add_ro_row(pl)
        l2.addWidget(self.ro_table)
        hb2 = QHBoxLayout()
        b_add2 = QPushButton("+ Aggiungi giocatore")
        b_add2.clicked.connect(lambda: self._add_ro_row({"num": self._next_num(), "name": ""}))
        b_del2 = QPushButton("– Rimuovi selezionato")
        b_del2.clicked.connect(lambda: self._del_rows(self.ro_table))
        hb2.addWidget(b_add2)
        hb2.addWidget(b_del2)
        hb2.addStretch()
        l2.addLayout(hb2)
        tabs.addTab(w2, "Rosa e squadre")

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Salva")
        bb.button(QDialogButtonBox.Cancel).setText("Annulla")
        bb.accepted.connect(self._accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _add_ev_row(self, et):
        r = self.ev_table.rowCount()
        self.ev_table.insertRow(r)
        self.ev_table.setItem(r, 0, QTableWidgetItem(et["name"]))
        self.ev_table.setItem(r, 1, QTableWidgetItem(et.get("key", "")))
        ci = QTableWidgetItem(et["color"])
        ci.setBackground(QColor(et["color"]))
        ci.setFlags(ci.flags() & ~Qt.ItemIsEditable)
        self.ev_table.setItem(r, 2, ci)
        for c, k in ((3, "pre"), (4, "post")):
            sp = QDoubleSpinBox()
            sp.setRange(0, 120)
            sp.setDecimals(0)
            sp.setValue(float(et.get(k, 5)))
            self.ev_table.setCellWidget(r, c, sp)

    def _pick_color(self, r, c):
        if c != 2:
            return
        item = self.ev_table.item(r, 2)
        col = QColorDialog.getColor(QColor(item.text()), self, "Colore evento")
        if col.isValid():
            item.setText(col.name())
            item.setBackground(col)

    def _move(self, delta):
        r = self.ev_table.currentRow()
        r2 = r + delta
        if r < 0 or r2 < 0 or r2 >= self.ev_table.rowCount():
            return
        rows = self._ev_rows()
        rows[r], rows[r2] = rows[r2], rows[r]
        self.ev_table.setRowCount(0)
        for et in rows:
            self._add_ev_row(et)
        self.ev_table.selectRow(r2)

    def _next_num(self):
        nums = [int(self.ro_table.item(i, 0).text()) for i in range(self.ro_table.rowCount())
                if self.ro_table.item(i, 0) and self.ro_table.item(i, 0).text().isdigit()]
        return (max(nums) + 1) if nums else 1

    def _add_ro_row(self, pl):
        r = self.ro_table.rowCount()
        self.ro_table.insertRow(r)
        self.ro_table.setItem(r, 0, QTableWidgetItem(str(pl["num"])))
        self.ro_table.setItem(r, 1, QTableWidgetItem(pl.get("name", "")))

    def _del_rows(self, table):
        rows = sorted({i.row() for i in table.selectedIndexes()}, reverse=True)
        if not rows and table.currentRow() >= 0:
            rows = [table.currentRow()]
        for r in rows:
            table.removeRow(r)

    def _ev_rows(self):
        out = []
        for r in range(self.ev_table.rowCount()):
            name = (self.ev_table.item(r, 0).text() if self.ev_table.item(r, 0) else "").strip()
            if not name:
                continue
            key = (self.ev_table.item(r, 1).text() if self.ev_table.item(r, 1) else "").strip().upper()[:1]
            out.append({"name": name, "key": key, "color": self.ev_table.item(r, 2).text(),
                        "pre": self.ev_table.cellWidget(r, 3).value(),
                        "post": self.ev_table.cellWidget(r, 4).value()})
        return out

    def _accept(self):
        ets = self._ev_rows()
        keys = [e["key"] for e in ets if e["key"]]
        dup = {k for k in keys if keys.count(k) > 1}
        bad = [k for k in keys if not k.isalpha()]
        from PySide6.QtWidgets import QMessageBox
        if dup:
            QMessageBox.warning(self, "Tasti duplicati", "Questi tasti sono usati più volte: " + ", ".join(sorted(dup)))
            return
        if bad:
            QMessageBox.warning(self, "Tasto non valido", "Usa solo lettere come tasti (i numeri servono per i giocatori).")
            return
        roster = []
        for r in range(self.ro_table.rowCount()):
            it = self.ro_table.item(r, 0)
            if not it or not it.text().strip().isdigit():
                continue
            nm = self.ro_table.item(r, 1).text().strip() if self.ro_table.item(r, 1) else ""
            roster.append({"num": int(it.text().strip()), "name": nm})
        nums = [p["num"] for p in roster]
        if len(nums) != len(set(nums)):
            QMessageBox.warning(self, "Numeri duplicati", "Due giocatori hanno lo stesso numero di maglia.")
            return
        self.result_data = {"event_types": ets, "roster": sorted(roster, key=lambda x: x["num"]),
                            "teams": {"home": self.home_name.text().strip() or "Noi",
                                      "away": self.away_name.text().strip() or "Avversari"}}
        self.accept()


class EventDialog(QDialog):
    def __init__(self, project, ev, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Modifica evento")
        self.ev = ev
        form = QFormLayout(self)
        self.type_cb = QComboBox()
        names = [et["name"] for et in project.event_types]
        if ev["type"] not in names:
            names.append(ev["type"])
        self.type_cb.addItems(names)
        self.type_cb.setCurrentText(ev["type"])
        form.addRow("Evento:", self.type_cb)
        self.team_cb = QComboBox()
        self.team_cb.addItem(project.teams["home"], "home")
        self.team_cb.addItem(project.teams["away"], "away")
        self.team_cb.setCurrentIndex(0 if ev["team"] == "home" else 1)
        form.addRow("Squadra:", self.team_cb)
        self.player_sp = QSpinBox()
        self.player_sp.setRange(0, 99)
        self.player_sp.setSpecialValueText("—")
        self.player_sp.setValue(int(ev["player"]) if ev.get("player") is not None else 0)
        form.addRow("Giocatore (n°):", self.player_sp)
        self.start_sp = QDoubleSpinBox()
        self.start_sp.setRange(0, 1e6)
        self.start_sp.setDecimals(1)
        self.start_sp.setSuffix(" s")
        self.start_sp.setValue(ev["t"] - ev["start"])
        form.addRow("Secondi prima:", self.start_sp)
        self.end_sp = QDoubleSpinBox()
        self.end_sp.setRange(0, 1e6)
        self.end_sp.setDecimals(1)
        self.end_sp.setSuffix(" s")
        self.end_sp.setValue(ev["end"] - ev["t"])
        form.addRow("Secondi dopo:", self.end_sp)
        self.note = QLineEdit(ev.get("note", ""))
        form.addRow("Nota:", self.note)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Cancel).setText("Annulla")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        form.addRow(bb)

    def apply(self, duration):
        ev = self.ev
        ev["type"] = self.type_cb.currentText()
        ev["team"] = self.team_cb.currentData()
        ev["player"] = self.player_sp.value() or None
        ev["start"] = round(max(0.0, ev["t"] - self.start_sp.value()), 3)
        ev["end"] = round(min(duration, ev["t"] + self.end_sp.value()) if duration else ev["t"] + self.end_sp.value(), 3)
        ev["note"] = self.note.text().strip()


class ExportVideoDialog(QDialog):
    def __init__(self, title, n_clips, parent=None, single_file=True):
        super().__init__(parent)
        self.setWindowTitle(title)
        lay = QVBoxLayout(self)
        what = "1 clip" if n_clips == 1 else f"{n_clips} clip"
        lay.addWidget(QLabel(f"<b>{what}</b> " + ("in un unico video" if single_file and n_clips > 1 else
                                                   ("— un file per clip" if n_clips > 1 else ""))))
        g = QGroupBox("Qualità")
        gl = QVBoxLayout(g)
        self.rb = {}
        for k, pr in PRESETS.items():
            rb = QRadioButton(pr["label"])
            gl.addWidget(rb)
            self.rb[k] = rb
        self.rb["hq"].setChecked(True)
        lay.addWidget(g)
        self.cb_draw = QCheckBox("Includi i disegni")
        self.cb_draw.setChecked(True)
        self.cb_pause = QCheckBox("Metti i fermi immagine")
        self.cb_pause.setChecked(True)
        self.cb_cap = QCheckBox("Didascalia (minuto · evento · giocatore)")
        self.cb_cap.setChecked(True)
        self.cb_audio = QCheckBox("Includi l'audio")
        self.cb_audio.setChecked(True)
        for cb in (self.cb_draw, self.cb_pause, self.cb_cap, self.cb_audio):
            lay.addWidget(cb)
        self.cb_draw.toggled.connect(self.cb_pause.setEnabled)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Esporta…")
        bb.button(QDialogButtonBox.Cancel).setText("Annulla")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def options(self):
        preset = "wa" if self.rb["wa"].isChecked() else "hq"
        return {"preset": preset, "with_drawings": self.cb_draw.isChecked(),
                "use_pause": self.cb_pause.isChecked(), "with_caption": self.cb_cap.isChecked(),
                "with_audio": self.cb_audio.isChecked()}


class Bridge(QObject):
    """Riceve i segnali del thread di lavoro nel thread principale."""

    def __init__(self, on_prog, on_done, on_fail, parent=None):
        super().__init__(parent)
        self._p, self._d, self._f = on_prog, on_done, on_fail

    @Slot(float, str)
    def prog(self, frac, msg):
        self._p(frac, msg)

    @Slot(object)
    def done(self, res):
        self._d(res)

    @Slot(str)
    def fail(self, msg):
        self._f(msg)


class Worker(QObject):
    """Esegue una funzione lunga in un thread separato."""
    progress = Signal(float, str)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def is_cancelled(self):
        return self._cancel

    def run(self):
        try:
            res = self.fn(self.progress.emit, self.is_cancelled)
            self.finished.emit(res)
        except Exception as e:  # noqa
            from export import Cancelled
            if isinstance(e, Cancelled):
                self.failed.emit("__cancelled__")
            else:
                import traceback
                self.failed.emit(f"{e}\n\n{traceback.format_exc()[-1200:]}")
