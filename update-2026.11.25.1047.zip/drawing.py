"""Disegno degli strumenti grafici (frecce, cerchi, zone...) con QPainter.

Le coordinate dei disegni sono normalizzate (0..1) rispetto al fotogramma, così
lo stesso disegno si vede uguale nel player, nelle foto e nei video esportati.
"""
import math
import time

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (QBrush, QColor, QFont, QFontMetricsF, QImage, QLinearGradient, QPainterPath, QPen, QPolygonF,
                           QTransform)

FADE_IN = 0.2
FADE_OUT = 0.3


def drawing_alpha(d, t, use_pause=True):
    """Opacità del disegno al tempo t (0 se non visibile)."""
    start, end = d["t"], d["t"] + d["dur"]
    if d.get("freeze"):
        # fermo immagine: visibile pieno su quel fotogramma (tolleranza mezzo fotogramma per gli arrotondamenti)
        return 1.0 if abs(t - start) <= max(d["dur"], 0.002) * 0.6 else 0.0
    if t < start - 1e-6 or t > end + 1e-6:
        return 0.0
    a = 1.0
    has_pause = use_pause and d.get("pause", 0) > 0
    if not has_pause and not d.get("no_fade") and t - start < FADE_IN:
        a = min(a, max(0.15, (t - start) / FADE_IN))
    if end - t < FADE_OUT:
        a = min(a, max(0.0, (end - t) / FADE_OUT))
    return a


def active_drawings(drawings, t, use_pause=True):
    out = []
    for d in drawings:
        a = drawing_alpha(d, t, use_pause)
        if a > 0:
            out.append((d, a))
    return out


def _map(rect, p):
    return QPointF(rect.x() + p[0] * rect.width(), rect.y() + p[1] * rect.height())


def _color(hexcol, alpha=1.0):
    c = QColor(hexcol)
    c.setAlphaF(max(0.0, min(1.0, c.alphaF() * alpha)))
    return c


def _arrow_head(painter, a, b, size, color):
    ang = math.atan2(b.y() - a.y(), b.x() - a.x())
    p1 = QPointF(b.x() - size * math.cos(ang - 0.45), b.y() - size * math.sin(ang - 0.45))
    p2 = QPointF(b.x() - size * math.cos(ang + 0.45), b.y() - size * math.sin(ang + 0.45))
    painter.setPen(Qt.NoPen)
    painter.setBrush(QBrush(color))
    painter.drawPolygon(QPolygonF([b, p1, p2]))


def text_font(d, rect):
    scale = rect.height() / 720.0
    f = QFont(d.get("font") or "Helvetica")
    f.setBold(d.get("bold", True))
    f.setItalic(d.get("italic", False))
    size = d.get("fsize") or 26 * d.get("width", 4) / 4  # testi vecchi: grandezza dallo spessore
    f.setPixelSize(max(8, int(size * scale)))
    return f


def curve_mid(a, b):
    """Punto in mezzo a una freccia curva appena tracciata da a a b: la curva si alza un po' verso l'alto."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    px, py = -dy * 0.22, dx * 0.22
    if py > 0:
        px, py = -px, -py
    return [(a[0] + b[0]) / 2 + px, (a[1] + b[1]) / 2 + py]


def _paint_floodlight(painter, c, r, top_y, top_w, strength):
    """Cono «riflettore»: luce bianca che schiarisce il video (non lo colora), con i bordi morbidi, e una chiazza
    di luce a terra. Tanti strati sempre più larghi e più tenui fanno la sfumatura dei bordi."""
    from PySide6.QtGui import QPainter, QRadialGradient
    painter.save()
    painter.setCompositionMode(QPainter.CompositionMode_Screen)
    painter.setPen(Qt.NoPen)
    s = max(0.2, min(2.5, strength))
    cx, cy = r.center().x(), r.center().y()
    for k in range(7):
        f = 0.55 + 0.15 * k
        rw, rh = r.width() / 2 * f, r.height() / 2 * f
        rr = QRectF(cx - rw, cy - rh, rw * 2, rh * 2)
        bm = QPainterPath()
        tw = top_w * f
        bm.moveTo(c.x() - tw, top_y)
        bm.lineTo(c.x() + tw, top_y)
        bm.lineTo(rr.right(), cy)
        bm.arcTo(rr, 0, -180)
        bm.closeSubpath()
        g = QLinearGradient(QPointF(c.x(), top_y), QPointF(c.x(), rr.bottom()))
        c0, c1 = QColor(255, 255, 255), QColor(255, 255, 255)
        c0.setAlphaF(min(1.0, 0.012 * s))
        c1.setAlphaF(min(1.0, 0.075 * s))
        g.setColorAt(0.0, c0)
        g.setColorAt(1.0, c1)
        painter.setBrush(QBrush(g))
        painter.drawPath(bm)
    # chiazza di luce a terra
    painter.translate(cx, cy)
    painter.scale(1.0, max(0.05, r.height() / max(1.0, r.width())))
    rg = QRadialGradient(QPointF(0, 0), r.width() * 0.8)
    g0, g1 = QColor(255, 255, 255), QColor(255, 255, 255)
    g0.setAlphaF(min(1.0, 0.45 * s))
    g1.setAlphaF(0.0)
    rg.setColorAt(0.0, g0)
    rg.setColorAt(1.0, g1)
    painter.setBrush(QBrush(rg))
    painter.drawEllipse(QPointF(0, 0), r.width() * 0.8, r.width() * 0.8)
    painter.restore()


def _curve_ctrl(a, m, b):
    """Punto di controllo della curva che passa per m a metà strada tra a e b."""
    return QPointF(2 * m.x() - (a.x() + b.x()) / 2, 2 * m.y() - (a.y() + b.y()) / 2)


def _curve_points(a, m, b, n=24):
    c = _curve_ctrl(a, m, b)
    out = []
    for k in range(n + 1):
        t = k / n
        u = 1 - t
        out.append(QPointF(u * u * a.x() + 2 * u * t * c.x() + t * t * b.x(),
                           u * u * a.y() + 2 * u * t * c.y() + t * t * b.y()))
    return out


def ground_transform(d, rect):
    """Trasformazione (decimetri sul prato -> punti dello schermo) per il testo steso sul campo, o None."""
    M = d.get("_ground")
    if not M:
        return None
    S = [[rect.width(), 0, rect.x()], [0, rect.height(), rect.y()], [0, 0, 1]]
    F = [[sum(S[i][k] * M[k * 3 + j] for k in range(3)) for j in range(3)] for i in range(3)]
    return QTransform(F[0][0], F[1][0], F[2][0], F[0][1], F[1][1], F[2][1], F[0][2], F[1][2], F[2][2])


def ground_path(d):
    """Il testo come figura, in decimetri, centrato sul punto: grandezza 26 = righe alte circa 4 m."""
    f = QFont(d.get("font") or "Helvetica")
    f.setBold(d.get("bold", True))
    f.setItalic(d.get("italic", False))
    f.setPixelSize(max(4, int(round((d.get("fsize") or 26) / 26 * 40))))
    fm = QFontMetricsF(f)
    lines = (d.get("text") or " ").split("\n")
    tot = fm.lineSpacing() * len(lines)
    path = QPainterPath()
    for i, ln in enumerate(lines):
        path.addText(-fm.horizontalAdvance(ln) / 2, -tot / 2 + i * fm.lineSpacing() + fm.ascent(), f, ln)
    return path


def text_box(d, rect, p):
    """Riquadro occupato da un testo (anche su più righe) che parte dal punto p."""
    scale = rect.height() / 720.0
    f = text_font(d, rect)
    T = ground_transform(d, rect)
    if T is not None:
        return T.mapRect(ground_path(d).boundingRect()), f
    fm = QFontMetricsF(f)
    lines = (d.get("text") or " ").split("\n")
    tw = max(fm.horizontalAdvance(ln) for ln in lines)
    th = fm.lineSpacing() * len(lines)
    pad = 6 * scale
    return QRectF(p.x(), p.y(), tw + 2 * pad, th + pad), f


def paint_drawing(painter, rect, d, alpha=1.0, selected=False):
    """Disegna un singolo oggetto dentro rect (area del fotogramma)."""
    pts = [_map(rect, p) for p in d.get("points", [])]
    if not pts:
        return
    scale = rect.height() / 720.0
    # intensità del disegno intero (Proprietà → Intensità) e del suo riempimento
    alpha = alpha * max(0.05, min(1.0, float(d.get("opacity", 1.0))))
    fk = max(0.1, min(2.5, float(d.get("fill_k", 1.0))))
    edge = d.get("edge", True)
    w = max(1.0, d.get("width", 4) * scale)
    col = _color(d.get("color", "#ffeb3b"), alpha)
    shadow = QColor(0, 0, 0, int(110 * alpha))
    kind = d["kind"]
    painter.save()
    painter.setRenderHint(painter.RenderHint.Antialiasing, True)
    # niente fuori dal video (le zone sul campo possono andare oltre il bordo dell'immagine)
    painter.setClipRect(rect, Qt.IntersectClip)

    def pen(c, width, dashed=False):
        p = QPen(c, width, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
        if dashed:
            p.setStyle(Qt.CustomDashLine)
            p.setDashPattern([2.2, 1.8])
        return p

    def stroke_path(path, dashed=False):
        painter.setBrush(Qt.NoBrush)
        painter.setPen(pen(shadow, w + 2.5 * scale, dashed))
        painter.drawPath(path.translated(1.5 * scale, 1.5 * scale))
        painter.setPen(pen(col, w, dashed))
        painter.drawPath(path)

    trail = d.get("_trail")
    if trail and len(trail) >= 2:
        tp = [_map(rect, p) for p in trail]
        n = len(tp)
        for j in range(1, n):
            a_ = (j / n) ** 1.3
            painter.setPen(pen(_color(d.get("color", "#ffeb3b"), alpha * (0.15 + 0.85 * a_)), max(2.0, w * 0.75)))
            painter.drawLine(tp[j - 1], tp[j])

    if kind == "palla":
        bp = [_map(rect, q) for q in (d.get("_ball") or [])]
        if len(bp) >= 2:
            bpath = QPainterPath()
            bpath.moveTo(bp[0])
            for q in bp[1:]:
                bpath.lineTo(q)
            bc = QColor(d.get("color", "#ffeb3b"))
            lw = max(1.4, w * 0.7)                       # riga sottile: non deve coprire il gioco
            if d.get("glow", False):
                # alone leggero sotto la riga
                for wd, al in ((lw * 4.0, 0.05), (lw * 2.2, 0.09)):
                    gc = QColor(bc)
                    gc.setAlphaF(al * alpha)
                    painter.setPen(QPen(gc, wd, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                    painter.setBrush(Qt.NoBrush)
                    painter.drawPath(bpath)
            fade = d.get("fade", True) and not d.get("ball_whole")
            nseg = len(bp) - 1
            for i in range(nseg):
                # la parte vecchia sfuma, quella vicina alla palla è piena
                a_ = alpha * ((0.12 + 0.88 * (i + 1) / nseg) if fade else 1.0)
                sh = QPen(QColor(0, 0, 0, int(110 * a_)), lw + 1.2 * scale, Qt.SolidLine, Qt.RoundCap)
                painter.setPen(sh)
                painter.drawLine(bp[i] + QPointF(0.6 * scale, 0.6 * scale), bp[i + 1] + QPointF(0.6 * scale, 0.6 * scale))
                pn_ = QPen(_color(d.get("color", "#ffeb3b"), a_), lw, Qt.SolidLine, Qt.RoundCap)
                if d.get("dashed"):
                    pn_.setStyle(Qt.DashLine)
                painter.setPen(pn_)
                painter.drawLine(bp[i], bp[i + 1])
            if d.get("head", False) and len(bp) >= 4:
                _arrow_head(painter, bp[-4], bp[-1], max(8.0 * scale, lw * 3.5), _color(d.get("color", "#ffeb3b"), alpha))
        if bp and d.get("ball_dot", False):
            # la palla adesso: pallino piccolo (facoltativo)
            painter.setPen(QPen(_color(d.get("color", "#ffeb3b"), alpha), max(1.0, 1.1 * scale)))
            painter.setBrush(QBrush(QColor(255, 255, 255, int(220 * alpha))))
            painter.drawEllipse(bp[-1] if not d.get("ball_whole") else pts[0], 2.6 * scale, 2.6 * scale)
    if kind == "visuale" and d.get("_fan"):
        # visuale: ventaglio sul prato che schiarisce l'erba, bordo sottile, anello sotto il giocatore
        fp = QPainterPath()
        fp.addPolygon(QPolygonF([_map(rect, q) for q in d["_fan"]]))
        fp.closeSubpath()
        st_ = max(0.1, min(2.0, float(d.get("vis_strength", 1.6))))
        _fill_zone(painter, fp, d.get("color", "#ffeb3b"), alpha * 0.22 * st_, d.get("fill_style", "schiarisci"),
                   alpha * st_)
        if d.get("vis_edge", True):
            stroke_path(fp)
        h0 = (d.get("_h") or [None])[0]
        if h0 and pts:
            er = max(6.0, h0 * rect.height() * 0.32)
            painter.setPen(pen(col, max(1.2, w * 0.7)))
            painter.setBrush(Qt.NoBrush)
            painter.drawEllipse(pts[0], er, er * 0.38)
    bh = d.get("_behind") if kind == "collega" else None
    if bh and bh.get("poly"):
        # spazio dietro l'ultimo uomo: colore leggero sul prato, sotto le linee e gli anelli
        zc = QColor(d.get("behind_color") or "#40c4ff")
        zp = QPainterPath()
        zp.addPolygon(QPolygonF([_map(rect, q) for q in bh["poly"]]))
        zp.closeSubpath()
        _fill_zone(painter, zp, d.get("behind_color") or "#40c4ff", 0.17 * alpha * fk, d.get("behind_style") or "",
                   alpha * fk)
        if bh.get("edge"):
            ec = QColor(d.get("behind_color") or "#40c4ff")
            ec.setAlphaF(0.6 * alpha)
            painter.setPen(QPen(ec, max(1.5, 2.0 * scale), Qt.SolidLine, Qt.RoundCap))
            painter.drawLine(_map(rect, bh["edge"][0]), _map(rect, bh["edge"][1]))
    gp_ = d.get("_gap") if kind == "collega" else None
    if gp_ and gp_.get("zone"):
        gz = QColor(d.get("gap_color") or "#ffeb3b")
        gz.setAlphaF(0.15 * alpha)
        zp2 = QPainterPath()
        zp2.addPolygon(QPolygonF([_map(rect, q) for q in gp_["zone"]]))
        zp2.closeSubpath()
        _fill_zone(painter, zp2, d.get("gap_color") or "#ffeb3b", 0.15 * alpha * fk, d.get("gap_style") or "",
                   alpha * fk)
    if gp_ and d.get("gap_line", True):
        # misura tra due reparti: riga sottile tratteggiata con una piccola freccia a ogni estremità
        ga, gb = _map(rect, gp_["line"][0]), _map(rect, gp_["line"][1])
        lc = _color(d.get("color", "#ffeb3b"), alpha * 0.85)
        gw = max(1.0, 1.4 * scale)
        hs = max(7.0, 9.0 * scale)
        ln = math.hypot(gb.x() - ga.x(), gb.y() - ga.y())
        if ln > 2 * hs:
            ux, uy = (gb.x() - ga.x()) / ln, (gb.y() - ga.y()) / ln
            a2 = QPointF(ga.x() + ux * hs * 0.8, ga.y() + uy * hs * 0.8)
            b2 = QPointF(gb.x() - ux * hs * 0.8, gb.y() - uy * hs * 0.8)
            gpn = QPen(QColor(0, 0, 0, int(90 * alpha)), gw + 1.5 * scale, Qt.CustomDashLine, Qt.FlatCap)
            gpn.setDashPattern([3.0, 2.5])
            painter.setPen(gpn)
            painter.drawLine(a2 + QPointF(scale, scale), b2 + QPointF(scale, scale))
            gpn = QPen(lc, gw, Qt.CustomDashLine, Qt.FlatCap)
            gpn.setDashPattern([3.0, 2.5])
            painter.setPen(gpn)
            painter.drawLine(a2, b2)
            _arrow_head(painter, b2, ga, hs, lc)
            _arrow_head(painter, a2, gb, hs, lc)
    if kind in ("distanza", "collega") and len(pts) >= 2:
        closed = kind == "collega" and len(pts) >= 3 and bool(d.get("closed") or d.get("fill"))
        if kind == "collega" and d.get("fill") and len(pts) >= 3:
            hp = QPainterPath()
            hp.addPolygon(QPolygonF(pts))
            hp.closeSubpath()
            if d.get("hatch") and not d.get("fill_style"):
                _paint_hatch(painter, hp, d.get("color", "#ffeb3b"), alpha * fk, scale)
            else:
                _fill_zone(painter, hp, d.get("color", "#ffeb3b"), alpha * 0.22 * fk, d.get("fill_style") or "",
                           alpha * fk)
        hs = d.get("_h") or [None] * len(pts)

        def _ring_r(i):
            h = hs[i] if i < len(hs) else None
            if not h or d.get("ring_on", True) is False:
                return 0.0
            return max(6.0, h * rect.height() * 0.32 * float(d.get("size", 1.0)))

        def _trim(p, q, er):
            # punto dove il segmento p->q esce dall'ellisse (er, er*0.38) centrata in p
            if er <= 0:
                return p
            dx, dy = q.x() - p.x(), q.y() - p.y()
            k = math.sqrt((dx / er) ** 2 + (dy / (er * 0.38)) ** 2)
            if k <= 1.0:
                return None   # l'altro punto è dentro l'anello: niente linea
            return QPointF(p.x() + dx / k, p.y() + dy / k)

        n_ = len(pts)
        seg_idx = [(i, i + 1) for i in range(n_ - 1)]
        if closed:
            seg_idx.append((n_ - 1, 0))
        path = QPainterPath()
        for i, j in seg_idx:
            a2 = _trim(pts[i], pts[j], _ring_r(i))
            b2 = _trim(pts[j], pts[i], _ring_r(j))
            if a2 is None or b2 is None:
                continue
            if math.hypot(b2.x() - a2.x(), b2.y() - a2.y()) < 2:
                continue
            path.moveTo(a2)
            path.lineTo(b2)
        if edge or not (kind == "collega" and d.get("fill")):
            stroke_path(path, dashed=(kind == "distanza"))
        # anelli: colore (anche diverso dalla riga) e intensità propri
        col = _color(d.get("ring_color") or d.get("color", "#ffeb3b"),
                     alpha * max(0.05, min(1.0, float(d.get("ring_k", 1.0)))))
        tags = d.get("tags") or []
        for ti, (p, h) in enumerate(zip(pts, hs)):
            if ti < len(tags) and tags[ti] and h:
                _paint_tag(painter, QPointF(p.x(), p.y() - h * rect.height() * 1.02), tags[ti], scale, alpha)
        for p, h in zip(pts, hs):
            r = 5 * scale + w * 0.6
            if h and d.get("ring_on", True) is False:
                painter.setPen(Qt.NoPen)
                painter.setBrush(QBrush(col))
                painter.drawEllipse(p, r, r)
            elif h:
                er = max(6.0, h * rect.height() * 0.32 * float(d.get("size", 1.0)))
                pn = pen(col, max(1.2, w * 0.7))
                if d.get("ring") == "tratteggiato":
                    pn = QPen(col, max(1.4, w * 0.9), Qt.CustomDashLine, Qt.FlatCap)
                    pn.setDashPattern([2.4, 1.6])
                    pn.setDashOffset((time.monotonic() * 4.5) % 4.0)
                painter.setPen(pn)
                painter.setBrush(Qt.NoBrush)
                painter.drawEllipse(p, er, er * 0.38)
            else:
                painter.setPen(Qt.NoPen)
                painter.setBrush(QBrush(col))
                painter.drawEllipse(p, r, r)
    elif kind in ("freccia", "movimento", "linea") and len(pts) >= 2:
        a, b = pts[0], pts[-1]
        head = 0.0 if kind == "linea" else max(10.0 * scale, w * 3.2)
        ang = math.atan2(b.y() - a.y(), b.x() - a.x())
        bb = QPointF(b.x() - head * 0.7 * math.cos(ang), b.y() - head * 0.7 * math.sin(ang)) if head else b
        path = QPainterPath(a)
        path.lineTo(bb)
        stroke_path(path, dashed=(kind == "movimento"))
        if head:
            _arrow_head(painter, a + QPointF(1.5 * scale, 1.5 * scale), b + QPointF(1.5 * scale, 1.5 * scale), head, shadow)
            _arrow_head(painter, a, b, head, col)
    elif kind == "cerchio" and len(pts) >= 2:
        r = QRectF(pts[0], pts[-1]).normalized()
        path = QPainterPath()
        path.addEllipse(r)
        stroke_path(path)
    elif kind == "fantasma" and len(pts) >= 2:
        a, g = pts[0], pts[1]
        ph = (d.get("_gh") or d.get("h_fixed") or 0.16) * rect.height()
        base = QColor(d.get("color", "#ffeb3b"))
        # freccia tratteggiata da dove sta a dove doveva stare
        if d.get("arrow", True):
            head = max(15.0 * scale, w * 3.8)
            ang = math.atan2(g.y() - a.y(), g.x() - a.x())
            rr = max(6.0, ph * 0.12)   # la freccia si ferma al bordo dell'anello
            dist = math.hypot(g.x() - a.x(), g.y() - a.y())
            if dist > rr * 2.4:
                e = QPointF(g.x() - rr * 1.3 * math.cos(ang), g.y() - rr * 1.3 * math.sin(ang))
                s0 = QPointF(a.x() + rr * 0.9 * math.cos(ang), a.y() + rr * 0.9 * math.sin(ang))
                ap = QPainterPath(s0)
                ap.lineTo(QPointF(e.x() - head * 0.7 * math.cos(ang), e.y() - head * 0.7 * math.sin(ang)))
                stroke_path(ap, dashed=True)
                _arrow_head(painter, s0 + QPointF(1.5 * scale, 1.5 * scale), e + QPointF(1.5 * scale, 1.5 * scale), head, shadow)
                _arrow_head(painter, s0, e, head, col)
        # anello a terra del fantasma
        rp = d.get("_ring_poly")
        path = QPainterPath()
        if rp:
            path.addPolygon(QPolygonF([_map(rect, q) for q in rp]))
            path.closeSubpath()
            rb = path.boundingRect()
        else:
            rad = max(7.0, ph * 0.42) * d.get("size", 1.0)
            rb = QRectF(g.x() - rad, g.y() - rad * 0.38, rad * 2, rad * 0.76)
            path.addEllipse(rb)
        fill = QColor(base)
        fill.setAlphaF(0.22 * alpha)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(fill))
        painter.drawPath(path)
        dp = QPen(_color(d.get("color", "#ffeb3b"), alpha), max(2.0, w * 1.0), Qt.CustomDashLine, Qt.FlatCap)
        dp.setDashPattern([2.4, 1.6])
        painter.setBrush(Qt.NoBrush)
        painter.setPen(QPen(shadow, max(2.0, w * 1.0) + 2.0 * scale))
        painter.drawPath(path.translated(1.2 * scale, 1.2 * scale))
        painter.setPen(dp)
        painter.drawPath(path)
        # il giocatore vero ritagliato, semitrasparente
        cut = d.get("cutout")
        drawn_cut = False
        if cut and d.get("use_cut", True) and d.get("figure", True):
            try:
                import ritaglio
                hc = float(cut.get("bh") or cut["h"])
                sc = ph / hc
                col3 = (base.red(), base.green(), base.blue())
                got = ritaglio.tinted(cut, col3, d.get("id", "x"), float(d.get("cut_op", 0.8)))
                if got:
                    arr, pad = got
                    qi = QImage(arr.data, arr.shape[1], arr.shape[0], arr.shape[1] * 4, QImage.Format_ARGB32).copy()
                    # fila BGRA in memoria = ARGB32 little endian: già nel formato giusto
                    tw, th = qi.width() * sc, qi.height() * sc
                    fx, fy = (cut["foot"][0] + pad) * sc, (cut["foot"][1] + pad) * sc
                    painter.setOpacity(alpha)
                    painter.setRenderHint(painter.RenderHint.SmoothPixmapTransform, True)
                    painter.drawImage(QRectF(g.x() - fx, g.y() - fy, tw, th), qi)
                    painter.setOpacity(1.0)
                    drawn_cut = True
            except Exception:
                drawn_cut = False
        # sagoma semitrasparente
        if d.get("figure", True) and not drawn_cut:
            fc = QColor(base)
            fc.setAlphaF(0.38 * alpha)
            ol = QColor(base)
            ol.setAlphaF(0.9 * alpha)
            cx, fy = g.x(), g.y()
            fig = QPainterPath()
            fig.addEllipse(QPointF(cx, fy - 0.90 * ph), 0.085 * ph, 0.085 * ph)                      # testa
            fig.addRoundedRect(QRectF(cx - 0.12 * ph, fy - 0.80 * ph, 0.24 * ph, 0.36 * ph), 0.06 * ph, 0.06 * ph)  # busto
            fig.addRoundedRect(QRectF(cx - 0.115 * ph, fy - 0.46 * ph, 0.10 * ph, 0.46 * ph), 0.04 * ph, 0.04 * ph)  # gamba
            fig.addRoundedRect(QRectF(cx + 0.015 * ph, fy - 0.46 * ph, 0.10 * ph, 0.46 * ph), 0.04 * ph, 0.04 * ph)  # gamba
            fig.addRoundedRect(QRectF(cx - 0.19 * ph, fy - 0.78 * ph, 0.06 * ph, 0.30 * ph), 0.03 * ph, 0.03 * ph)   # braccio
            fig.addRoundedRect(QRectF(cx + 0.13 * ph, fy - 0.78 * ph, 0.06 * ph, 0.30 * ph), 0.03 * ph, 0.03 * ph)   # braccio
            fig = fig.simplified()
            painter.setPen(QPen(ol, max(1.2, 1.4 * scale), Qt.DashLine))
            painter.setBrush(QBrush(fc))
            painter.drawPath(fig)
    elif kind == "spotlight" and len(pts) >= 1:
        c = pts[0]
        rad = 28 * scale
        hs = d.get("_h") or ([d["h_fixed"]] if d.get("h_fixed") else [None])
        ph = None  # altezza del giocatore in pixel
        if hs[0]:
            ph = hs[0] * rect.height()
            rad = max(7.0, ph * 0.42) * d.get("size", 1.0)
        elif len(pts) >= 2:
            rad = max(8 * scale, math.hypot(pts[1].x() - c.x(), pts[1].y() - c.y())) * d.get("size", 1.0)
        if ph is None:
            ph = rad / 0.42
        if d.get("_space") is not None:
            # spazio libero: disco trasparente a terra che arriva fino all'avversario più vicino
            # (come nelle analisi FIFA); l'anello piccolo sotto il giocatore resta com'è
            fc = QColor(d.get("color", "#ffeb3b"))
            fc.setAlphaF(0.10 * alpha)   # leggero: non deve coprire il gioco
            painter.setBrush(QBrush(fc))
            sdp = QPen(_color(d.get("color", "#ffeb3b"), alpha * 0.7), max(1.2, 1.2 * scale), Qt.CustomDashLine, Qt.FlatCap)
            sdp.setDashPattern([3.0, 2.5])
            painter.setPen(sdp)
            sp = d.get("_space_poly")
            if sp:
                # campo calibrato: cerchio vero sul terreno, con il raggio in metri
                painter.drawPolygon(QPolygonF([_map(rect, q) for q in sp["pts"]]))
            else:
                if d.get("_space_w"):
                    sr = max(rad * 1.15, float(d["_space_w"]) * rect.width())   # misura nuova: già in pixel
                else:
                    sr = max(rad * 1.15, ph * min(3.2, max(0.45, float(d["_space"]))))
                painter.drawEllipse(QRectF(c.x() - sr, c.y() - sr * 0.38, sr * 2, sr * 0.76))
        light = float(d.get("light", 0.35))
        base = QColor(d.get("color", "#ffeb3b"))
        r = QRectF(c.x() - rad, c.y() - rad * 0.38, rad * 2, rad * 0.76)
        path = QPainterPath()
        rp = d.get("_ring_poly")
        if rp:
            poly_r = QPolygonF([_map(rect, q) for q in rp])
            path.addPolygon(poly_r)
            path.closeSubpath()
            r = poly_r.boundingRect()
        else:
            path.addEllipse(r)
        # cono di luce che scende dall'alto sul giocatore: stretto in alto, largo quanto il cerchio a terra
        cone = float(d.get("cone", 3.0)) if d.get("cone_on", True) else 0.0
        if cone > 0:
            top_y = max(rect.top(), c.y() - ph * cone)
            top_w = rad * 0.18
            beam = QPainterPath()
            beam.moveTo(c.x() - top_w, top_y)
            beam.lineTo(c.x() + top_w, top_y)
            beam.lineTo(r.right(), r.center().y())
            beam.arcTo(r, 0, -180)
            beam.closeSubpath()
            if d.get("cone_style") == "riflettore":
                _paint_floodlight(painter, c, r, top_y, top_w, alpha * light / 0.35)
                beam = QPainterPath()
            g = QLinearGradient(QPointF(c.x(), top_y), QPointF(c.x(), r.bottom()))
            c0, c1 = QColor(base), QColor(base)
            c0.setAlphaF(min(1.0, 0.10 * alpha * light / 0.35))
            c1.setAlphaF(min(1.0, 0.45 * alpha * light / 0.35))
            g.setColorAt(0.0, c0)
            g.setColorAt(1.0, c1)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(g))
            painter.drawPath(beam)
        if d.get("ring_on", True):
            if d.get("ring") == "tratteggiato":
                # anello a trattini con un alone, come quello su Messi nelle analisi FIFA; i trattini girano
                fill = QColor(base)
                fill.setAlphaF(min(1.0, 0.25 * alpha * light))
                painter.setPen(Qt.NoPen)
                painter.setBrush(QBrush(fill))
                painter.drawPath(path)
                painter.setBrush(Qt.NoBrush)
                glow = QColor(base)
                glow.setAlphaF(0.30 * alpha)
                painter.setPen(QPen(glow, w * 2.6))
                painter.drawPath(path)
                dp = QPen(_color(d.get("color", "#ffeb3b"), alpha), max(2.0, w * 1.1), Qt.CustomDashLine, Qt.FlatCap)
                dp.setDashPattern([2.4, 1.6])
                dp.setDashOffset((time.monotonic() * 4.5) % 4.0)
                painter.setPen(QPen(shadow, max(2.0, w * 1.1) + 2.0 * scale))
                painter.drawPath(path.translated(1.2 * scale, 1.2 * scale))
                painter.setPen(dp)
                painter.drawPath(path)
            else:
                fill = QColor(base)
                fill.setAlphaF(min(1.0, 0.8 * alpha * light))
                painter.setPen(Qt.NoPen)
                painter.setBrush(QBrush(fill))
                painter.drawPath(path)
                stroke_path(path)
    elif kind == "zona" and len(pts) >= 2:
        r = QRectF(pts[0], pts[-1]).normalized()
        path = QPainterPath()
        path.addRect(r)
        if d.get("hatch") and not d.get("fill_style"):
            _paint_hatch(painter, path, d.get("color", "#ffeb3b"), alpha * fk, scale)
            if edge:
                stroke_path(path)
        else:
            _fill_zone(painter, path, d.get("color", "#ffeb3b"), alpha * 0.30 * fk, d.get("fill_style") or "", alpha * fk)
            if edge:
                stroke_path(path, dashed=True)
        _paint_zone_text(painter, path, d, alpha, scale)
    elif kind == "area" and len(pts) >= 3:
        poly = QPolygonF(pts)
        path = QPainterPath()
        path.addPolygon(poly)
        path.closeSubpath()
        if d.get("hatch") and not d.get("fill_style"):
            _paint_hatch(painter, path, d.get("color", "#ffeb3b"), alpha * fk, scale)
        else:
            _fill_zone(painter, path, d.get("color", "#ffeb3b"), alpha * 0.30 * fk, d.get("fill_style") or "", alpha * fk)
        if edge:
            stroke_path(path)
        _paint_zone_text(painter, path, d, alpha, scale)
    elif kind == "mano" and len(pts) >= 2:
        path = QPainterPath(pts[0])
        for p in pts[1:]:
            path.lineTo(p)
        stroke_path(path)
    elif kind == "testo" and ground_transform(d, rect) is not None and d.get("text"):
        # testo steso sul prato, in prospettiva
        T = ground_transform(d, rect)
        gp = ground_path(d)
        painter.save()
        painter.setWorldTransform(T, True)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(0, 0, 0, int(120 * alpha))))
        painter.drawPath(gp.translated(0.6, 0.6))
        painter.setBrush(QBrush(col))
        painter.drawPath(gp)
        painter.restore()
    elif kind == "curva" and len(pts) >= 3:
        a, m, b = pts[0], pts[1], pts[2]
        cp = _curve_points(a, m, b)
        if d.get("lob"):
            # passaggio alto: la palla vola sull'arco, a terra resta la sua ombra (dritta, tratteggiata)
            sh = QPen(QColor(0, 0, 0, int(140 * alpha)), max(1.5, w * 0.8), Qt.CustomDashLine, Qt.RoundCap)
            sh.setDashPattern([1.6, 2.2])
            painter.setPen(sh)
            painter.setBrush(Qt.NoBrush)
            painter.drawLine(a, b)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(QColor(0, 0, 0, int(110 * alpha))))
            painter.drawEllipse(b, max(4.0, w * 1.6), max(1.6, w * 0.6))
        head = max(10.0 * scale, w * 3.2) if d.get("head", True) else 0.0
        path = QPainterPath(cp[0])
        if head:
            # accorcia la curva sotto la punta (taglio preciso lungo la curva)
            need = head * 0.7
            keep = len(cp) - 1
            end = cp[-1]
            while keep > 0:
                seg = math.hypot(cp[keep].x() - cp[keep - 1].x(), cp[keep].y() - cp[keep - 1].y())
                if seg >= need:
                    t = need / seg if seg else 0
                    end = QPointF(cp[keep].x() + (cp[keep - 1].x() - cp[keep].x()) * t,
                                  cp[keep].y() + (cp[keep - 1].y() - cp[keep].y()) * t)
                    break
                need -= seg
                keep -= 1
            for q in cp[1:keep]:
                path.lineTo(q)
            path.lineTo(end)
        else:
            for q in cp[1:]:
                path.lineTo(q)
        stroke_path(path, dashed=bool(d.get("dashed")))
        if head:
            tail = cp[-2]
            _arrow_head(painter, tail + QPointF(1.5 * scale, 1.5 * scale), b + QPointF(1.5 * scale, 1.5 * scale),
                        head, shadow)
            _arrow_head(painter, tail, b, head, col)
    elif kind == "testo":
        text = d.get("text", "")
        if text:
            box, f = text_box(d, rect, pts[0])
            pad = 6 * scale
            if d.get("bg", True):
                painter.setPen(Qt.NoPen)
                painter.setBrush(QBrush(QColor(0, 0, 0, int(170 * alpha))))
                painter.drawRoundedRect(box, 4 * scale, 4 * scale)
            painter.setFont(f)
            if not d.get("bg", True):
                painter.setPen(QPen(shadow))
                painter.drawText(box.adjusted(pad + 1.5 * scale, pad / 2 + 1.5 * scale, 0, 0),
                                 Qt.AlignLeft | Qt.AlignTop, text)
            painter.setPen(QPen(col))
            painter.drawText(box.adjusted(pad, pad / 2, -pad, 0), Qt.AlignLeft | Qt.AlignTop, text)

    for lab in d.get("_labels", []):
        ang = None
        if len(lab) > 3 and d.get("label_along") and lab[3] is not None:
            i, j = lab[3]
            if i < len(pts) and j < len(pts):
                ang = math.degrees(math.atan2(pts[j].y() - pts[i].y(), pts[j].x() - pts[i].x()))
                if ang > 90:
                    ang -= 180
                elif ang <= -90:
                    ang += 180
        _paint_label(painter, _map(rect, lab[0]), lab[1], scale, alpha, d.get("color", "#ffeb3b"),
                     below=len(lab) > 2 and bool(lab[2]), angle=ang)

    if selected:
        xs = [p.x() for p in pts]
        ys = [p.y() for p in pts]
        bb = QRectF(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)).adjusted(-8, -8, 8, 8)
        if kind == "testo" and d.get("text"):
            bb = text_box(d, rect, pts[0])[0].adjusted(-4, -4, 4, 4)
        if kind == "spotlight" and len(pts) >= 2:
            rad = math.hypot(pts[1].x() - pts[0].x(), pts[1].y() - pts[0].y())
            bb = QRectF(pts[0].x() - rad, pts[0].y() - rad, rad * 2, rad * 2).adjusted(-6, -6, 6, 6)
        p = QPen(QColor("#ffffff"), 1, Qt.DashLine)
        painter.setPen(p)
        painter.setBrush(Qt.NoBrush)
        painter.drawRect(bb)
        if kind == "visuale" and len(pts) >= 2:
            # pallino da trascinare: verso dove guarda il giocatore
            painter.setPen(QPen(QColor(0, 0, 0, 180), 1.5))
            painter.setBrush(QBrush(QColor("#ffffff")))
            painter.drawEllipse(pts[1], 6, 6)
        if kind == "curva" and len(pts) >= 3:
            # pallino da trascinare per curvare di più o di meno
            painter.setPen(QPen(QColor(0, 0, 0, 180), 1.5))
            painter.setBrush(QBrush(QColor("#ffffff")))
            painter.drawEllipse(pts[1], 6, 6)
    painter.restore()


def _paint_tag(painter, p, text, scale, alpha):
    """Sigla sopra la testa del giocatore (CM, RB…): testo bianco con ombra, senza riquadro."""
    f = QFont()
    f.setBold(True)
    f.setPixelSize(max(10, int(17 * scale)))
    fm = QFontMetricsF(f)
    tw = fm.horizontalAdvance(text)
    painter.save()
    painter.setFont(f)
    base = QPointF(p.x() - tw / 2, p.y() - 4 * scale)
    painter.setPen(QPen(QColor(0, 0, 0, int(170 * alpha))))
    painter.drawText(base + QPointF(1.2 * scale, 1.2 * scale), text)
    painter.setPen(QPen(QColor(255, 255, 255, int(255 * alpha))))
    painter.drawText(base, text)
    painter.restore()


def _fill_zone(painter, path, color, a, style="", alpha=1.0):
    """Riempie una zona: colore (trasparenza a), oppure schiarisce o scurisce l'erba senza colorarla."""
    from PySide6.QtGui import QPainter
    painter.save()
    painter.setPen(Qt.NoPen)
    if style == "scurisci":
        painter.setBrush(QBrush(QColor(0, 0, 0, int(255 * min(1.0, 0.30 * alpha)))))
    elif style == "schiarisci":
        painter.setCompositionMode(QPainter.CompositionMode_Screen)
        painter.setBrush(QBrush(QColor(255, 255, 255, int(255 * min(1.0, 0.24 * alpha)))))
    else:
        painter.setBrush(QBrush(_color(color, a)))
    painter.drawPath(path)
    painter.restore()


def _paint_hatch(painter, path, color, alpha, scale):
    """Riempimento a righe diagonali (come le zone delle analisi FIFA): velo leggero + righe oblique."""
    painter.save()
    painter.setPen(Qt.NoPen)
    painter.setBrush(QBrush(_color(color, alpha * 0.14)))
    painter.drawPath(path)
    painter.setClipPath(path, Qt.IntersectClip)
    bb = path.boundingRect()
    step = max(6.0, 13.0 * scale)
    painter.setPen(QPen(_color(color, alpha * 0.55), max(1.0, 1.6 * scale)))
    x = bb.left() - bb.height()
    while x < bb.right():
        painter.drawLine(QPointF(x, bb.bottom()), QPointF(x + bb.height(), bb.top()))
        x += step
    painter.restore()


def _paint_zone_text(painter, path, d, alpha, scale):
    """Scritta della zona: di base SOTTO la zona, lungo il bordo più basso e inclinata come lui
    (come nelle analisi FIFA); oppure dentro, centrata."""
    text = (d.get("label") or "").strip()
    if not text:
        return
    f = QFont()
    f.setBold(True)
    painter.save()
    o = max(1.0, 1.5 * scale)

    def draw(box, align):
        painter.setPen(QPen(QColor(0, 0, 0, int(200 * alpha))))
        for dx, dy in ((o, o), (-o, o), (o, -o), (-o, -o)):
            painter.drawText(box.translated(dx, dy), align, text)
        painter.setPen(QPen(_color(d.get("color", "#ffeb3b"), alpha)))
        painter.drawText(box, align, text)

    if d.get("label_pos", "sotto") == "dentro":
        bb = path.boundingRect()
        size = max(10, int(min(bb.height() * 0.42, 34 * scale)))
        f.setPixelSize(size)
        fm = QFontMetricsF(f)
        while size > 10 and fm.horizontalAdvance(text) > bb.width() * 0.9:
            size -= 1
            f.setPixelSize(size)
            fm = QFontMetricsF(f)
        painter.setFont(f)
        draw(bb, Qt.AlignCenter)
        painter.restore()
        return
    poly = list(path.toFillPolygon())
    if len(poly) > 1 and poly[0] == poly[-1]:
        poly = poly[:-1]
    if len(poly) < 2:
        painter.restore()
        return
    above = d.get("label_pos") == "sopra"
    # il bordo più in basso (verso chi guarda) per «sotto», quello più in alto per «sopra»
    edges = [(poly[k], poly[(k + 1) % len(poly)]) for k in range(len(poly))]
    sign = -1 if above else 1
    a, b = max(edges, key=lambda e: sign * (e[0].y() + e[1].y()) / 2 + 0.001 * math.hypot(e[1].x() - e[0].x(),
                                                                                              e[1].y() - e[0].y()))
    if a.x() > b.x():
        a, b = b, a
    length = math.hypot(b.x() - a.x(), b.y() - a.y())
    ang = math.degrees(math.atan2(b.y() - a.y(), b.x() - a.x()))
    if abs(ang) > 60 or length < 20:
        yy = path.boundingRect().top() if above else path.boundingRect().bottom()
        a, b = QPointF(path.boundingRect().left(), yy), QPointF(path.boundingRect().right(), yy)
        length, ang = b.x() - a.x(), 0.0
    size = max(10, int(26 * scale))
    f.setPixelSize(size)
    fm = QFontMetricsF(f)
    while size > 10 and fm.horizontalAdvance(text) > length * 0.95:
        size -= 1
        f.setPixelSize(size)
        fm = QFontMetricsF(f)
    painter.setFont(f)
    painter.translate((a.x() + b.x()) / 2, (a.y() + b.y()) / 2)
    painter.rotate(ang)
    w = max(length, fm.horizontalAdvance(text) + 8)
    hh = fm.height() + 4
    y0 = -(hh + 4 * scale) if above else 4 * scale
    draw(QRectF(-w / 2, y0, w, hh), Qt.AlignHCenter | (Qt.AlignBottom if above else Qt.AlignTop))
    painter.restore()


def _label_box(p, text, scale, below=False):
    f = QFont()
    f.setBold(True)
    f.setPixelSize(max(10, int(19 * scale)))
    fm = QFontMetricsF(f)
    pad = 6 * scale
    tw = fm.horizontalAdvance(text) + 2 * pad
    th = fm.height() + pad * 0.6
    box = QRectF(p.x() - tw / 2, (p.y() + 2 * scale) if below else (p.y() - th - 4 * scale), tw, th)
    return box, f, tw, th


def label_hit(d, rect, pos):
    """Scritta spostabile (righello tra i reparti, spazio dietro) sotto il mouse: ritorna la sua chiave o None."""
    scale = rect.height() / 720.0
    for lab in d.get("_labels") or []:
        if len(lab) > 4 and lab[4]:
            box = _label_box(_map(rect, lab[0]), lab[1], scale, len(lab) > 2 and bool(lab[2]))[0]
            if box.adjusted(-4, -4, 4, 4).contains(pos):
                return lab[4]
    return None


def _paint_label(painter, p, text, scale, alpha, color, below=False, angle=None):
    box, f, tw, th = _label_box(p, text, scale, below)
    painter.save()
    if angle is not None:
        painter.translate(p)
        painter.rotate(angle)
        box = QRectF(-tw / 2, -th / 2, tw, th)   # centrata sulla linea, inclinata come lei
    painter.setPen(Qt.NoPen)
    painter.setBrush(QBrush(QColor(0, 0, 0, int(185 * alpha))))
    painter.drawRoundedRect(box, 5 * scale, 5 * scale)
    painter.setBrush(QBrush(_color(color, alpha)))
    painter.drawRect(QRectF(box.x(), box.bottom() - 2.5 * scale, box.width(), 2.5 * scale))
    painter.setFont(f)
    painter.setPen(QPen(QColor(255, 255, 255, int(255 * alpha))))
    painter.drawText(box, Qt.AlignCenter, text)
    painter.restore()


def paint_drawings(painter, rect, drawings, t, use_pause=True, selected_id=None, force_full=None,
                   resolver=None, idx=None):
    """Disegna tutti i disegni attivi al tempo t.

    force_full: insieme di id da mostrare con opacità piena (usato durante le pause).
    resolver(d, idx): posizioni aggiornate dei disegni che seguono giocatori/campo.
    """
    for d, a in active_drawings(drawings, t, use_pause):
        if force_full and d["id"] in force_full:
            a = 1.0
        if resolver is not None and (d.get("anchors") or d.get("ground") or d.get("kind") in ("spotlight", "fantasma")):
            d = resolver(d, idx)
            if d is None:
                continue
        paint_drawing(painter, rect, d, a, selected=(d["id"] == selected_id))


def paint_caption(painter, rect, text, color="#2ecc71"):
    """Didascalia in basso a sinistra (es. "23:10 · Recupero · Noi · #7 Rossi")."""
    if not text:
        return
    scale = rect.height() / 720.0
    painter.save()
    painter.setRenderHint(painter.RenderHint.Antialiasing, True)
    f = QFont()
    f.setBold(True)
    f.setPixelSize(max(10, int(22 * scale)))
    fm = QFontMetricsF(f)
    pad = 10 * scale
    tw = fm.horizontalAdvance(text)
    th = fm.height()
    box = QRectF(rect.x() + 18 * scale, rect.bottom() - 18 * scale - th - pad, tw + 2 * pad + 8 * scale, th + pad)
    painter.setPen(Qt.NoPen)
    painter.setBrush(QBrush(QColor(0, 0, 0, 175)))
    painter.drawRoundedRect(box, 5 * scale, 5 * scale)
    painter.setBrush(QBrush(QColor(color)))
    painter.drawRoundedRect(QRectF(box.x(), box.y(), 6 * scale, box.height()), 2 * scale, 2 * scale)
    painter.setFont(f)
    painter.setPen(QPen(QColor("white")))
    painter.drawText(box.adjusted(pad + 6 * scale, 0, 0, 0), Qt.AlignVCenter | Qt.AlignLeft, text)
    painter.restore()


def hit_test(d, rect, pos, tol=10):
    """True se il punto (in coordinate widget) è vicino al disegno."""
    pts = [_map(rect, p) for p in d.get("points", [])]
    if not pts:
        return False
    xs = [p.x() for p in pts]
    ys = [p.y() for p in pts]
    if d["kind"] == "spotlight":
        hs = d.get("_h") or [None]
        if hs[0]:
            rad = max(12.0, hs[0] * rect.height() * 0.5)
            # anche il corpo del giocatore (sopra i piedi) conta
            body = QRectF(pts[0].x() - rad * 0.6, pts[0].y() - hs[0] * rect.height(), rad * 1.2, hs[0] * rect.height())
            return math.hypot(pos.x() - pts[0].x(), pos.y() - pts[0].y()) <= rad + tol or body.contains(pos)
        if len(pts) >= 2:
            rad = math.hypot(pts[1].x() - pts[0].x(), pts[1].y() - pts[0].y())
            return math.hypot(pos.x() - pts[0].x(), pos.y() - pts[0].y()) <= rad + tol
    if d["kind"] == "palla":
        bp = [_map(rect, q) for q in (d.get("_ball") or [])] or pts
        return any(math.hypot(pos.x() - q.x(), pos.y() - q.y()) <= tol + 6 for q in bp[::2] + bp[-1:])
    if d["kind"] == "visuale":
        if any(math.hypot(pos.x() - q.x(), pos.y() - q.y()) <= tol + 10 for q in pts[:2]):
            return True
        if d.get("_fan"):
            return QPolygonF([_map(rect, q) for q in d["_fan"]]).containsPoint(pos, Qt.OddEvenFill)
        return False
    if d["kind"] in ("distanza", "collega"):
        seg = list(zip(pts, pts[1:]))
        if d["kind"] == "collega" and len(pts) >= 3 and (d.get("closed") or d.get("fill")):
            seg.append((pts[-1], pts[0]))
        for a, b in seg:
            if _seg_dist(pos, a, b) <= tol + 4:
                return True
        return any(math.hypot(pos.x() - p.x(), pos.y() - p.y()) <= tol + 8 for p in pts)
    if d["kind"] == "testo":
        return text_box(d, rect, pts[0])[0].adjusted(-tol, -tol, tol, tol).contains(pos)
    if d["kind"] == "curva" and len(pts) >= 3:
        cp = _curve_points(pts[0], pts[1], pts[2])
        if math.hypot(pos.x() - pts[1].x(), pos.y() - pts[1].y()) <= tol + 8:
            return True
        return any(_seg_dist(pos, a, b) <= tol + d.get("width", 4) for a, b in zip(cp, cp[1:]))
    if d["kind"] in ("freccia", "movimento", "linea", "mano"):
        for a, b in zip(pts, pts[1:]):
            if _seg_dist(pos, a, b) <= tol + d.get("width", 4):
                return True
        return False
    return QRectF(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)).adjusted(-tol, -tol, tol, tol).contains(pos)


def _seg_dist(p, a, b):
    dx, dy = b.x() - a.x(), b.y() - a.y()
    if dx == dy == 0:
        return math.hypot(p.x() - a.x(), p.y() - a.y())
    u = ((p.x() - a.x()) * dx + (p.y() - a.y()) * dy) / (dx * dx + dy * dy)
    u = max(0.0, min(1.0, u))
    return math.hypot(p.x() - (a.x() + u * dx), p.y() - (a.y() + u * dy))
