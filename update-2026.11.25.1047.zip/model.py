"""Dati del progetto: eventi, disegni, pannello di tagging, rosa. Salvataggio JSON."""
import copy
import json
import os
import uuid

VERSION = 1

DEFAULT_EVENT_TYPES = [
    {"name": "Gol", "key": "G", "color": "#2ecc71", "pre": 8, "post": 4},
    {"name": "Tiro", "key": "T", "color": "#e67e22", "pre": 6, "post": 3},
    {"name": "Passaggio chiave", "key": "P", "color": "#3498db", "pre": 6, "post": 3},
    {"name": "Recupero", "key": "R", "color": "#1abc9c", "pre": 4, "post": 5},
    {"name": "Palla persa", "key": "L", "color": "#e74c3c", "pre": 5, "post": 4},
    {"name": "Fallo", "key": "F", "color": "#9b59b6", "pre": 5, "post": 3},
    {"name": "Calcio d'angolo", "key": "A", "color": "#f1c40f", "pre": 2, "post": 8},
    {"name": "Punizione", "key": "U", "color": "#95a5a6", "pre": 2, "post": 8},
]

DRAWING_KINDS = {
    "distanza": "Distanza",
    "collega": "Collega giocatori",
    "visuale": "Visuale del giocatore",
    "palla": "Traiettoria della palla",
    "freccia": "Freccia",
    "movimento": "Movimento (tratteggiata)",
    "curva": "Freccia curva",
    "linea": "Linea",
    "cerchio": "Cerchio",
    "spotlight": "Evidenzia giocatore",
    "fantasma": "Fantasma (dove doveva stare)",
    "zona": "Zona",
    "area": "Area libera",
    "mano": "Mano libera",
    "testo": "Testo",
}


def new_id():
    return uuid.uuid4().hex[:10]


def fmt_time(t, with_tenths=False):
    t = max(0.0, float(t))
    m = int(t // 60)
    s = t - m * 60
    if with_tenths:
        return f"{m:02d}:{s:04.1f}"
    return f"{m:02d}:{int(s):02d}"


class Project:
    def __init__(self):
        self.video_path = ""
        self.teams = {"home": "Noi", "away": "Avversari"}
        self.roster = []  # [{"num": 7, "name": "Rossi"}]
        self.event_types = copy.deepcopy(DEFAULT_EVENT_TYPES)
        self.events = []  # dict: id,type,t,start,end,team,player,note,pos
        self.drawings = []  # dict: id,kind,points,color,width,t,dur,pause,text,anchors
        self.tracks = {}  # id -> {"from": idx, "to": idx, "data": {idx: [x, y, h, conf]}}
        self.calibrations = []  # [{"idx", "H", "img", "pitch_pts", "pitch", "err"}]
        self.camera = {}  # movimento telecamera già calcolato (vedi camera.py)
        self.pitch = None  # misure del campo scelte per l'ultima calibrazione
        self.pitch_refs = {}  # fotogrammi riconosciuti in automatico: idx -> matrice verso il campo
        self.stills = []  # fermi immagine: [{"id", "t" (secondi nel video), "dur" (secondi di fermo)}]
        self.cuts = []  # pezzi tolti dal video [inizio, fine] in secondi (il file originale non si tocca)
        self.path = ""  # file .analisi.json

    # ---------- tipi evento ----------
    def type_by_name(self, name):
        for et in self.event_types:
            if et["name"] == name:
                return et
        return None

    def type_by_key(self, key):
        key = key.upper()
        for et in self.event_types:
            if et.get("key", "").upper() == key:
                return et
        return None

    def color_for(self, type_name):
        et = self.type_by_name(type_name)
        return et["color"] if et else "#bbbbbb"

    # ---------- rosa ----------
    def player_label(self, num):
        if num is None or num == "":
            return ""
        for p in self.roster:
            if int(p["num"]) == int(num):
                return f"#{p['num']} {p['name']}".strip()
        return f"#{num}"

    # ---------- eventi ----------
    def add_event(self, type_name, t, duration, team="home", player=None, note=""):
        et = self.type_by_name(type_name) or {"pre": 5, "post": 5}
        ev = {
            "id": new_id(),
            "type": type_name,
            "t": round(float(t), 3),
            "start": round(max(0.0, t - float(et["pre"])), 3),
            "end": round(min(duration, t + float(et["post"])) if duration else t + float(et["post"]), 3),
            "team": team,
            "player": player,
            "note": note,
            "pos": None,
        }
        self.events.append(ev)
        self.events.sort(key=lambda e: e["t"])
        return ev

    def event(self, eid):
        for e in self.events:
            if e["id"] == eid:
                return e
        return None

    def remove_event(self, eid):
        self.events = [e for e in self.events if e["id"] != eid]

    def event_caption(self, ev):
        parts = [fmt_time(ev["t"]), ev["type"], self.teams.get(ev["team"], "")]
        pl = self.player_label(ev.get("player"))
        if pl:
            parts.append(pl)
        return "  ·  ".join(p for p in parts if p)

    # ---------- disegni ----------
    def add_drawing(self, d):
        d.setdefault("id", new_id())
        self.drawings.append(d)
        self.drawings.sort(key=lambda x: x["t"])
        return d

    def drawing(self, did):
        for d in self.drawings:
            if d["id"] == did:
                return d
        return None

    def remove_drawing(self, did):
        self.drawings = [d for d in self.drawings if d["id"] != did]
        used = {a["id"] for d in self.drawings for a in (d.get("anchors") or []) if a and a.get("type") == "track"}
        for tid in list(self.tracks):
            if tid not in used:
                del self.tracks[tid]

    def drawings_between(self, a, b):
        return [d for d in self.drawings if d["t"] < b and d["t"] + d["dur"] > a]

    # ---------- statistiche ----------
    def stats_matrix(self):
        """Ritorna (righe, colonne, conteggi) con righe = giocatori/squadre."""
        cols = [et["name"] for et in self.event_types]
        extra = sorted({e["type"] for e in self.events} - set(cols))
        cols += extra
        rows = []
        for team in ("home", "away"):
            nums = sorted({e["player"] for e in self.events if e["team"] == team and e.get("player") is not None},
                          key=lambda n: int(n))
            if team == "home":
                for p in self.roster:
                    if p["num"] not in nums:
                        nums.append(p["num"])
                nums = sorted(set(int(n) for n in nums))
            for n in nums:
                rows.append((team, n))
            if any(e["team"] == team and e.get("player") is None for e in self.events):
                rows.append((team, None))
            rows.append((team, "TOT"))
        counts = {}
        for r in rows:
            team, n = r
            for c in cols:
                if n == "TOT":
                    k = sum(1 for e in self.events if e["team"] == team and e["type"] == c)
                elif n is None:
                    k = sum(1 for e in self.events if e["team"] == team and e["type"] == c and e.get("player") is None)
                else:
                    k = sum(1 for e in self.events if e["team"] == team and e["type"] == c
                            and e.get("player") is not None and int(e["player"]) == int(n))
                counts[(r, c)] = k
        return rows, cols, counts

    def row_label(self, row):
        team, n = row
        tn = self.teams.get(team, team)
        if n == "TOT":
            return f"TOTALE {tn}"
        if n is None:
            return f"{tn} – senza giocatore"
        if team == "home":
            return self.player_label(n)
        return f"{tn} #{n}"

    # ---------- salvataggio ----------
    def to_dict(self):
        return {
            "version": VERSION,
            "video_path": self.video_path,
            "teams": self.teams,
            "roster": self.roster,
            "event_types": self.event_types,
            "events": self.events,
            "drawings": self.drawings,
            "tracks": {tid: {"from": t["from"], "to": t["to"], "lost_at": t.get("lost_at"),
                             "data": {str(k): [round(float(x), 5) for x in v] for k, v in t["data"].items()}}
                       for tid, t in self.tracks.items()},
            "calibrations": self.calibrations,
            "camera": self.camera,
            "pitch": self.pitch,
            "pitch_refs": self.pitch_refs,
            "cuts": self.cuts,
            "stills": self.stills,
        }

    def save(self, path=None):
        path = path or self.path
        if not path:
            return False
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
        self.path = path
        return True

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        p = cls.from_dict(d)
        p.path = path
        return p

    @classmethod
    def from_dict(cls, d):
        p = cls()
        p.video_path = d.get("video_path", "")
        p.teams = d.get("teams", p.teams)
        p.roster = d.get("roster", [])
        p.event_types = d.get("event_types") or copy.deepcopy(DEFAULT_EVENT_TYPES)
        p.events = d.get("events", [])
        p.drawings = d.get("drawings", [])
        p.tracks = {tid: {"from": int(t["from"]), "to": int(t["to"]), "lost_at": t.get("lost_at"),
                          "data": {int(k): v for k, v in t["data"].items()}}
                    for tid, t in (d.get("tracks") or {}).items()}
        p.calibrations = d.get("calibrations", [])
        p.camera = d.get("camera", {})
        p.pitch = d.get("pitch")
        p.pitch_refs = d.get("pitch_refs") or {}
        p.cuts = [[float(a), float(b)] for a, b in (d.get("cuts") or [])]
        p.stills = [dict(s) for s in (d.get("stills") or [])]
        # analisi vecchie: la pausa stava sui disegni -> diventa un fermo immagine vero
        for dw in p.drawings:
            pz = float(dw.get("pause", 0) or 0)
            if pz > 0:
                s = p.still_at(dw["t"], 0.002)
                if s:
                    s["dur"] = max(s["dur"], pz)
                else:
                    p.stills.append({"id": new_id(), "t": float(dw["t"]), "dur": pz})
                dw["pause"] = 0.0
                dw["freeze"] = True
        p.stills.sort(key=lambda s: s["t"])
        return p

    # ---------- fermi immagine ----------
    def still_at(self, t, tol):
        best = None
        for s in self.stills:
            if abs(s["t"] - t) <= tol and (best is None or abs(s["t"] - t) < abs(best["t"] - t)):
                best = s
        return best

    def still(self, sid):
        return next((s for s in self.stills if s["id"] == sid), None)

    def add_still(self, t, dur):
        s = {"id": new_id(), "t": round(float(t), 4), "dur": round(float(dur), 2)}
        self.stills.append(s)
        self.stills.sort(key=lambda x: x["t"])
        return s

    def remove_still(self, sid, with_drawings=True):
        s = self.still(sid)
        if not s:
            return
        self.stills = [x for x in self.stills if x["id"] != sid]
        if with_drawings:
            self.drawings = [d for d in self.drawings if not (d.get("freeze") and abs(d["t"] - s["t"]) < 0.002)]

    def still_drawings(self, s):
        return [d for d in self.drawings if d.get("freeze") and abs(d["t"] - s["t"]) < 0.002]

    # tempo "montato": il video con i fermi immagine inseriti (come lo vedi in riproduzione)
    def out_time(self, ts, elapsed=0.0):
        return ts + sum(s["dur"] for s in self.stills if s["t"] < ts - 1e-4) + elapsed

    def src_time(self, to):
        """Dal tempo montato al video: (secondi nel video, fermo immagine o None, secondi già passati nel fermo)."""
        acc = 0.0
        for s in self.stills:
            so = s["t"] + acc
            if to < so:
                break
            if to < so + s["dur"]:
                return s["t"], s, to - so
            acc += s["dur"]
        return to - acc, None, 0.0

    def stills_total(self):
        return sum(s["dur"] for s in self.stills)

    # ---------- pezzi tolti ----------
    def add_cut(self, a, b):
        """Toglie [a, b] (secondi), unendolo ai pezzi tolti che si toccano."""
        a, b = min(a, b), max(a, b)
        out = []
        for x, y in sorted(self.cuts + [[a, b]]):
            if out and x <= out[-1][1] + 1e-3:
                out[-1][1] = max(out[-1][1], y)
            else:
                out.append([x, y])
        self.cuts = out

    def cut_at(self, t):
        return next((c for c in self.cuts if c[0] <= t < c[1]), None)

    def kept_segments(self, a, b):
        """Parti di [a, b] che NON sono state tolte."""
        segs = [[a, b]]
        for x, y in self.cuts:
            nxt = []
            for s, e in segs:
                if y <= s or x >= e:
                    nxt.append([s, e])
                    continue
                if x > s:
                    nxt.append([s, x])
                if y < e:
                    nxt.append([y, e])
            segs = nxt
        return [s for s in segs if s[1] - s[0] > 0.05]

    # ---------- pannello condivisibile ----------
    def panel_dict(self):
        return {"tipo": "pannello-analisi-video", "teams": self.teams,
                "roster": self.roster, "event_types": self.event_types}

    def apply_panel(self, d):
        if "event_types" in d and d["event_types"]:
            self.event_types = d["event_types"]
        if "roster" in d:
            self.roster = d["roster"]
        if "teams" in d:
            self.teams = d["teams"]


def project_path_for_video(video_path):
    base = os.path.splitext(video_path)[0]
    return base + ".analisi.json"
