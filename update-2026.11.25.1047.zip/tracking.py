"""Riconoscimento dei giocatori (YOLO via OpenCV DNN) e inseguimento di un giocatore.

Il giocatore viene seguito fotogramma per fotogramma:
- si prevede dove sarà (velocità + movimento della telecamera);
- si cercano le persone in un ritaglio attorno alla previsione (il ritaglio ingrandito
  aiuta con i giocatori piccoli delle riprese larghe);
- si sceglie il candidato più vicino che ha anche i colori della maglia simili.
Se per qualche fotogramma non lo trova (contrasto, giocatore coperto) prosegue con la
previsione; se lo perde troppo a lungo si ferma e lo segnala.
"""
import os

import cv2
import numpy as np

from camera import apply
import cvsafe

import paths as _paths
def _pick_model():
    """YOLOX-s (licenza Apache 2.0, ok anche per un programma venduto); yolov8n solo come ripiego in sviluppo."""
    for n in ("yolox_s.onnx", "yolov8n.onnx"):
        p = os.path.join(_paths.models_dir(), n)
        if os.path.exists(p):
            return p
    return os.path.join(_paths.models_dir(), "yolox_s.onnx")


MODEL_PATH = _pick_model()


class Detector:
    _instance = None

    @classmethod
    def get(cls):
        if cls._instance is None:
            cls._instance = cls(MODEL_PATH)
        return cls._instance

    def __init__(self, path, size=640):
        if not os.path.exists(path):
            raise FileNotFoundError("Manca il modello per riconoscere i giocatori:\n" + path)
        self.net = cv2.dnn.readNetFromONNX(path)
        import threading
        self._lock = threading.Lock()
        self.size = size
        self.yolox = "yolox" in os.path.basename(path).lower()
        if self.yolox:     # YOLOX dà le uscite grezze: servono la griglia e il passo di ogni cella
            g, st = [], []
            for stride in (8, 16, 32):
                n = size // stride
                yv, xv = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
                g.append(np.stack([xv, yv], -1).reshape(-1, 2))
                st.append(np.full((n * n, 1), stride))
            self._grid = np.concatenate(g).astype(np.float32)
            self._stride = np.concatenate(st).astype(np.float32)

    def _run(self, img, conf=0.15):
        h, w = img.shape[:2]
        s = self.size / max(h, w)
        nw, nh = max(1, int(round(w * s))), max(1, int(round(h * s)))
        canvas = np.full((self.size, self.size, 3), 114, np.uint8)
        canvas[:nh, :nw] = cvsafe.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
        if self.yolox:   # BGR, valori 0-255
            blob = cv2.dnn.blobFromImage(canvas.astype(np.float32), 1.0, (self.size, self.size), swapRB=False)
        else:
            blob = cv2.dnn.blobFromImage(canvas, 1 / 255.0, (self.size, self.size), swapRB=True)
        with self._lock:  # la rete è una sola: due calcoli insieme da thread diversi la rompono
            self.net.setInput(blob)
            out = self.net.forward()[0]
        if self.yolox:
            xy = (out[:, :2] + self._grid) * self._stride
            wh = np.exp(out[:, 2:4]) * self._stride
            out = np.concatenate([xy, wh, (out[:, 4] * out[:, 5])[:, None]], 1)   # centro, misure, punteggio persona
            conf = max(conf, 0.22)
        else:
            out = out.T  # N x 84
        sc = out[:, 4]  # classe 0 = persona
        m = sc > conf
        b = out[m, :4]
        sc = sc[m]
        boxes = np.stack([(b[:, 0] - b[:, 2] / 2) / s, (b[:, 1] - b[:, 3] / 2) / s, b[:, 2] / s, b[:, 3] / s], 1) \
            if len(b) else np.zeros((0, 4))
        return boxes, sc

    @staticmethod
    def _nms(boxes, scores, thr=0.5):
        if not len(boxes):
            return boxes, scores
        idx = cv2.dnn.NMSBoxes(boxes.tolist(), scores.tolist(), 0.15, thr)
        idx = np.array(idx).flatten() if len(idx) else np.array([], int)
        boxes, scores = boxes[idx], scores[idx]
        # togli i "pezzi" di giocatore (testa, busto) contenuti quasi del tutto in un box più grande
        keep = []
        for i, (x, y, w, h) in enumerate(boxes):
            inside = False
            for j, (X, Y, Wb, Hb) in enumerate(boxes):
                if i == j or Hb <= h * 1.15:
                    continue
                ix = max(0, min(x + w, X + Wb) - max(x, X))
                iy = max(0, min(y + h, Y + Hb) - max(y, Y))
                if ix * iy > 0.7 * w * h:
                    inside = True
                    break
            if not inside:
                keep.append(i)
        return boxes[keep], scores[keep]

    def detect(self, frame):
        """Persone nell'intero fotogramma (tre passaggi: intero + due metà). Box in pixel x,y,w,h."""
        H, W = frame.shape[:2]
        allb, alls = [], []
        ov = int(W * 0.08)
        half = W // 2
        for x0, x1 in ((0, half + ov), (half - ov, W)):
            b, s = self._run(frame[:, x0:x1])
            b[:, 0] += x0
            allb.append(b)
            alls.append(s)
        b, s = self._run(frame)
        allb.append(b)
        alls.append(s)
        return self._nms(np.concatenate(allb), np.concatenate(alls))

    def detect_crop(self, frame, cx, cy, side):
        H, W = frame.shape[:2]
        side = int(max(160, min(side, max(H, W))))
        x0 = int(max(0, min(W - side, cx - side / 2)))
        y0 = int(max(0, min(H - side, cy - side / 2)))
        crop = frame[y0:y0 + side, x0:x0 + side]
        b, s = self._run(crop, conf=0.12)
        if len(b):
            b[:, 0] += x0
            b[:, 1] += y0
        return self._nms(b, s)


def _grass(hsv):
    return (hsv[..., 0] >= 30) & (hsv[..., 0] <= 90) & (hsv[..., 1] > 45) & (hsv[..., 2] > 35)


def _hist(frame, box):
    """Colori della maglia e dei pantaloncini, SENZA l'erba (nei giocatori piccoli il riquadro è
    pieno di erba e falsava il confronto). Colori vivi (tinta) + bianchi/grigi/neri (luminosità)."""
    x, y, w, h = [int(round(v)) for v in box]
    H, W = frame.shape[:2]
    x0, x1 = max(0, x + int(w * 0.15)), min(W, x + int(w * 0.85))
    feats = []
    for a, b in ((0.12, 0.5), (0.5, 0.75)):
        y0, y1 = max(0, y + int(h * a)), min(H, y + int(h * b))
        if x1 - x0 < 2 or y1 - y0 < 2:
            feats.append(np.full((16 * 4 + 8,), 1.0 / 72, np.float32))
            continue
        hsv = cv2.cvtColor(frame[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)
        keep = ~_grass(hsv)
        if keep.sum() < 4:
            keep[:] = True
        vivid = (hsv[..., 1] > 60) & (hsv[..., 2] > 50)
        c = cv2.calcHist([hsv], [0, 1], (keep & vivid).astype(np.uint8), [16, 4], [0, 180, 60, 256]).flatten()
        g = cv2.calcHist([hsv], [2], (keep & ~vivid).astype(np.uint8), [8], [0, 256]).flatten()
        f = np.concatenate([c, g]).astype(np.float32)
        f /= (f.sum() + 1e-6)
        feats.append(f)
    return np.concatenate(feats)


def _kit(frame, box):
    """Colore medio di maglia e pantaloncini rispetto all'erba lì attorno (così sole e ombra
    contano poco): [L maglia, a, b, L pantaloncini, a, b]."""
    x, y, w, h = [int(round(v)) for v in box]
    H, W = frame.shape[:2]
    X0, X1, Y0, Y1 = max(0, x - w // 2), min(W, x + w + w // 2), max(0, y), min(H, y + h)
    if X1 - X0 < 3 or Y1 - Y0 < 3:
        return None
    reg = frame[Y0:Y1, X0:X1]
    hsv = cv2.cvtColor(reg, cv2.COLOR_BGR2HSV)
    lab = cv2.cvtColor(reg, cv2.COLOR_BGR2LAB).astype(np.float32)
    gr = _grass(hsv)
    gl = float(np.median(lab[..., 0][gr])) if gr.sum() > 10 else 110.0
    out = []
    for a, b in ((0.15, 0.48), (0.5, 0.72)):
        ya, yb = max(0, y + int(h * a)) - Y0, min(H, y + int(h * b)) - Y0
        xa, xb = max(0, x + int(w * 0.2)) - X0, min(W, x + int(w * 0.8)) - X0
        if xb - xa < 1 or yb - ya < 1:
            return None
        m = ~gr[ya:yb, xa:xb]
        p = lab[ya:yb, xa:xb][m] if m.sum() >= 4 else lab[ya:yb, xa:xb].reshape(-1, 3)
        md = np.median(p, 0)
        out += [md[0] - gl, md[1] - 128, md[2] - 128]
    return np.array(out, np.float32)


def _kit_dist(a, b):
    """0 = stessi colori; oltre ~1,5 = quasi certamente un'altra squadra."""
    if a is None or b is None:
        return 0.0
    d = a - b
    return float(np.sqrt((d[0] / 38) ** 2 + (d[1] / 12) ** 2 + (d[2] / 12) ** 2 +
                         (d[3] / 45) ** 2 + (d[4] / 14) ** 2 + (d[5] / 14) ** 2) / 1.4)


def _hist_sim(a, b):
    return float(np.sum(np.sqrt(a * b)) / 2.0)  # Bhattacharyya (0..1)


def _pick_from(boxes, px, py):
    best, bd = None, 1e9
    for (x, y, w, h) in boxes:
        inside = x - w * 0.3 <= px <= x + w * 1.3 and y - h * 0.15 <= py <= y + h * 1.3
        d = np.hypot(px - (x + w / 2), py - (y + h * 0.75)) / max(h, 1)
        if inside and d < bd:
            best, bd = (x, y, w, h), d
    if best is None:
        # niente sotto il clic: il più vicino entro una distanza ragionevole
        for (x, y, w, h) in boxes:
            d = np.hypot(px - (x + w / 2), py - (y + h)) / max(h, 1)
            if d < 1.2 and d < bd:
                best, bd = (x, y, w, h), d
    return best


def pick_player(frame, nx, ny, det=None):
    """Trova il giocatore cliccato. Ritorna box in pixel o None.
    Prova più ingrandimenti: i giocatori piccoli o lontani si riconoscono meglio da vicino."""
    det = det or Detector.get()
    H, W = frame.shape[:2]
    px, py = nx * W, ny * H
    for side, conf in ((0.33 * H, 0.12), (0.18 * H, 0.10), (0.55 * H, 0.10)):
        bs, sc = det.detect_crop(frame, px, py, side) if conf == 0.12 else _crop_low(det, frame, px, py, side, conf)
        best = _pick_from([tuple(float(v) for v in b) for b in bs], px, py)
        if best is not None:
            return best
    return None


def _crop_low(det, frame, cx, cy, side, conf):
    """Come detect_crop ma con una soglia più bassa (per l'ultimo tentativo sul clic)."""
    H, W = frame.shape[:2]
    side = int(max(120, min(side, max(H, W))))
    x0 = int(max(0, min(W - side, cx - side / 2)))
    y0 = int(max(0, min(H - side, cy - side / 2)))
    b, s = det._run(frame[y0:y0 + side, x0:x0 + side], conf=conf)
    if len(b):
        b[:, 0] += x0
        b[:, 1] += y0
    return det._nms(b, s)


class PlayerTracker:
    """Insegue un giocatore un fotogramma alla volta.

    step(i) ritorna [x_piedi, y_piedi, altezza, conf] (normalizzati) oppure None quando il
    giocatore non si vede (coperto / fuori inquadratura): in quel caso continua a cercarlo e,
    quando ricompare, riprende.

    REGOLA: non scambia mai un giocatore in silenzio. Quando un altro giocatore gli arriva addosso
    (contrasto, incrocio, mucchio) l'inseguitore lo annota; quando si separano decide chi è chi
    guardando colori e direzione di corsa di PRIMA del contatto. Se non è sicuro si ferma con
    `reason == "doubt"` e in `doubt` mette i giocatori tra cui scegliere: sarà l'utente a
    indicare quello giusto con un clic.
    `finished` diventa True anche a un cambio di inquadratura o se resta introvabile a lungo.
    """

    NEAR = 1.0      # un altro giocatore entro questa distanza (in altezze) = contatto
    FREE = 1.5      # contatto finito quando nessuno è più vicino di così...
    FREE_N = 3      # ...per tanti fotogrammi di fila

    def __init__(self, reader, cam, start_idx, init_box, det=None, search_seconds=6.0, stride=1):
        self.reader, self.cam = reader, cam
        self.stride = max(1, int(stride))  # il giocatore si cerca un fotogramma ogni `stride`
        self.last_i = start_idx
        self.det = det or Detector.get()
        self.W, self.H = reader.width, reader.height
        fr = reader.frame(start_idx)
        init_box = _refine_box(self.det, fr, init_box)
        x, y, w, h = init_box
        self.model = _hist(fr, init_box)
        self.model0 = self.model.copy()  # aspetto iniziale: serve per ritrovarlo
        self.kit = _kit(fr, init_box)
        self.kit0 = None if self.kit is None else self.kit.copy()
        self.cur = np.array([x + w / 2, y + h], float)
        self.box = tuple(float(v) for v in init_box)
        self.hh = float(h)
        self.vel = np.zeros(2)
        self.lost = 0
        self.skip_ok = False
        self.k = 0
        self.i = start_idx
        self.max_coast = max(2, int(reader.fps * 1.0 / self.stride))
        self.max_search = int(reader.fps * search_seconds / self.stride)
        self.finished = False
        self.reason = ""
        self.doubt = None
        self.contact = None  # contatto in corso: {"start", "ghost", "vel", "free", "n"}
        self.after_cut = 0  # dopo un (possibile) taglio: breve ricerca severa nello stesso punto
        self.first = [self.cur[0] / self.W, self.cur[1] / self.H, self.hh / self.H, 1.0]
        self.near_other = 99.0
        self.was_contact = False
        self.kit_samples = []
        # partito su un giocatore attaccato a un altro? allora al primo distacco chiede chi è
        self.mixed = False
        bs, _ = self.det.detect_crop(fr, x + w / 2, y + h / 2, max(5 * h, 220))
        for b in bs:
            b = tuple(float(v) for v in b)
            if _iou(b, init_box) > 0.6 or _fragment(b, init_box) or _fragment(init_box, b):
                continue
            fb = np.array([b[0] + b[2] / 2, b[1] + b[3]])
            if _iou(b, init_box) > 0.12 or np.linalg.norm(fb - self.cur) / max(h, 8) < 0.6:
                self.mixed = True
        if self.mixed:
            self.contact = {"start": start_idx, "ghost": self.cur.copy(), "vel": np.zeros(2), "free": 0, "n": 0}
        self.log = []  # decisioni prese alla fine dei contatti (per controllo)

    # ---------------------------------------------------------------- utilità
    def _cam_pt(self, P, pt):
        q = apply(P, [[pt[0] / self.W, pt[1] / self.H]])
        return np.array([q[0][0] * self.W, q[0][1] * self.H])

    def _predict(self, i):
        P = None
        if self.cam is not None:
            for k in range(self.last_i + 1, i + 1):
                Pk = self.cam.pairs.get(k)
                if isinstance(Pk, str):
                    return None
                if Pk is not None:
                    P = Pk if P is None else Pk @ P
        pred = self.cur.copy()
        if P is not None:
            q = apply(P, [[self.cur[0] / self.W, self.cur[1] / self.H],
                          [self.cur[0] / self.W, (self.cur[1] - self.hh) / self.H]])
            pred = np.array([q[0][0] * self.W, q[0][1] * self.H])
            self.hh = max(6.0, abs(q[0][1] - q[1][1]) * self.H)
            if self.contact is not None:
                self.contact["ghost"] = self._cam_pt(P, self.contact["ghost"])
        return pred

    def _looks(self, frame, box):
        hb = _hist(frame, box)
        sim = max(_hist_sim(self.model, hb), _hist_sim(self.model0, hb))
        kd = 0.0
        if self.kit is not None and box[3] >= 1.5 * box[2]:  # riquadro tagliato: colori poco affidabili
            k = _kit(frame, box)
            kd = min(_kit_dist(self.kit, k), _kit_dist(self.kit0, k))
        return sim, kd

    def _app_cost(self, sim, kd):
        # colori molto diversi = quasi certamente l'altra squadra: costo molto alto
        return 2.4 * (1 - sim) + 2.0 * min(1.5, max(0.0, kd - 1.3))

    space_pt = None  # piedi dell'avversario più vicino (pixel), per misurare la distanza vera sul campo calibrato
    space = -1.0  # distanza dall'avversario più vicino, in "altezze del giocatore" sul terreno (-1 = nessuno vicino)

    def _out(self, conf=1.0):
        o = self.space_pt
        return [self.cur[0] / self.W, self.cur[1] / self.H, self.hh / self.H, conf, round(float(self.space), 2),
                round(float(o[0]) / self.W, 5) if o is not None else -1.0,
                round(float(o[1]) / self.H, 5) if o is not None else -1.0]

    # ---------------------------------------------------------------- passo
    def step(self, i):
        if self.finished:
            return None
        self.k += 1
        self.i = i
        base = self._predict(i)
        self.last_i = i
        if base is None:
            # cambio di inquadratura (o movimento troppo brusco): prova un attimo a ritrovarlo lì vicino
            self.after_cut = max(2, int(self.reader.fps * 0.6 / self.stride))
            self.lost = self.max_coast + 1
            self.vel = np.zeros(2)
            self.contact = None
            base = self.cur.copy()
        if self.after_cut:
            self.after_cut -= 1
            if self.after_cut == 0 and self.lost > 0:
                self.finished, self.reason = True, "cut"
                return None
        searching = self.lost > self.max_coast
        if self.contact is not None:
            self.contact["ghost"] = self.contact["ghost"] + self.contact["vel"]
            self.contact["vel"] = self.contact["vel"] * 0.97
        pred = base + (self.vel if not searching else 0)
        # salto di un fotogramma solo se è da solo e sicuro
        if not searching and self.skip_ok and self.stride == 1 and self.contact is None and \
                self.near_other > 3.0 and self.k % 2 == 0:
            self.cur = pred
            self.skip_ok = False
            return self._out()
        frame = self.reader.frame(i)
        if searching:
            grow = 1 + (self.lost - self.max_coast) * self.stride / self.reader.fps
            side = min(max(self.W, self.H), max(10 * self.hh * grow, 400))
            maxd = 2.5 + 2.5 * grow
        else:
            side = max(7.5 * self.hh, 240)
            maxd = 1.6
        boxes, scs = self.det.detect_crop(frame, pred[0], pred[1] - self.hh / 2, side)
        cands = []
        for bx in boxes:
            bx = tuple(float(v) for v in bx)
            foot = np.array([bx[0] + bx[2] / 2, bx[1] + bx[3]])
            dist = np.linalg.norm(foot - pred) / max(self.hh, 8)
            # riquadro più largo che alto = due giocatori uniti in uno: non può essere "il" giocatore
            merged = bx[3] < 1.25 * bx[2]
            cands.append({"box": bx, "foot": foot, "dist": dist, "merged": merged})
        hh = max(self.hh, 8)

        if searching:
            return self._search_step(frame, cands, pred, maxd)

        best, bcost = None, 1e9
        for c in cands:
            if c["dist"] > maxd:
                continue
            c["sim"], c["kd"] = self._looks(frame, c["box"])
            size = abs(np.log(max(c["box"][3], 1) / hh))
            c["cost"] = c["dist"] + self._app_cost(c["sim"], c["kd"]) + 0.8 * size
            if c["cost"] < bcost:
                best, bcost = c, c["cost"]
        if self.after_cut:
            ok = best is not None and best["sim"] > 0.85 and best["kd"] < 1.0 and best["dist"] < 2.5
        else:
            ok = best is not None and bcost < 2.0
        ref = best["foot"] if ok else pred
        others = [c for c in cands if c is not best and not (ok and _fragment(c["box"], best["box"]))]
        self.near_other = min([np.linalg.norm(c["foot"] - ref) / hh for c in others], default=99.0)
        if ok:
            # spazio libero: l'avversario (maglia diversa) più vicino, misurato sul terreno
            # (in profondità le distanze sullo schermo sono schiacciate: le riallargo)
            sp, sp_pt = -1.0, None
            for c in sorted(others, key=lambda c: np.linalg.norm(c["foot"] - ref))[:4]:
                if c["merged"]:
                    continue
                if "kd" not in c:
                    c["sim"], c["kd"] = self._looks(frame, c["box"])
                if c["kd"] > 1.0:
                    dx, dy = c["foot"] - ref
                    g = float(np.hypot(dx, dy / 0.38)) / hh
                    if sp < 0 or g < sp:
                        sp, sp_pt = g, c["foot"].copy()
            self.space, self.space_pt = sp, sp_pt
        # sovrapposizione dei riquadri = contatto anche se i piedi sono un po' lontani
        overlap = ok and any(_iou(c["box"], best["box"]) > 0.08 for c in others)
        touching = self.near_other < self.NEAR or overlap

        if self.contact is None and (touching or (not ok and self.near_other < self.NEAR * 1.3)):
            self.contact = {"start": i, "ghost": self.cur.copy(), "vel": self.vel.copy(), "free": 0, "n": 0}
        if self.contact is not None:
            self.contact["n"] += 1
            if touching or not ok:
                self.contact["free"] = 0
            elif self.near_other > self.FREE:
                self.contact["free"] += 1
            if self.contact["free"] >= self.FREE_N:
                res = self._resolve(frame, cands, ref)
                if self.finished:
                    return None  # dubbio: si ferma e chiede
                if res is not None:
                    if "cost" not in res:
                        res["cost"] = 1.0
                    best, ok = res, True

        if ok:
            in_contact = self.contact is not None
            if in_contact:
                # nel mucchio la velocità misurata non è affidabile: cambia poco
                self.vel = 0.85 * self.vel + 0.15 * (best["foot"] - base)
            else:
                self.vel = 0.6 * self.vel + 0.4 * (best["foot"] - base)
            self.cur = best["foot"]
            self.box = best["box"]
            self.hh = 0.7 * self.hh + 0.3 * best["box"][3]
            if not in_contact and self.near_other > 1.6 and best["cost"] < 0.9:
                # aspetto aggiornato SOLO quando è da solo (mai con un altro addosso)
                self.model = 0.92 * self.model + 0.08 * _hist(frame, best["box"])
                kt = _kit(frame, best["box"])
                if kt is not None and len(self.kit_samples) < 6 and best["box"][3] >= 1.5 * best["box"][2]:
                    # i primi fotogrammi da solo fissano bene i colori della maglia
                    self.kit_samples.append(kt)
                    if len(self.kit_samples) == 6:
                        self.kit = np.median(np.array(self.kit_samples), 0)
                        self.kit0 = self.kit.copy()
                elif kt is not None and self.kit is not None and _kit_dist(kt, self.kit) < 0.8:
                    self.kit = 0.9 * self.kit + 0.1 * kt
            self.skip_ok = bcost < 0.8 and self.reader.fps >= 24
            self.lost = 0
            self.after_cut = 0
            return self._out(1.0 if not in_contact else 0.9)
        self.skip_ok = False
        self.lost += 1
        self.cur = pred
        self.vel *= 0.85
        if self.lost > self.max_coast and self.contact is not None:
            # sparito dentro un mucchio: quando ricompare va riconosciuto con certezza
            self.was_contact = True
            self.contact = None
        if self.lost <= self.max_coast // 2:
            return self._out(0.5)
        return None

    def _search_step(self, frame, cands, pred, maxd):
        """Lo cerca dopo averlo perso. Lo riprende solo se è inconfondibile; se ci sono più
        giocatori che potrebbero essere lui, chiede."""
        hh = max(self.hh, 8)
        good = []
        for c in cands:
            if c["dist"] > maxd:
                continue
            # altezza compatibile: in un paio di secondi un giocatore non diventa alto il doppio
            # (vorrebbe dire che è un altro, molto più vicino o lontano dalla telecamera)
            if abs(np.log(max(c["box"][3], 1) / hh)) > 0.42:
                continue
            c["sim"], c["kd"] = self._looks(frame, c["box"])
            c["cost"] = 0.35 * c["dist"] + self._app_cost(c["sim"], c["kd"]) + \
                0.6 * abs(np.log(max(c["box"][3], 1) / hh))
            if c["sim"] > 0.78 and c["kd"] < 1.4:
                good.append(c)
        good.sort(key=lambda c: c["cost"])
        if good and (len(good) == 1 or good[1]["cost"] - good[0]["cost"] > 0.4):
            self.was_contact = False
            b = good[0]
            self.cur, self.box, self.hh = b["foot"], b["box"], float(b["box"][3])
            self.vel = np.zeros(2)
            self.lost = 0
            self.after_cut = 0
            self.contact = None
            return self._out()
        self.lost += 1
        self.cur = pred
        if len(good) >= 2 and (self.was_contact or self.lost > self.max_coast + int(self.reader.fps * 0.5 / self.stride)):
            return self._ask(frame, good, pred, "più giocatori simili")
        if self.lost > self.max_coast + self.max_search:
            self.finished, self.reason = True, "lost"
        return None

    def _resolve(self, frame, cands, ref):
        """Fine di un contatto: chi è il nostro giocatore?"""
        hh = max(self.hh, 8)
        ct = self.contact
        near = [c for c in cands if np.linalg.norm(c["foot"] - ref) / hh < 3.5]
        if not near:
            self.contact = None
            return self._first(cands, ref)
        frames = max(1, ct["n"])
        for c in near:
            if "sim" not in c:
                c["sim"], c["kd"] = self._looks(frame, c["box"])
            app = self._app_cost(c["sim"], c["kd"])
            # dove sarebbe andato correndo come prima del contatto (la direzione conta più col tempo corto)
            mv = np.linalg.norm(c["foot"] - ct["ghost"]) / hh
            w_mv = 0.9 / (1 + frames / (self.reader.fps * 1.0))
            c["score"] = app + w_mv * mv + 0.6 * np.linalg.norm(c["foot"] - ref) / hh
        near.sort(key=lambda c: c["score"])
        self.log.append({"idx": int(self.i), "start": int(ct["start"]),
                         "boxes": [c["box"] for c in near], "scores": [round(float(c["score"]), 2) for c in near],
                         "kd": [round(c["kd"], 2) for c in near], "sim": [round(c["sim"], 2) for c in near]})
        self.contact = None
        if len(near) == 1:
            self.mixed = False
            return near[0]
        if self.mixed:
            # partito con due giocatori attaccati: se ora sono ancora vicini e si somigliano, chiede
            self.mixed = False
            # (il primo aspetto era misto, quindi i colori non bastano: decide solo se l'altro è lontano)
            close = [c for c in near if np.linalg.norm(c["foot"] - ref) / hh < 2.5]
            if len(close) == 1:
                return close[0]
            return self._ask(frame, close or near, ref, "contatto")
        margin = near[1]["score"] - near[0]["score"]
        # avversario (colori diversi) contro compagno: decide il colore, è sicuro
        if near[0]["kd"] < 1.0 and near[1]["kd"] > 1.6 and near[0]["sim"] > 0.8:
            return near[0]
        if margin > 0.35:
            return near[0]
        return self._ask(frame, near, ref, "contatto")

    def _first(self, cands, ref):
        return min(cands, key=lambda c: np.linalg.norm(c["foot"] - ref)) if cands else None

    def _ask(self, frame, cands, ref, why):
        hh = max(self.hh, 8)
        cs = sorted(cands, key=lambda c: c.get("score", c.get("cost", c["dist"])))[:5]
        # i giocatori dell'altra squadra non sono tra le scelte, se ci sono compagni
        same = [c for c in cs if c.get("kd", 0) < 1.3]
        cs = same if same else cs
        self.finished, self.reason = True, "doubt"
        self.doubt = {"idx": int(self.i), "why": why,
                      "boxes": [[c["box"][0] / self.W, c["box"][1] / self.H,
                                 c["box"][2] / self.W, c["box"][3] / self.H] for c in cs],
                      "near": [float(ref[0] / self.W), float(ref[1] / self.H), float(hh / self.H)]}
        return None


def _refine_box(det, frame, box):
    """Il riquadro di partenza deve essere un giocatore intero e solo lui: se è troppo alto (due
    giocatori uno sopra l'altro) o tagliato, cerca quello giusto con i piedi nello stesso punto."""
    x, y, w, h = [float(v) for v in box]
    if 1.6 <= h / max(w, 1) <= 3.4:
        return (x, y, w, h)
    fx, fy = x + w / 2, y + h
    bs, _ = det.detect_crop(frame, fx, fy - h / 2, max(4 * h, 200))
    best, bd = None, 1e9
    for b in bs:
        if not 1.6 <= b[3] / max(b[2], 1) <= 3.4:
            continue
        d = np.hypot(b[0] + b[2] / 2 - fx, b[1] + b[3] - fy) / b[3]
        if d < 0.5 and d < bd:
            best, bd = tuple(float(v) for v in b), d
    return best or (x, y, w, h)


def _fragment(a, b):
    """a è un pezzo (testa, busto, gambe) del giocatore nel riquadro b."""
    ix = max(0.0, min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]))
    return a[3] < b[3] * 0.8 and ix * iy > 0.65 * a[2] * a[3]


def _iou(a, b):
    ix = max(0.0, min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]))
    inter = ix * iy
    return inter / (a[2] * a[3] + b[2] * b[3] - inter + 1e-6)


def track_player(reader, cam, start_idx, end_idx, init_box, progress=None, cancel=None, det=None):
    """Insegue il giocatore da start_idx a end_idx. Ritorna {idx: [x, y, h, conf]} normalizzati."""
    tr = PlayerTracker(reader, cam, start_idx, init_box, det)
    out = {start_idx: tr.first}
    n = max(1, end_idx - start_idx)
    for k, i in enumerate(range(start_idx + 1, end_idx + 1)):
        if (cancel and cancel()) or tr.finished:
            break
        v = tr.step(i)
        if v is not None:
            out[i] = v
        if progress and k % 3 == 0:
            progress(k / n)
    return smooth_track(out)


def smooth_track(pts, win=2):
    """Media mobile centrata per togliere il tremolio delle box."""
    if len(pts) < 3:
        return pts
    keys = sorted(pts)
    arr = np.array([pts[k][:3] for k in keys])
    sm = arr.copy()
    for j in range(len(keys)):
        a, b = max(0, j - win), min(len(keys), j + win + 1)
        # non mescolare punti separati da un buco (giocatore ritrovato altrove)
        while keys[j] - keys[a] > j - a:
            a += 1
        while keys[b - 1] - keys[j] > b - 1 - j:
            b -= 1
        sm[j] = arr[a:b].mean(0)
    return {k: [float(sm[j][0]), float(sm[j][1]), float(sm[j][2]), pts[k][3]] for j, k in enumerate(keys)}


class SpaceMeter:
    """Spazio libero di un giocatore seguito: distanza dall'avversario più vicino, fotogramma per fotogramma.

    Si lavora in tre passi, perché guardare un fotogramma alla volta sbaglia spesso squadra:
    1. scan(): in ogni fotogramma campione trova i giocatori attorno e i colori di maglia e pantaloncini;
    2. le maglie di TUTTI i fotogrammi vengono divise in due squadre (così un riflesso o un'ombra in un
       fotogramma non fa cambiare squadra a un giocatore) e la squadra del giocatore seguito è la sua;
    3. la distanza viene ripulita dai salti (mediana su un secondo) e riempita per ogni fotogramma,
       così il cerchio si allarga e si stringe in modo continuo.
    """
    S = np.array([38, 12, 12, 45, 14, 14], np.float32)   # scala dei colori, come in _kit_dist
    CAP = 3.5                                             # nessun avversario vicino: cerchio largo 3,5 altezze

    def __init__(self):
        self.det = Detector.get()

    def scan(self, frame, foot, h):
        H, W = frame.shape[:2]
        fx, fy = float(foot[0]), float(foot[1])
        h = max(8.0, float(h))
        side = max(320.0, min(float(max(H, W)), 14.0 * h))
        bs, _sc = self.det.detect_crop(frame, fx, fy - h / 2, side)
        boxes = [tuple(float(v) for v in b) for b in bs]
        own, bd = None, 1e9
        for b in boxes:
            dd = float(np.hypot(b[0] + b[2] / 2 - fx, b[1] + b[3] - fy))
            if dd < bd:
                own, bd = b, dd
        if own is None or bd > 0.6 * h:
            own = None
        others = []
        for b in boxes:
            if b is own or not (0.45 * h <= b[3] <= 2.2 * h):
                continue
            bx, by = b[0] + b[2] / 2, b[1] + b[3]
            if own is None and np.hypot(bx - fx, by - fy) < 0.3 * h:
                continue
            # solo chi ha i piedi sull'erba: via il pubblico in tribuna, le panchine, i cartelloni
            x0, x1 = int(max(0, bx - 0.4 * b[2])), int(min(W, bx + 0.4 * b[2]))
            y0, y1 = int(max(0, by - 0.05 * b[3])), int(min(H, by + 0.18 * b[3]))
            if x1 - x0 < 2 or y1 - y0 < 2:
                continue
            if _grass(cv2.cvtColor(frame[y0:y1, x0:x1], cv2.COLOR_BGR2HSV)).mean() < 0.4:
                continue
            k = _kit(frame, b)
            if k is not None:
                others.append((bx, by, k))
        return {"foot": (fx, fy), "h": h, "others": others,
                "own": _kit(frame, own if own is not None else (fx - 0.2 * h, fy - h, 0.4 * h, h))}

    @classmethod
    def _teams(cls, scans):
        """Divide le maglie viste in due squadre. Ritorna (centro mia squadra, centro avversari) o None."""
        own = [s["own"] for s in scans if s["own"] is not None]
        oth = [k for s in scans for (_x, _y, k) in s["others"]]
        if not own or len(oth) < 6:
            return None
        me = np.median(np.array(own), 0) / cls.S
        X = np.array(oth) / cls.S
        c0, c1 = me.copy(), X[int(np.argmax(np.linalg.norm(X - me, axis=1)))].copy()
        for _ in range(15):
            a = np.linalg.norm(X - c1, axis=1) < np.linalg.norm(X - c0, axis=1)
            n0 = np.vstack([X[~a], me[None]]).mean(0)   # il giocatore seguito tira il centro della sua squadra
            n1 = X[a].mean(0) if a.any() else c1
            if np.allclose(n0, c0) and np.allclose(n1, c1):
                break
            c0, c1 = n0, n1
        if np.linalg.norm(c0 - c1) / 1.4 < 0.9:
            return None   # attorno ci sono solo maglie simili: non si distinguono due squadre
        return c0, c1

    @classmethod
    def solve(cls, scans):
        """Per ogni campione: (distanza dall'avversario più vicino in pixel "a terra", scarto dx, dy) o None."""
        teams = cls._teams(scans)
        own = [s["own"] for s in scans if s["own"] is not None]
        me = (np.median(np.array(own), 0) if own else None)
        out = []
        for s in scans:
            fx, fy = s["foot"]
            best = None
            for bx, by, k in s["others"]:
                if teams is not None:
                    q = k / cls.S
                    opp = np.linalg.norm(q - teams[1]) < np.linalg.norm(q - teams[0])
                else:
                    opp = me is not None and _kit_dist(me, k) > 1.0
                if not opp:
                    continue
                g = float(np.hypot(bx - fx, (by - fy) / 0.38))   # in profondità le distanze sono schiacciate
                if best is None or g < best[0]:
                    best = (g, bx - fx, by - fy)
            out.append(best)
        return out

    @classmethod
    def series(cls, keys, scans, feet, W, H):
        """keys = fotogrammi campione (ordinati), feet = {fotogramma: (x, y) piedi in pixel} per TUTTI i
        fotogrammi. Ritorna {fotogramma: [raggio / larghezza video, x avversario 0..1, y avversario 0..1]}."""
        if not keys:
            return {}
        raw = cls.solve(scans)
        hmed = float(np.median([s["h"] for s in scans]))
        cap = cls.CAP * hmed
        g = np.array([min(cap, r[0]) if r is not None else cap for r in raw])
        n = len(g)
        # un avversario non può allontanarsi (o essere stato lontano) più di ~5 m in un quinto di secondo:
        # se sparisce per un attimo (coperto, in contrasto con il giocatore) il cerchio non salta largo
        rate = 1.0 * hmed
        for i in range(1, n):
            g[i] = min(g[i], g[i - 1] + rate)
        for i in range(n - 2, -1, -1):
            g[i] = min(g[i], g[i + 1] + rate)
        med, src = np.empty(n), []
        for i in range(n):                                  # mediana su 3 misure (0,6 s): via i salti isolati
            lo, hi = max(0, i - 1), min(n, i + 2)
            order = np.argsort(g[lo:hi])
            j = lo + int(order[len(order) // 2])
            med[i] = g[j]
            src.append(j)
        sm = med   # tra una misura e l'altra il raggio cambia in linea retta: continuo, senza ritardo
        offs = [None if raw[j] is None or raw[j][0] >= cap else (raw[j][1], raw[j][2]) for j in src]
        for i in range(n):          # avversario non visto in questo campione: tengo la direzione del campione vicino
            if offs[i] is None and sm[i] < cap * 0.98:
                near = [offs[j] for j in (i - 1, i + 1, i - 2, i + 2) if 0 <= j < n and offs[j] is not None]
                if near:
                    L = float(np.hypot(near[0][0], near[0][1] / 0.38)) or 1.0
                    offs[i] = (near[0][0] * sm[i] / L, near[0][1] * sm[i] / L)
        out = {}
        ks = np.array(keys, float)
        for k in sorted(feet):
            i = int(np.clip(np.searchsorted(ks, k, side="right") - 1, 0, n - 1))
            i2 = min(n - 1, i + 1)
            t = 0.0 if i2 == i or k <= ks[i] else min(1.0, (k - ks[i]) / (ks[i2] - ks[i]))
            r = sm[i] * (1 - t) + sm[i2] * t
            a, b = offs[i], offs[i2]
            if a is not None and b is not None:
                o = (a[0] * (1 - t) + b[0] * t, a[1] * (1 - t) + b[1] * t)
            else:
                o = a if (a is not None and t < 0.5) else (b if b is not None and t >= 0.5 else None)
            fx, fy = feet[k]
            out[k] = [round(float(r) / W, 5),
                      round((fx + o[0]) / W, 5) if o is not None else -1.0,
                      round((fy + o[1]) / H, 5) if o is not None else -1.0]
        return out
