"""Audio del video mentre lavori: suona insieme alle immagini, si ferma sui fermi immagine,
segue i salti (pezzi tolti, clic sulla linea del tempo) e la velocità.

Le immagini restano quelle del programma (OpenCV); qui si riproduce solo il suono dello stesso file.
Se Qt Multimedia non c'è o il file non ha audio, tutto continua a funzionare in silenzio.
"""
from PySide6.QtCore import QUrl

import os

try:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    OK = not os.environ.get("ANALISI_NO_AUDIO")  # per le prove senza scheda audio
except Exception:  # pragma: no cover
    OK = False

DRIFT = 0.30  # secondi di scarto oltre i quali si riallinea il suono alle immagini


class Audio:
    def __init__(self, parent=None):
        self.ok = OK
        self.muted = False
        self.volume = 0.8
        self.path = None
        self._on = False  # dovrebbe suonare adesso
        if not OK:
            return
        self.out = QAudioOutput(parent)
        self.out.setVolume(self.volume)
        self.player = QMediaPlayer(parent)
        self.player.setAudioOutput(self.out)

    def load(self, path):
        if not self.ok:
            return
        self._on = False
        self.player.stop()
        self.path = path
        self.player.setSource(QUrl.fromLocalFile(path) if path else QUrl())

    def close(self):
        self.load(None)

    def set_muted(self, m):
        self.muted = bool(m)
        if self.ok:
            self.out.setMuted(self.muted)

    def set_volume(self, v):
        self.volume = max(0.0, min(1.0, float(v)))
        if self.ok:
            self.out.setVolume(self.volume)

    def play_at(self, t, rate=1.0):
        """Fa partire il suono dal secondo t del video."""
        if not self.ok or not self.path:
            return
        self._on = True
        # a velocità molto diverse dal normale il suono è inutile: resta muto
        self.out.setMuted(self.muted or not (0.5 <= rate <= 2.0))
        if abs(self.player.playbackRate() - rate) > 1e-3:
            self.player.setPlaybackRate(rate)
        self.player.setPosition(int(max(0.0, t) * 1000))
        self.player.play()

    def pause(self):
        if not self.ok:
            return
        self._on = False
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()

    def set_rate(self, rate):
        if not self.ok:
            return
        self.player.setPlaybackRate(rate)
        self.out.setMuted(self.muted or not (0.5 <= rate <= 2.0))

    def sync(self, t):
        """Chiamato durante la riproduzione: se il suono si è staccato dalle immagini lo riallinea."""
        if not self.ok or not self.path or not self._on:
            return
        if self.player.playbackState() != QMediaPlayer.PlayingState:
            self.player.setPosition(int(t * 1000))
            self.player.play()
            return
        if abs(self.player.position() / 1000.0 - t) > DRIFT:
            self.player.setPosition(int(t * 1000))

    def keep(self, t, rate=1.0):
        """Durante la riproduzione: se il suono è fermo lo fa ripartire, altrimenti lo tiene allineato."""
        if not self.ok or not self.path:
            return
        if not self._on:
            self.play_at(t, rate)
        else:
            self.sync(t)
