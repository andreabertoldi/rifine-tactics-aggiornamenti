"""Dove il programma scrive i suoi file (registri, errori, prove).

Avviato da Python (come sul Mac di Andrea) è la cartella AnalisiVideo, accanto ad «app». Nell'applicazione
costruita (Analisi Video.app) dentro il pacchetto non si può scrivere: si usa la cartella di sistema
~/Library/Application Support/AnalisiVideoCalcio.
"""
import os
import sys

FROZEN = bool(getattr(sys, "frozen", False))
if FROZEN:
    BASE = os.path.join(os.path.expanduser("~/Library/Application Support"), "AnalisiVideoCalcio")
else:
    BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.makedirs(BASE, exist_ok=True)


def base(*parts):
    return os.path.join(BASE, *parts)


def models_dir():
    """Cartella dei modelli (YOLO, SAM 2): nell'app costruita sta dentro il pacchetto, anche dopo un aggiornamento."""
    if FROZEN:
        return os.path.join(getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable))), "models")
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
