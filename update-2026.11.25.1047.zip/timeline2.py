"""Linea del tempo a righe (come DigitalLog): Video con i fermi immagine, Disegni, Testi, Giocatori.

Il tempo orizzontale è quello "montato": il video con i fermi immagine inseriti, come lo vedi in riproduzione.
"""
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import QSizePolicy, QToolTip, QWidget

from model import fmt_time

ROWS = [("video", "🎞  Video"), ("draw", "✏️  Disegni"), ("text", "Aa  Testi"), ("players", "🏃  Giocatori")]
PLAYER_KINDS = ("spotlight", "distanza", "collega", "visuale", "palla")
LABEL_W = 96
RULER_H = 20
ROW_H = 28
ROW_MIN = 14
ROW_MAX = 44
EDGE = 6


def row_of(d):
    if d["kind"] == "testo":
        return "text"
    if d["kind"] in PLAYER_KINDS:
        return "players"
    return "draw"


class TrackTimeline(QWidget):
    seek = Signal(float)                 # tempo montato
    cutMenu = Signal(float, object)      # tempo nel video, posizione
    drawingClicked = Signal(str)
    drawingEdited = Signal(str)
    drawingMenu = Signal(str, object)
    stillClicked = Signal(str)
    stillEdited = Signal(str)
    stillMenu = Signal(str, object)
    stillDouble = Signal(str)
    pieceEdited = Signal(object, object)  # inizio e fine del pezzo segnato (tempi del video), dopo uno spostamento

    def __init__(self, parent=None):
        super().__init__(parent)
        # l'altezza si può cambiare trascinando il bordo sopra la linea del tempo: le righe si adattano
        self.setMinimumHeight(RULER_H + ROW_MIN * len(ROWS) + 6)
        self.setMaximumHeight(RULER_H + ROW_MAX * len(ROWS) + 6)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self.project = None
        self.duration = 0.0      # durata del video (senza fermi)
        self.t = 0.0             # cursore, tempo montato
        self.drawings = []
        self.cuts = []
        self.piece = (None, None)
        self.selected_id = None
        self.events, self.colors, self.selected = [], {}, set()  # compatibilità
        self.v0, self.v1 = 0.0, 0.0  # finestra visibile (zoom)
        self._drag = None
        self.playing = False

    # ---------- tempi ----------
    def total(self):
        st = self.project.stills_total() if self.project else 0.0
        return self.duration + st

    def out(self, ts):
        return self.project.out_time(ts) if self.project else ts

    def src(self, to):
        return self.project.src_time(to)[0] if self.project else to

    def _win(self):
        tot = self.total()
        if self.v1 <= self.v0 or self.v1 > tot + 1e-6 or self.v0 < 0:
            self.v0, self.v1 = 0.0, tot
        return self.v0, self.v1

    def x_for(self, to):
        v0, v1 = self._win()
        w = self.width() - LABEL_W - 10
        return LABEL_W + 4 + w * ((to - v0) / (v1 - v0) if v1 > v0 else 0)

    def t_for(self, x):
        v0, v1 = self._win()
        w = max(1, self.width() - LABEL_W - 10)
        return max(0.0, min(self.total(), v0 + (x - LABEL_W - 4) / w * (v1 - v0)))

    def row_rect(self, key):
        i = [k for k, _ in ROWS].index(key)
        rh = self.row_h()
        return QRectF(LABEL_W, RULER_H + i * rh, self.width() - LABEL_W - 2, rh - 2)

    def row_h(self):
        return max(ROW_MIN, min(ROW_MAX, (self.height() - RULER_H - 6) / len(ROWS)))

    def sizeHint(self):
        from PySide6.QtCore import QSize
        return QSize(600, RULER_H + ROW_H * len(ROWS) + 6)

    # ---------- zoom ----------
    def zoom(self, factor, center=None):
        tot = self.total()
        if tot <= 0:
            return
        v0, v1 = self._win()
        c = self.t if center is None else center
        span = max(2.0, min(tot, (v1 - v0) * factor))
        a = c - (c - v0) * span / (v1 - v0)
        a = max(0.0, min(tot - span, a))
        self.v0, self.v1 = a, a + span
        self.update()

    def fit(self):
        self.v0, self.v1 = 0.0, self.total()
        self.update()

    def follow_cursor(self):
        v0, v1 = self._win()
        if v1 - v0 >= self.total() - 1e-6:
            return
        if not (v0 <= self.t <= v1):
            span = v1 - v0
            a = max(0.0, min(self.total() - span, self.t - span * 0.1))
            self.v0, self.v1 = a, a + span

    def wheelEvent(self, ev):
        dy = ev.angleDelta().y()
        dx = ev.angleDelta().x()
        if abs(dx) > abs(dy) or ev.modifiers() & Qt.ShiftModifier:
            v0, v1 = self._win()
            span = v1 - v0
            sh = -(dx or dy) / 120 * span * 0.1
            a = max(0.0, min(self.total() - span, v0 + sh))
            self.v0, self.v1 = a, a + span
            self.update()
        elif dy:
            self.zoom(0.8 if dy > 0 else 1.25, self.t_for(ev.position().x()))

    # ---------- oggetti ----------
    def _bars(self):
        """[(rect, kind, obj)] per i clic e il disegno."""
        out = []
        if not self.project:
            return out
        r = self.row_rect("video")
        for s in self.project.stills:
            a = self.out(s["t"])
            out.append((QRectF(self.x_for(a), r.top() + 3, max(4, self.x_for(a + s["dur"]) - self.x_for(a)),
                               r.height() - 6), "still", s))
        lanes = {}
        items = []
        for d in sorted(self.drawings, key=lambda d: d["t"]):
            if d.get("freeze"):
                s = self.project.still_at(d["t"], 0.002)
                a = self.out(d["t"])
                b = a + (s["dur"] if s else 0.3)
            else:
                a = self.out(d["t"])
                b = self.out(d["t"] + d["dur"])
            key = row_of(d)
            ends = lanes.setdefault(key, [])
            lane = next((i for i, e in enumerate(ends) if e <= a), None)
            if lane is None:
                lane = len(ends)
                ends.append(b)
            else:
                ends[lane] = b
            items.append((key, lane, a, b, d))
        # ogni corsia che si sovrappone va in una riga propria: niente barre sovrapposte
        for key, lane, a, b, d in items:
            rr = self.row_rect(key)
            nl = max(3, len(lanes.get(key, [])))
            lh = (rr.height() - 4) / nl
            out.append((QRectF(self.x_for(a), rr.top() + 2 + lane * lh, max(4, self.x_for(b) - self.x_for(a)),
                               lh - 1), "drawing", d))
        return out

    def _hit(self, pos):
        for rect, kind, obj in reversed(self._bars()):
            if rect.adjusted(-2, -1, 2, 1).contains(pos):
                edge = abs(pos.x() - rect.right()) <= EDGE and not (kind == "drawing" and obj.get("freeze"))
                return kind, obj, rect, edge
        return None

    # ---------- disegno ----------
    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        W, H = self.width(), self.height()
        p.fillRect(self.rect(), QColor("#1a1d23"))
        f = QFont()
        f.setPointSize(9)
        p.setFont(f)
        # etichette righe
        for i, (key, name) in enumerate(ROWS):
            rh = self.row_h()
            y = RULER_H + i * rh
            p.fillRect(QRectF(0, y, W, rh - 2), QColor("#20242c" if i % 2 == 0 else "#1d2128"))
            p.setPen(QColor("#9aa3b2"))
            p.drawText(QRectF(8, y, LABEL_W - 8, rh - 2), Qt.AlignVCenter | Qt.AlignLeft, name)
        p.setPen(QPen(QColor("#2c323d"), 1))
        p.drawLine(QPointF(LABEL_W, 0), QPointF(LABEL_W, H))
        tot = self.total()
        if not tot:
            return
        v0, v1 = self._win()
        p.setClipRect(QRectF(LABEL_W + 1, 0, W - LABEL_W, H))
        # righello
        span = v1 - v0
        step = next((c for c in (0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800) if span / c <= 12), 1800)
        p.setPen(QPen(QColor("#565e6c"), 1))
        k = int(v0 // step)
        while k * step <= v1 + 1e-6:
            tt = k * step
            x = self.x_for(tt)
            p.drawLine(QPointF(x, RULER_H - 6), QPointF(x, RULER_H))
            lbl = fmt_time(tt) if step >= 1 else fmt_time(tt, True)
            p.drawText(QRectF(x + 3, 2, 60, RULER_H - 6), Qt.AlignLeft | Qt.AlignVCenter, lbl)
            k += 1
        # video: pezzi blu tra i fermi immagine
        r = self.row_rect("video")
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#3d6fd6"))
        p.drawRoundedRect(QRectF(self.x_for(0), r.top() + 3, self.x_for(tot) - self.x_for(0), r.height() - 6), 4, 4)
        # pezzi tolti
        for a, b in self.cuts:
            xa, xb = self.x_for(self.out(a)), self.x_for(self.out(b))
            rr = QRectF(xa, r.top() + 3, max(2, xb - xa), r.height() - 6)
            p.setBrush(QColor(10, 10, 12, 220))
            p.drawRect(rr)
            p.setBrush(QBrush(QColor(255, 82, 82, 150), Qt.BDiagPattern))
            p.drawRect(rr)
        # barre
        for rect, kind, obj in self._bars():
            if kind == "still":
                p.setPen(QPen(QColor("#ffb74d"), 1))
                p.setBrush(QColor("#ff9100"))
                p.drawRoundedRect(rect, 4, 4)
                p.setPen(QColor("#16191f"))
                if rect.width() > 34:
                    p.drawText(rect, Qt.AlignCenter, f"⏸ {obj['dur']:g}s")
                continue
            col = QColor(obj.get("color", "#ffeb3b"))
            if col.lightness() < 40:
                col = QColor("#8a93a3")
            sel = obj["id"] == self.selected_id
            p.setPen(QPen(QColor("white"), 2) if sel else Qt.NoPen)
            c2 = QColor(col)
            c2.setAlpha(235 if sel else 190)
            p.setBrush(c2)
            p.drawRoundedRect(rect, 3, 3)
            if obj.get("freeze"):
                p.setPen(QPen(QColor("#ff9100"), 1, Qt.DotLine))
                p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(rect, 3, 3)
        # pezzo Inizio / Fine
        pa, pb = self.piece
        if pa is not None or pb is not None:
            xa = self.x_for(self.out(pa)) if pa is not None else LABEL_W
            xb = self.x_for(self.out(pb)) if pb is not None else W
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(61, 126, 255, 55))
            p.drawRect(QRectF(xa, RULER_H, max(2, xb - xa), H - RULER_H))
            p.setPen(QPen(QColor("#6d9dff"), 2))
            if pa is not None:
                p.drawLine(QPointF(xa, 0), QPointF(xa, H))
            if pb is not None:
                p.drawLine(QPointF(xb, 0), QPointF(xb, H))
        # cursore
        x = self.x_for(self.t)
        p.setPen(QPen(QColor("#e040fb"), 2))
        p.drawLine(QPointF(x, 6), QPointF(x, H))
        p.setBrush(QColor("#e040fb"))
        p.setPen(Qt.NoPen)
        p.drawPolygon([QPointF(x - 5, 2), QPointF(x + 5, 2), QPointF(x, 9)])

    # ---------- mouse ----------
    def _piece_edge(self, x):
        """0 = bordo Inizio, 1 = bordo Fine del pezzo segnato, se il mouse è vicino (6 px)."""
        best = None
        for i, v in enumerate(self.piece):
            if v is None:
                continue
            d = abs(self.x_for(self.out(v)) - x)
            if d <= 6 and (best is None or d < best[1]):
                best = (i, d)
        return best[0] if best else None

    def mousePressEvent(self, ev):
        if not self.total():
            return
        pos = ev.position()
        if pos.x() < LABEL_W:
            return
        if ev.button() == Qt.LeftButton and self._piece_edge(pos.x()) is not None:
            self._drag = ("piece", self._piece_edge(pos.x()))
            return
        hit = self._hit(pos) if pos.y() > RULER_H else None
        if ev.button() == Qt.RightButton:
            return  # menu: contextMenuEvent
        if ev.button() != Qt.LeftButton:
            return
        if hit:
            kind, obj, rect, edge = hit
            if kind == "still":
                self.stillClicked.emit(obj["id"])
                self._drag = ("still_edge", obj, pos.x(), obj["dur"]) if edge else ("seek",)
                if not edge:
                    self.seek.emit(self.t_for(pos.x()))
                return
            self.selected_id = obj["id"]
            self.drawingClicked.emit(obj["id"])
            if obj.get("freeze"):
                self._drag = None
            elif edge:
                self._drag = ("dr_edge", obj, pos.x(), obj["dur"])
            else:
                self._drag = ("dr_move", obj, pos.x(), obj["t"])
            self.update()
            return
        self._drag = ("seek",)
        self.seek.emit(self.t_for(pos.x()))

    def mouseDoubleClickEvent(self, ev):
        hit = self._hit(ev.position())
        if hit and hit[0] == "still":
            self.stillDouble.emit(hit[1]["id"])

    def mouseMoveEvent(self, ev):
        pos = ev.position()
        d = self._drag
        if d:
            if d[0] == "seek":
                self.seek.emit(self.t_for(pos.x()))
            elif d[0] == "piece":
                ts = round(self.src(self.t_for(pos.x())), 3)
                a, b = self.piece
                gap = 0.2
                if d[1] == 0:
                    a = ts if b is None else min(ts, b - gap)
                else:
                    b = ts if a is None else max(ts, a + gap)
                self.piece = (max(0.0, a) if a is not None else None, b)
                self.pieceEdited.emit(*self.piece)
                self.seek.emit(self.out(self.piece[d[1]]))   # il video mostra il fotogramma dove stai spostando
                self.update()
            elif d[0] == "still_edge":
                dt = self.t_for(pos.x()) - self.t_for(d[2])
                d[1]["dur"] = round(max(0.3, d[3] + dt), 2)
                self.update()
            elif d[0] == "dr_edge":
                obj = d[1]
                end_out = self.out(obj["t"]) + (self.out(obj["t"] + d[3]) - self.out(obj["t"])) + \
                    (self.t_for(pos.x()) - self.t_for(d[2]))
                obj["dur"] = round(max(0.3, self.src(end_out) - obj["t"]), 2)
                self.update()
            elif d[0] == "dr_move":
                obj = d[1]
                start_out = self.out(d[3]) + self.t_for(pos.x()) - self.t_for(d[2])
                obj["t"] = round(max(0.0, min(self.duration - 0.1, self.src(start_out))), 3)
                self.update()
            return
        if pos.x() < LABEL_W or not self.total():
            QToolTip.hideText()
            return
        if self._piece_edge(pos.x()) is not None:
            self.setCursor(Qt.SizeHorCursor)
            QToolTip.showText(ev.globalPosition().toPoint(), "Trascina per spostare l'inizio o la fine del pezzo", self)
            return
        hit = self._hit(pos) if pos.y() > RULER_H else None
        if hit:
            kind, obj, rect, edge = hit
            self.setCursor(Qt.SizeHorCursor if edge else Qt.PointingHandCursor)
            if kind == "still":
                tip = f"⏸ Fermo immagine {obj['dur']:g} s — trascina il bordo destro per allungarlo, " \
                      f"doppio clic per la durata, tasto destro per toglierlo"
            elif obj.get("freeze"):
                tip = "Disegno dentro il fermo immagine (si vede finché il video è fermo)"
            else:
                tip = f"Disegno: appare a {fmt_time(obj['t'], True)}, resta {obj['dur']:g} s — trascinalo per " \
                      f"spostarlo, tira il bordo destro per allungarlo, tasto destro per eliminarlo"
            QToolTip.showText(ev.globalPosition().toPoint(), tip, self)
            return
        self.unsetCursor()
        to = self.t_for(pos.x())
        ts, st, _el = self.project.src_time(to) if self.project else (to, None, 0)
        c = next(((a, b) for a, b in self.cuts if a <= ts < b), None)
        if c:
            QToolTip.showText(ev.globalPosition().toPoint(),
                              f"✂ Pezzo tolto {fmt_time(c[0])} – {fmt_time(c[1])} (tasto destro per rimetterlo)", self)
        else:
            QToolTip.showText(ev.globalPosition().toPoint(), fmt_time(to, True), self)

    def mouseReleaseEvent(self, ev):
        d = self._drag
        self._drag = None
        if not d:
            return
        if d[0] == "still_edge":
            self.stillEdited.emit(d[1]["id"])
        elif d[0] in ("dr_edge", "dr_move"):
            self.drawingEdited.emit(d[1]["id"])

    def contextMenuEvent(self, ev):
        pos = QPointF(ev.pos())
        if pos.x() < LABEL_W or not self.total():
            return
        hit = self._hit(pos) if pos.y() > RULER_H else None
        gp = ev.globalPos()
        if hit:
            if hit[0] == "still":
                self.stillMenu.emit(hit[1]["id"], gp)
            else:
                self.drawingMenu.emit(hit[1]["id"], gp)
            return
        ts = self.src(self.t_for(pos.x()))
        if any(a <= ts < b for a, b in self.cuts):
            self.cutMenu.emit(ts, gp)
