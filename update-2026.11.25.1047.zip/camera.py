"""Stima del movimento della telecamera (panoramica / zoom) tra fotogrammi consecutivi.

Per ogni coppia (i-1 -> i) si calcola un'omografia H tale che  p_i = H @ p_{i-1}
(coordinate normalizzate 0..1). Serve per:
- tenere i disegni "agganciati al campo" mentre la telecamera si muove;
- disegnare la scia dei giocatori;
- portare la calibrazione del campo da un fotogramma agli altri.
Riconosce anche i cambi di inquadratura (tagli) e i fermi immagine.
"""
import cv2
import numpy as np
import cvsafe

WORK_W = 960
CUT = "cut"


def _to_norm_matrix(w, h):
    S = np.array([[1.0 / w, 0, 0], [0, 1.0 / h, 0], [0, 0, 1]])
    return S


class CameraMotion:
    def __init__(self):
        self.pairs = {}  # idx -> 3x3 (np.array) oppure CUT
        self._prev = None  # (idx, gray, hist)

    # ---------- persistenza ----------
    def to_dict(self):
        out = {}
        for k, v in list(self.pairs.items()):
            out[str(k)] = CUT if isinstance(v, str) else [round(float(x), 7) for x in v.flatten()[:8]]
        return out

    @classmethod
    def from_dict(cls, d):
        cm = cls()
        for k, v in (d or {}).items():
            if v == CUT:
                cm.pairs[int(k)] = CUT
            else:
                cm.pairs[int(k)] = np.array(list(v) + [1.0]).reshape(3, 3)
        return cm

    # ---------- calcolo ----------
    def missing(self, a, b):
        return [i for i in range(a + 1, b + 1) if i not in self.pairs]

    def ensure(self, reader, a, b, progress=None, cancel=None):
        """Calcola le coppie mancanti nell'intervallo [a, b] (indici fotogramma).

        Usa un fotogramma chiave: i punti vengono inseguiti dal fotogramma chiave a quello
        corrente e l'omografia si calcola sempre rispetto al chiave, così l'errore non si
        accumula fotogramma dopo fotogramma.
        """
        a = max(0, int(a))
        b = min(reader.frame_count - 1, int(b))
        miss = self.missing(a, b)
        if not miss:
            return
        start = miss[0] - 1
        n = b - start
        prev = self._prepare(reader.frame(start))
        key = self._new_key(prev)
        H_prev = np.eye(3)  # chiave -> fotogramma precedente (pixel di lavoro)
        for k, i in enumerate(range(start + 1, b + 1)):
            cur = self._prepare(reader.frame(i))
            if i in self.pairs:
                prev = cur
                key = self._new_key(cur)
                H_prev = np.eye(3)
                continue
            kind = self._classify(prev, cur)
            if kind == CUT:
                self.pairs[i] = CUT
                key = self._new_key(cur)
                H_prev = np.eye(3)
            elif kind == "freeze":
                self.pairs[i] = np.eye(3)
                key["pts"] = key["pts"]  # niente da aggiornare
            else:
                H_cur, key = self._track_key(key, prev, cur, H_prev)
                if H_cur is None:
                    # perso: stima solo tra i due fotogrammi
                    P = self._pair_direct(prev, cur)
                    Pn = self._norm(P, cur) if P is not None else None
                    if Pn is None or not self._consistent(prev, cur, P):
                        self.pairs[i] = CUT  # inquadrature che non combaciano: è un taglio
                    else:
                        self.pairs[i] = Pn
                    key = self._new_key(cur)
                    H_prev = np.eye(3)
                else:
                    P = H_cur @ np.linalg.inv(H_prev)
                    Pn = self._norm(P, cur)
                    if Pn is None or not self._consistent(prev, cur, P):
                        self.pairs[i] = CUT
                        key = self._new_key(cur)
                        H_prev = np.eye(3)
                    else:
                        self.pairs[i] = Pn
                        H_prev = H_cur
                    if key["alive"] < 0.45 * key["n0"] or key["age"] > 250:
                        key = self._new_key(cur)
                        H_prev = np.eye(3)
            prev = cur
            if progress and k % 5 == 0:
                progress(k / max(1, n))
            if cancel and cancel():
                return

    def _norm(self, P, cur):
        H, W = cur[0].shape
        N = _to_norm_matrix(W, H)
        Mn = N @ P @ np.linalg.inv(N)
        Mn = Mn / Mn[2, 2]
        c = Mn @ np.array([0.5, 0.5, 1.0])
        c = c[:2] / c[2]
        if abs(c[0] - 0.5) > 0.25 or abs(c[1] - 0.5) > 0.25:
            return None  # salto impossibile tra due fotogrammi
        return Mn

    @staticmethod
    def _consistent(prev, cur, P):
        """Controlla che il fotogramma precedente, spostato con P, assomigli davvero al corrente."""
        g0, g1 = prev[0], cur[0]
        h, w = g0.shape
        s = 240 / w
        S = np.array([[s, 0, 0], [0, s, 0], [0, 0, 1]])
        a = cvsafe.resize(g0, (240, int(h * s)), interpolation=cv2.INTER_AREA)
        b = cvsafe.resize(g1, (240, int(h * s)), interpolation=cv2.INTER_AREA)
        Ps = S @ P @ np.linalg.inv(S)
        warped = cv2.warpPerspective(a, Ps, (b.shape[1], b.shape[0]), borderValue=-1)
        mask = cv2.warpPerspective(np.full_like(a, 255), Ps, (b.shape[1], b.shape[0])) > 0
        if mask.mean() < 0.3:
            return False
        err = float(np.mean(cv2.absdiff(warped, b)[mask]))
        base = float(np.mean(cv2.absdiff(a, b)))
        return err < 18 or err < 0.5 * base

    def _new_key(self, frame_data):
        g = frame_data[0]
        mask = np.full(g.shape, 255, np.uint8)
        pts = cv2.goodFeaturesToTrack(g, maxCorners=1200, qualityLevel=0.005, minDistance=7, blockSize=7, mask=mask)
        if pts is None:
            pts = np.zeros((0, 1, 2), np.float32)
        return {"orig": pts.reshape(-1, 2).copy(), "pts": pts.reshape(-1, 2).copy(), "n0": max(1, len(pts)),
                "alive": len(pts), "age": 0}

    def _track_key(self, key, prev, cur, H_prev):
        if len(key["pts"]) < 25:
            return None, key
        p_prev = key["pts"].reshape(-1, 1, 2).astype(np.float32)
        nxt, st, _ = cv2.calcOpticalFlowPyrLK(prev[0], cur[0], p_prev, None, winSize=(21, 21), maxLevel=3,
                                              criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
        # controllo avanti-indietro: scarta i punti inseguiti male
        back, st2, _ = cv2.calcOpticalFlowPyrLK(cur[0], prev[0], nxt, None, winSize=(21, 21), maxLevel=3)
        fb = np.linalg.norm(back.reshape(-1, 2) - key["pts"], axis=1)
        ok = (st.flatten() == 1) & (st2.flatten() == 1) & (fb < 1.0)
        orig = key["orig"][ok]
        newp = nxt.reshape(-1, 2)[ok]
        oldp = key["pts"][ok]
        if len(orig) < 25:
            return None, key
        # scarta i punti fermi (grafiche in sovrimpressione) se la telecamera si muove
        mv = np.linalg.norm(newp - oldp, axis=1)
        med = float(np.median(mv))
        if med > 0.8:
            moving = mv > 0.25 * med
            if moving.sum() >= 25:
                orig, newp, oldp = orig[moving], newp[moving], oldp[moving]
        H, inl = cv2.findHomography(orig, newp, cv2.RANSAC, 2.0)
        if H is None or inl is None or inl.sum() < 20:
            return None, key
        inl = inl.flatten() == 1
        key = dict(key, orig=orig[inl], pts=newp[inl], alive=int(inl.sum()), age=key["age"] + 1)
        return H, key

    def _pair_direct(self, prev, cur):
        g0, g1 = prev[0], cur[0]
        pts = cv2.goodFeaturesToTrack(g0, maxCorners=800, qualityLevel=0.01, minDistance=8, blockSize=7)
        if pts is None or len(pts) < 20:
            return np.eye(3)
        nxt, st, _ = cv2.calcOpticalFlowPyrLK(g0, g1, pts, None, winSize=(21, 21), maxLevel=3)
        st = st.flatten() == 1
        p0, p1 = pts[st].reshape(-1, 2), nxt[st].reshape(-1, 2)
        if len(p0) < 20:
            return None
        mv = np.linalg.norm(p1 - p0, axis=1)
        med = float(np.median(mv))
        if med > 1.0:
            keep = mv > 0.25 * med
            if keep.sum() >= 20:
                p0, p1 = p0[keep], p1[keep]
        M, inl = cv2.findHomography(p0, p1, cv2.RANSAC, 1.5)
        if M is None or inl is None or inl.sum() < max(15, 0.3 * len(p0)):
            return None
        return M

    def _classify(self, prev, cur):
        g0, h0 = prev
        g1, h1 = cur
        diff = float(np.mean(cv2.absdiff(g0, g1)))
        corr = cv2.compareHist(h0, h1, cv2.HISTCMP_CORREL)
        if diff > 30 or corr < 0.6:
            return CUT
        if diff < 0.4:
            return "freeze"
        return "move"

    def _prepare(self, frame):
        h, w = frame.shape[:2]
        s = WORK_W / w
        small = cvsafe.resize(frame, (WORK_W, int(round(h * s))), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        hsv = cv2.cvtColor(cvsafe.resize(small, (160, 90)), cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [30, 32], [0, 180, 0, 256])
        cv2.normalize(hist, hist)
        return gray, hist

    # ---------- uso ----------
    def is_cut_between(self, a, b):
        lo, hi = (a, b) if a <= b else (b, a)
        return any(isinstance(self.pairs.get(i), str) for i in range(lo + 1, hi + 1))

    def next_cut(self, a, limit):
        for i in range(a + 1, limit + 1):
            if isinstance(self.pairs.get(i), str):
                return i
        return None

    def transform(self, a, b):
        """Matrice che porta coordinate del fotogramma a in quelle del fotogramma b.

        Ritorna None se tra a e b c'è un taglio. Coppie mancanti = nessun movimento.
        """
        if a == b:
            return np.eye(3)
        M = np.eye(3)
        if b > a:
            for i in range(a + 1, b + 1):
                P = self.pairs.get(i)
                if isinstance(P, str):
                    return None
                if P is not None:
                    M = P @ M
        else:
            for i in range(a, b, -1):
                P = self.pairs.get(i)
                if isinstance(P, str):
                    return None
                if P is not None:
                    M = np.linalg.inv(P) @ M
        return M

    def cumulative(self, a, b):
        """Lista di matrici C[k] che portano il fotogramma a nel fotogramma a+k, per k=0..b-a.
        Dopo un taglio le matrici valgono None."""
        out = [np.eye(3)]
        M = np.eye(3)
        broken = False
        for i in range(a + 1, b + 1):
            P = self.pairs.get(i)
            if broken or isinstance(P, str):
                broken = True
                out.append(None)
                continue
            if P is not None:
                M = P @ M
            out.append(M.copy())
        return out


def apply(M, pts):
    """Applica una matrice 3x3 a una lista di punti normalizzati [[x, y], ...]."""
    if M is None:
        return None
    if not len(pts):
        return []
    P = np.hstack([np.asarray(pts, float), np.ones((len(pts), 1))])
    Q = (M @ P.T).T
    Q = Q[:, :2] / Q[:, 2:3]
    return Q.tolist()
