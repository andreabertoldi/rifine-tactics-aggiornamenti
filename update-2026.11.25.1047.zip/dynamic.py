"""Disegni dinamici: posizioni dei giocatori inseguiti, aggancio al campo, calibrazione e misure.

Un disegno può avere `anchors`, uno per punto:
  {"type": "track", "id": <id traccia>}       -> il punto segue i piedi del giocatore
  {"type": "field", "f": <fotogramma>, "p": [x, y]} -> punto fisso sul campo (segue la telecamera)
Senza `anchors` il disegno resta fermo sullo schermo (come prima).
"""
import math
import time

import cv2
import numpy as np

from camera import CameraMotion, apply
import cvsafe

# Misure tipiche. L x W = lunghezza x larghezza (nelle giovanili variano: l'app le può calcolare dai
# punti cliccati). Misure interne (FIGC dove previste): pd/pw = area di rigore profondità/larghezza,
# gd/gw = area piccola, r = raggio cerchio, ps = dischetto, gp = larghezza porta.
# Le "range" sono i limiti ammessi per lunghezza e larghezza.
PITCH_PRESETS = {
    "11 contro 11 (105×68)": {"L": 105, "W": 68, "pd": 16.5, "pw": 40.32, "gd": 5.5, "gw": 18.32, "r": 9.15,
                              "ps": 11, "gp": 7.32, "range": [90, 120, 45, 90]},
    "9 contro 9 (60-75 × 40-50)": {"L": 65, "W": 45, "pd": 13, "pw": 30, "gd": 5, "gw": 14, "r": 6, "ps": 9,
                                  "gp": 6, "range": [55, 80, 35, 55]},
    "8 contro 8 (55-70 × 35-50)": {"L": 60, "W": 40, "pd": 12, "pw": 26, "gd": 4.5, "gw": 12, "r": 6, "ps": 9,
                                  "gp": 6, "range": [50, 75, 30, 55]},
    "7 contro 7 (50-65 × 35-45)": {"L": 55, "W": 40, "pd": 9, "pw": 20, "gd": 4, "gw": 10, "r": 5, "ps": 7,
                                  "gp": 5, "range": [45, 70, 30, 50]},
    "5 contro 5 (25-40 × 12-25)": {"L": 32, "W": 18, "pd": 6, "pw": 12, "gd": 3, "gw": 7, "r": 3, "ps": 6,
                                  "gp": 4.5, "range": [20, 45, 10, 30]},
}
DEFAULT_PITCH = dict(PITCH_PRESETS["11 contro 11 (105×68)"])


def pitch_landmarks(sp):
    """Punti notevoli del campo in metri (origine angolo in alto a sinistra)."""
    L, W, r = sp["L"], sp["W"], sp["r"]
    cy = W / 2
    pts = {
        "Angolo alto sx": (0, 0), "Angolo alto dx": (L, 0), "Angolo basso sx": (0, W), "Angolo basso dx": (L, W),
        "Metà campo alto": (L / 2, 0), "Metà campo basso": (L / 2, W), "Centro": (L / 2, cy),
        "Cerchio alto": (L / 2, cy - r), "Cerchio basso": (L / 2, cy + r),
        "Cerchio sx": (L / 2 - r, cy), "Cerchio dx": (L / 2 + r, cy),
        "Rigore sx": (sp["ps"], cy), "Rigore dx": (L - sp["ps"], cy),
    }
    for side, x0, sg in (("sx", 0, 1), ("dx", L, -1)):
        gp = sp.get("gp", 0)
        if gp:
            pts[f"Palo {side} alto"] = (x0, cy - gp / 2)
            pts[f"Palo {side} basso"] = (x0, cy + gp / 2)
        # lunetta (arco fuori dall'area): dove tocca la linea dell'area
        if sp["pd"] >= 16 and r > sp["pd"] - sp["ps"]:  # lunetta: solo campo a 11
            hw = math.sqrt(r * r - (sp["pd"] - sp["ps"]) ** 2)
            pts[f"Lunetta {side} alto"] = (x0 + sg * sp["pd"], cy - hw)
            pts[f"Lunetta {side} basso"] = (x0 + sg * sp["pd"], cy + hw)
        for nm, d, w in (("Area", sp["pd"], sp["pw"]), ("Area piccola", sp["gd"], sp["gw"])):
            pts[f"{nm} {side} fondo alto"] = (x0, cy - w / 2)
            pts[f"{nm} {side} fondo basso"] = (x0, cy + w / 2)
            pts[f"{nm} {side} spigolo alto"] = (x0 + sg * d, cy - w / 2)
            pts[f"{nm} {side} spigolo basso"] = (x0 + sg * d, cy + w / 2)
    return pts


def pitch_lines(sp, n_arc=48):
    """Linee del campo (in metri) per l'anteprima della calibrazione."""
    L, W, r = sp["L"], sp["W"], sp["r"]
    cy = W / 2
    lines = [[(0, 0), (L, 0), (L, W), (0, W), (0, 0)], [(L / 2, 0), (L / 2, W)]]
    lines.append([(L / 2 + r * math.cos(a), cy + r * math.sin(a)) for a in np.linspace(0, 2 * math.pi, n_arc)])
    for x0, sg in ((0, 1), (L, -1)):
        if sp["pd"] >= 16 and r > sp["pd"] - sp["ps"]:  # lunetta: solo campo a 11
            a0 = math.acos((sp["pd"] - sp["ps"]) / r)
            lines.append([(x0 + sg * (sp["ps"] + r * math.cos(a)), cy + r * math.sin(a))
                          for a in np.linspace(-a0, a0, 16)])
        for d, w in ((sp["pd"], sp["pw"]), (sp["gd"], sp["gw"])):
            lines.append([(x0, cy - w / 2), (x0 + sg * d, cy - w / 2), (x0 + sg * d, cy + w / 2), (x0, cy + w / 2)])
    return lines


def _front_sign(H, Hinv):
    """Sceglie il segno di Hinv in modo che i punti davanti alla telecamera abbiano w > 0."""
    c = H @ np.array([0.5, 0.6, 1.0])
    c = c / c[2]  # punto del campo (X, Y, 1) che si vede nell'immagine
    w = (Hinv @ c)[2]
    return Hinv if w > 0 else -Hinv


def ref_point(ref, sp):
    """Coordinate in metri di un riferimento: punto notevole (per nome) o punto libero (in proporzione)."""
    if ref[0] == "name":
        return pitch_landmarks(sp).get(ref[1])
    return (ref[1] * sp["L"], ref[2] * sp["W"])


def _img_error(H, img_pts, pitch_pts):
    """Errore medio nell'immagine (unità normalizzate) riproiettando i punti del campo."""
    try:
        Hinv = np.linalg.inv(H)
    except np.linalg.LinAlgError:
        return 1e9
    q = np.asarray(apply(Hinv, pitch_pts))
    return float(np.mean(np.linalg.norm(q - np.asarray(img_pts), axis=1)))


def general_position(pitch_pts, min_area=4.0):
    """True se esistono 4 punti di cui nessun gruppo di 3 è (quasi) sulla stessa linea."""
    from itertools import combinations
    P = [np.asarray(p, float) for p in pitch_pts]

    def area(a, b, c):
        return abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) / 2

    for quad in combinations(range(len(P)), 4):
        if all(area(P[i], P[j], P[k]) > min_area for i, j, k in combinations(quad, 3)):
            return True
    return False


def loo_error(img_pts, pitch_pts):
    """Errore 'onesto' in metri: ogni punto previsto da una calibrazione fatta SENZA di lui."""
    n = len(img_pts)
    if n < 5:
        return None
    errs = []
    for i in range(n):
        src = np.asarray([p for j, p in enumerate(img_pts) if j != i], float)
        dst = np.asarray([p for j, p in enumerate(pitch_pts) if j != i], float)
        if not general_position(dst):
            continue
        H, _ = cv2.findHomography(src, dst, 0)
        if H is None:
            continue
        q = apply(H, [img_pts[i]])[0]
        errs.append(float(np.hypot(q[0] - pitch_pts[i][0], q[1] - pitch_pts[i][1])))
    return float(np.median(errs)) if errs else None


def solve_calibration(img_pts, refs, sp, auto_size=True):
    """Calcola la calibrazione. Con auto_size cerca anche lunghezza e larghezza del campo che fanno
    combaciare meglio i punti (le misure interne restano quelle fisse). Ritorna (H, err_m, L, W, size_known)."""
    if len(img_pts) < 4:
        return None, None, sp["L"], sp["W"], (False, False)

    def fit(L, W):
        s2 = dict(sp, L=L, W=W)
        pp = [ref_point(r, s2) for r in refs]
        if any(p is None for p in pp):
            return None, 1e9, pp
        H, _ = cv2.findHomography(np.asarray(img_pts, float), np.asarray(pp, float), 0)
        if H is None:
            return None, 1e9, pp
        return H, _img_error(H, img_pts, pp), pp

    L0, W0 = sp["L"], sp["W"]
    best = (L0, W0)
    size_known = (False, False)
    if auto_size:
        rng = sp.get("range") or [L0 * 0.6, L0 * 1.5, W0 * 0.6, W0 * 1.5]
        lo_l, hi_l, lo_w, hi_w = rng[0] * 0.85, rng[1] * 1.15, rng[2] * 0.85, rng[3] * 1.15
        _, e0, _ = fit(L0, W0)
        cands = []
        for _round in range(4):
            Ls = np.linspace(lo_l, hi_l, 15)
            Ws = np.linspace(lo_w, hi_w, 15)
            cands = []
            for L in Ls:
                for W in Ws:
                    _, e, _ = fit(L, W)
                    cands.append((e, L, W))
            cands.sort()
            e, L, W = cands[0]
            dl, dw = (hi_l - lo_l) / 7, (hi_w - lo_w) / 7
            lo_l, hi_l, lo_w, hi_w = max(5, L - dl), L + dl, max(5, W - dw), W + dw
        e_best, Lb, Wb = cands[0]
        # le misure contano solo se i punti le "vincolano": se l'errore non cambia, tieni quelle note
        _, e_lw, _ = fit(Lb * 1.1, Wb)
        _, e_ww, _ = fit(Lb, Wb * 1.1)
        l_ok = e_lw > e_best * 1.05
        w_ok = e_ww > e_best * 1.05
        best = (float(Lb) if l_ok else L0, float(Wb) if w_ok else W0)
        size_known = (l_ok, w_ok)
    H, _, pp = fit(*best)
    if H is None:
        return None, None, best[0], best[1], (False, False)
    proj = apply(H, img_pts)
    err = float(np.mean(np.linalg.norm(np.asarray(proj) - np.asarray(pp), axis=1)))
    return H, err, best[0], best[1], size_known


def fit_homography(img_pts, pitch_pts):
    """Omografia immagine (normalizzata) -> campo (metri). Ritorna (H, errore medio in metri)."""
    src = np.asarray(img_pts, float)
    dst = np.asarray(pitch_pts, float)
    if len(src) < 4:
        return None, None
    method = cv2.RANSAC if len(src) > 4 else 0
    H, _ = cv2.findHomography(src, dst, method, 1.0)
    if H is None:
        return None, None
    proj = apply(H, src)
    err = float(np.mean(np.linalg.norm(np.asarray(proj) - dst, axis=1)))
    return H, err


class Scene:
    """Calcola, per un fotogramma, dove si trovano i punti di ogni disegno."""

    REACH = 250  # fotogrammi entro cui usare la catena del movimento camera da un riferimento

    def __init__(self, project, fps, video_path=None):
        self.project = project
        self.fps = fps
        self.cam = CameraMotion.from_dict(getattr(project, "camera", {}))
        self._cum_cache = {}
        self._H_cache = {}
        self.video_path = video_path
        self._reader = None
        self._feats = {}
        self._failed = set()
        if not hasattr(project, "pitch_refs") or project.pitch_refs is None:
            project.pitch_refs = {}

    # ---------- camera ----------
    def invalidate(self):
        self._cum_cache = {}
        self._H_cache = {}

    def transform(self, a, b):
        return self.cam.transform(int(a), int(b))

    def _cum(self, a, b):
        key = (a, b, len(self.cam.pairs))
        c = self._cum_cache.get(key)
        if c is None:
            mats = self.cam.cumulative(a, b)
            inv = [np.linalg.inv(m) if m is not None else None for m in mats]
            c = (mats, inv)
            if len(self._cum_cache) > 200:
                self._cum_cache = {}
            self._cum_cache[key] = c
        return c

    def map_from_to(self, p, a, b, base=None):
        """Porta il punto p (fotogramma a) nel fotogramma b usando una cache cumulativa da `base`."""
        if base is None:
            M = self.transform(a, b)
            return None if M is None else apply(M, [p])[0]
        lo = base
        hi = max(a, b)
        mats, inv = self._cum(lo, hi)
        ma, mb = mats[a - lo], mats[b - lo]
        if ma is None or mb is None:
            return None
        return apply(mb @ inv[a - lo], [p])[0]

    # ---------- tracce ----------
    def track(self, tid):
        return self.project.tracks.get(tid)

    def track_at(self, tid, idx):
        tr = self.track(tid)
        if not tr:
            return None
        return tr["data"].get(idx)

    # ---------- calibrazione ----------
    def calibration_for(self, idx):
        """Calibrazione più vicina (serve per le misure del campo)."""
        cs = self.project.calibrations
        return min(cs, key=lambda c: abs(c["idx"] - idx)) if cs else None

    def pitch_spec(self, idx=0):
        c = self.calibration_for(idx)
        return (c or {}).get("pitch") or self.project.pitch or DEFAULT_PITCH

    def _refs(self):
        """Fotogrammi di cui si conosce la posizione sul campo: calibrazioni + riconoscimenti automatici."""
        refs = {int(c["idx"]): np.array(c["H"]).reshape(3, 3) for c in self.project.calibrations}
        for k, v in self.project.pitch_refs.items():
            refs.setdefault(int(k), np.array(v).reshape(3, 3))
        return refs

    def chain_ok(self, a, b):
        lo, hi = (a, b) if a <= b else (b, a)
        for i in range(lo + 1, hi + 1):
            P = self.cam.pairs.get(i)
            if P is None or isinstance(P, str):
                return False
        return True

    def pitch_H(self, idx):
        """Matrice immagine (fotogramma idx, normalizzata) -> campo in metri, oppure None."""
        if not self.project.calibrations:
            return None
        if idx in self._H_cache:
            return self._H_cache[idx]
        st = self.__dict__.setdefault("stats", {})
        H = None
        refs = self._refs()
        near = sorted(refs, key=lambda f: abs(f - idx))
        for f in near:
            if abs(f - idx) > self.REACH:
                break
            if f == idx or self.chain_ok(f, idx):
                M = self.transform(idx, f)
                if M is not None:
                    H = refs[f] @ M
                    break
        if H is None and near and abs(near[0] - idx) <= self.REACH:
            # manca solo un pezzetto del movimento della telecamera (es. il video sta andando avanti):
            # lo calcola adesso, è veloce e tiene le linee attaccate al campo
            f = near[0]
            lo, hi = min(f, idx), max(f, idx)
            miss = self.cam.missing(lo, hi)
            if len(miss) <= 12 and self._frame(min(miss) - 1) is not None:
                try:
                    # solo il pezzo che manca (di solito 1 fotogramma: il lettore è già lì, niente salti)
                    self.cam.ensure(self._reader, min(miss) - 1, max(miss))
                    if self.chain_ok(f, idx):
                        M = self.transform(idx, f)
                        if M is not None:
                            H = refs[f] @ M
                except Exception:
                    H = None
        if H is None:
            t0 = time.perf_counter()
            H = self.register(idx)
            k = "campo ricalcolato da zero" if H is not None else "campo NON trovato"
            st[k] = st.get(k, 0) + 1
            st["tempo ricalcolo campo ms"] = st.get("tempo ricalcolo campo ms", 0) + int(1000 * (time.perf_counter() - t0))
        else:
            st["campo seguito col movimento camera"] = st.get("campo seguito col movimento camera", 0) + 1
        self._H_cache[idx] = H
        return H

    # ---------- riconoscimento automatico del campo in tutto il video ----------
    def _frame(self, idx):
        if not self.video_path:
            return None
        if self._reader is None:
            from video import VideoReader
            try:
                self._reader = VideoReader(self.video_path)
            except Exception:
                self.video_path = None
                return None
        return self._reader.frame(idx)

    def _features(self, idx):
        if idx in self._feats:
            return self._feats[idx]
        fr = self._frame(idx)
        if fr is None:
            return None
        h, w = fr.shape[:2]
        s = 960 / w
        g = cv2.cvtColor(cvsafe.resize(fr, (960, int(h * s)), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
        sift = cv2.SIFT_create(nfeatures=2500)
        kp, des = sift.detectAndCompute(g, None)
        pts = np.array([k.pt for k in kp], np.float32) / [960, g.shape[0]] if kp else np.zeros((0, 2), np.float32)
        out = (pts, des)
        if len(self._feats) > 40:
            self._feats.pop(next(iter(self._feats)))
        self._feats[idx] = out
        return out

    @staticmethod
    def _match(fa, fb):
        """Omografia (normalizzata) dal fotogramma a al b con le corrispondenze SIFT, oppure None.

        Le grafiche fisse della diretta (punteggio, loghi) restano ferme sullo schermo in tutti i
        fotogrammi e darebbero «nessun movimento» anche quando la telecamera ha girato: le corrispondenze
        che non si spostano vengono tenute solo se sono sparse su tutta l'immagine (telecamera davvero ferma)."""
        if fa is None or fb is None or fa[1] is None or fb[1] is None or len(fa[0]) < 30 or len(fb[0]) < 30:
            return None
        m = cv2.BFMatcher(cv2.NORM_L2).knnMatch(fa[1], fb[1], k=2)
        good = [x[0] for x in m if len(x) == 2 and x[0].distance < 0.75 * x[1].distance]
        if len(good) < 30:
            return None
        src = np.float32([fa[0][g.queryIdx] for g in good])
        dst = np.float32([fb[0][g.trainIdx] for g in good])
        still = np.linalg.norm(src - dst, axis=1) < 0.003
        if still.any():
            sp = src[still]
            spread = len(sp) >= 20 and np.ptp(sp[:, 0]) > 0.5 and np.ptp(sp[:, 1]) > 0.35
            if not spread:
                src, dst = src[~still], dst[~still]
        if len(src) < 30:
            return None
        M, inl = cv2.findHomography(src, dst, cv2.RANSAC, 0.004)
        if M is None or inl is None:
            return None
        n_in = int(inl.sum())
        if n_in < 30 or n_in < 0.2 * len(src):
            return None
        pin = src[inl.ravel() == 1]
        if np.ptp(pin[:, 0]) < 0.25 or np.ptp(pin[:, 1]) < 0.15:
            return None  # corrispondenze tutte in un angolino: non affidabile
        return M

    def register(self, idx):
        """Trova da solo il campo nel fotogramma idx confrontandolo con i fotogrammi calibrati.

        Funziona anche dopo un cambio di inquadratura se la telecamera è la stessa (stessa
        posizione nello stadio, cambia solo dove guarda e lo zoom)."""
        if any(abs(idx - f) < 12 for f in self._failed):
            return None
        a = self._features(idx)
        if a is None or a[1] is None or len(a[0]) < 30:
            self._failed.add(idx)
            return None
        refs = self._refs()
        # prima le calibrazioni, poi gli altri riferimenti più vicini
        order = sorted(refs, key=lambda f: (0 if any(int(c["idx"]) == f for c in self.project.calibrations) else 1,
                                            abs(f - idx)))[:6]
        for f in order:
            M = self._match(a, self._features(f))
            if M is None:
                continue
            H = refs[f] @ M
            self.project.pitch_refs[str(idx)] = [float(x) for x in H.flatten()]
            return H
        self._failed.add(idx)
        return None

    def match_frames(self, a, b):
        """Matrice che porta punti (normalizzati) del fotogramma a nel fotogramma b.

        Usa il movimento della telecamera se i due fotogrammi sono collegati, altrimenti confronta
        direttamente le due immagini (stessa telecamera, anche dopo un cambio di scena)."""
        if a == b:
            return np.eye(3)
        if self.chain_ok(a, b):
            M = self.transform(a, b)
            if M is not None:
                return M
        return self._match(self._features(a), self._features(b))

    def add_anchor(self, idx, H):
        """Posizione del campo ri-agganciata alle linee nel fotogramma idx: diventa un nuovo riferimento."""
        self.project.pitch_refs[str(int(idx))] = [float(v) for v in np.asarray(H).flatten()]
        self._H_cache = {}
        self._cum_cache = {k: v for k, v in self._cum_cache.items() if k[0] != "pt" and k[0] != "clean"}

    def pitch_overlay(self, idx):
        """Linee del campo calibrate proiettate nel fotogramma idx (normalizzate), per il controllo a vista."""
        if not self.project.calibrations:
            return []
        H = self.pitch_H(idx)
        if H is None:
            return None
        try:
            Hinv = np.linalg.inv(H)
        except np.linalg.LinAlgError:
            return None
        Hinv = _front_sign(H, Hinv)
        out = []
        for line in pitch_lines(self.pitch_spec(idx)):
            dense = []
            for (x0, y0), (x1, y1) in zip(line, line[1:]):
                for t in np.linspace(0, 1, 10):
                    dense.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
            P = np.hstack([np.asarray(dense), np.ones((len(dense), 1))]) @ Hinv.T
            seg = []
            for (X, Y, Wh) in P:
                if Wh > 1e-6:
                    q = (X / Wh, Y / Wh)
                    if -0.3 < q[0] < 1.3 and -0.3 < q[1] < 1.3:
                        seg.append(q)
                        continue
                if len(seg) > 1:
                    out.append(seg)
                seg = []
            if len(seg) > 1:
                out.append(seg)
        return out

    def to_pitch(self, p, idx):
        H = self.pitch_H(idx)
        if H is None:
            return None
        return apply(H, [p])[0]

    def pitch_track(self, tid):
        """Posizioni in metri del giocatore per ogni fotogramma della traccia (con cache)."""
        tr = self.track(tid)
        if not tr or not self.project.calibrations:
            return {}
        key = ("pt", tid, tr["to"], len(self.project.calibrations), len(self.cam.pairs),
               len(self.project.pitch_refs))
        hit = self._cum_cache.get(key)
        if hit is not None:
            return hit
        out = {}
        H = None
        since = 0
        prev = None
        for k in sorted(tr["data"]):
            P = self.cam.pairs.get(k)
            if H is not None and prev == k - 1 and P is not None and not isinstance(P, str) and since < self.REACH \
                    and str(k) not in self.project.pitch_refs:
                H = H @ np.linalg.inv(P)  # avanza di un fotogramma lungo la catena
                since += 1
            else:
                H = self.pitch_H(k)
                since = 0
            prev = k
            if H is not None:
                out[k] = apply(H, [tr["data"][k][:2]])[0]
        self._cum_cache[key] = out
        return out

    MAX_KMH = 30.0  # oltre: errore di misura (scambio, tremolio), non si mostra

    def clean_track(self, tid):
        """Posizioni in metri ripulite: mediana su ±0,3 s e niente salti impossibili (con cache)."""
        pt = self.pitch_track(tid)
        tr = self.track(tid)
        key = ("clean", tid, tr["to"] if tr else 0, len(pt), len(self.project.calibrations),
               len(self.project.pitch_refs))
        hit = self._cum_cache.get(key)
        if hit is not None:
            return hit
        ks = sorted(k for k in pt if tr and tr["data"].get(k, [0, 0, 0, 0])[3] >= 0.9)
        out = {}
        if ks:
            w = max(2, int(self.fps * 0.3))
            arr = np.array([pt[k] for k in ks])
            for j, k in enumerate(ks):
                lo, hi = max(0, j - w), min(len(ks), j + w + 1)
                out[k] = np.median(arr[lo:hi], axis=0)
            # togli i punti che implicherebbero velocità impossibili rispetto al precedente buono
            good, prev = {}, None
            for k in ks:
                if prev is not None:
                    dt = (k - prev) / self.fps
                    if math.dist(out[k], out[prev]) / max(dt, 1e-3) * 3.6 > self.MAX_KMH * 1.3:
                        continue
                good[k] = out[k]
                prev = k
            out = good
        self._cum_cache[key] = out
        return out

    def speed_kmh(self, tid, idx):
        pt = self.clean_track(tid)
        if not pt:
            return None
        k = max(3, int(self.fps * 0.5))  # finestra di 1 secondo centrata
        cand = [i for i in pt if abs(i - idx) <= k]
        if len(cand) < k:
            return None
        a, b = min(cand), max(cand)
        if b - a < k:
            return None
        v = math.dist(pt[a], pt[b]) / ((b - a) / self.fps) * 3.6
        return v if v <= self.MAX_KMH else None

    def distance_run(self, tid, idx, start):
        """Metri percorsi dal giocatore tra il fotogramma start e idx."""
        pt = self.clean_track(tid)
        ks = [k for k in sorted(pt) if start <= k <= idx]
        if len(ks) < 2:
            return None
        step = max(1, int(self.fps * 0.2))  # campiona ogni 0,2 s per non sommare il tremolio
        sample = ks[::step] + ([ks[-1]] if ks[-1] % step else [])
        return sum(math.dist(pt[a], pt[b]) for a, b in zip(sample, sample[1:]))

    def dist_to_goal(self, p, idx):
        q = self.to_pitch(p, idx)
        if q is None:
            return None
        sp = self.pitch_spec(idx)
        if sp.get("goals"):  # porte della partita indicate in calibrazione (es. 9c9 di traverso)
            return min(math.dist(q, g) for g in sp["goals"])
        gx = sp.get("goal_at", 0) or 0  # 9c9 nel campo da 11: porta sulla linea dell'area di rigore
        return min(math.dist(q, (gx, sp["W"] / 2)), math.dist(q, (sp["L"] - gx, sp["W"] / 2)))

    # ---------- risoluzione disegni ----------
    def resolve(self, d, idx):
        """Ritorna una copia del disegno con i punti nel fotogramma idx, o None se non visibile."""
        anchors = d.get("anchors")
        if not anchors:
            if d.get("kind") == "fantasma" and len(d.get("points") or []) >= 2:
                return self._ghost(dict(d), idx)
            if d.get("kind") == "testo" and d.get("ground") and d.get("points"):
                return self._ground_text(dict(d), d["points"][0], idx)
            if d.get("kind") == "spotlight" and d.get("points"):
                return self._still_spot(dict(d), idx)
            return d
        out = dict(d)
        pts = []
        heights = []
        tids = []
        for an, base in zip(anchors, d["points"]):
            if an is None:
                pts.append(base)
                heights.append(None)
                tids.append(None)
            elif an["type"] == "track":
                v = self.track_at(an["id"], idx)
                if v is None:
                    return None
                off = an.get("off")
                if off:
                    # punto agganciato al giocatore con uno scostamento (in altezze-giocatore)
                    pts.append([v[0] + off[0] * v[2] * an.get("ar", 0.5625), v[1] + off[1] * v[2]])
                    heights.append(None)
                else:
                    pts.append([v[0], v[1]])
                    heights.append(v[2])
                tids.append(an["id"])
            else:
                q = self.map_from_to(an["p"], an["f"], idx)
                if q is None:
                    return None
                pts.append(q)
                heights.append(None)
                tids.append(None)
        out["points"] = pts
        out["_h"] = heights
        kind = d["kind"]
        if kind == "spotlight" and tids and tids[0] and heights[0]:
            # anello vero sul prato (campo calibrato): cerchio di ~0,75 m di raggio, giusto in ogni prospettiva
            rp = self._ground_circle(idx, pts[0], 0.75 * float(d.get("size", 1.0)))
            if rp:
                out["_ring_poly"] = rp["pts"]
        if kind == "spotlight" and d.get("space") and tids and tids[0]:
            # anello = spazio libero: raggio fino all'avversario più vicino (mediana su mezzo secondo, senza scatti)
            tr = self.track(tids[0])
            if tr:
                data = tr["data"]
                if len(data.get(idx, ())) >= 10 or any(len(v) >= 10 for v in (data.get(idx - 1, ()), data.get(idx + 1, ()))):
                    # misura nuova (raggio già ripulito, per ogni fotogramma): media corta, solo per togliere il tremolio
                    n = max(1, int(self.fps * 0.1))
                    acc = ws = 0.0
                    for k in range(idx - n, idx + n + 1):
                        v = data.get(k)
                        if v is not None and len(v) >= 10:
                            w = 1.0 - abs(k - idx) / (n + 1.0)
                            acc += w * v[7]
                            ws += w
                    if ws:
                        out["_space"] = 1.0
                        out["_space_w"] = acc / ws
                        poly = self._space_circle(tr, idx, n, pts[0], smooth=True)
                        if poly:
                            out["_space_poly"] = poly
                else:
                    n = max(2, int(self.fps * 0.25))
                    vals = [data[k][4] for k in range(idx - n, idx + n + 1) if k in data and len(data[k]) > 4]
                    if vals:
                        near = sorted(v for v in vals if v >= 0)
                        out["_space"] = near[len(near) // 2] if len(near) * 2 >= len(vals) else 3.2
                        poly = self._space_circle(tr, idx, n, pts[0])
                        if poly:
                            out["_space_poly"] = poly
        labels = []
        kind = d["kind"]
        if kind == "palla" and tids and tids[0]:
            # traiettoria della palla: tutti i punti trovati, riportati nel fotogramma attuale (la telecamera si muove)
            tr = self.track(tids[0])
            if tr:
                first = tr["from"]
                last = tr["to"] if d.get("ball_whole") else min(idx, tr["to"])
                path = []
                for k in range(first, last + 1):
                    v = self.track_at(tids[0], k)
                    if v is None:
                        continue
                    q = self.map_from_to(v[:2], k, idx, base=first) if k != idx else v[:2]
                    path.append(list(q) if q is not None else list(v[:2]))
                if len(path) >= 3:
                    # leggera media su 3 punti: toglie il tremolio del rilevatore
                    sm = [path[0]] + [[(path[i - 1][0] + path[i][0] + path[i + 1][0]) / 3,
                                       (path[i - 1][1] + path[i][1] + path[i + 1][1]) / 3]
                                      for i in range(1, len(path) - 1)] + [path[-1]]
                    path = sm
                out["_ball"] = path
        if kind == "spotlight" and tids and tids[0]:
            tid = tids[0]
            if d.get("trail", 0) > 0:
                tr = self.track(tid)
                first = tr["from"]
                n = int(d["trail"] * self.fps)
                lo = max(first, idx - n)
                brk = [b for b in (self.track(tid) or {}).get("breaks", []) if b <= idx]
                if brk:
                    lo = max(lo, max(brk) + 1)
                trail = []
                for k in range(lo, idx + 1, 2 if n > 60 else 1):
                    v = self.track_at(tid, k)
                    if v is None:
                        continue
                    q = self.map_from_to(v[:2], k, idx, base=first)
                    if q is not None:
                        trail.append(q)
                trail.append(pts[0])
                if d.get("trail_smooth", True) and len(trail) >= 5:
                    # scia morbida: media sui punti vicini (toglie lo zig-zag del tremolio dei piedi);
                    # gli estremi restano dove sono, così la scia parte e arriva al punto giusto
                    sm = [trail[0]]
                    for i in range(1, len(trail) - 1):
                        r_ = min(4, i, len(trail) - 1 - i)
                        seg = trail[i - r_:i + r_ + 1]
                        sm.append([sum(q[0] for q in seg) / len(seg), sum(q[1] for q in seg) / len(seg)])
                    sm.append(trail[-1])
                    trail = sm
                out["_trail"] = trail
            parts = []
            if d.get("name"):
                parts.append(d["name"])
            vnow = self.track_at(tid, idx)
            seen = vnow is not None and vnow[3] >= 0.9
            # numeri solo quando il giocatore è davvero visto in questo fotogramma (non stimato)
            if not seen:
                pass
            elif d.get("speed"):
                v = self.speed_kmh(tid, idx)
                if v is not None:
                    parts.append(f"{v:.1f} km/h".replace(".", ","))
            if seen and d.get("run"):
                m = self.distance_run(tid, idx, self.track(tid)["from"])
                if m is not None:
                    parts.append(f"{m:.1f} m percorsi".replace(".", ","))
            if seen and d.get("goal"):
                g = self.dist_to_goal(pts[0], idx)
                if g is not None:
                    parts.append(f"porta {g:.1f} m".replace(".", ","))
            if seen and d.get("space") and d.get("space_m") and out.get("_space_poly"):
                sm = out["_space_poly"].get("m")
                if sm is not None:
                    parts.append("spazio oltre 10 m" if sm >= 9.95 else f"spazio {sm:.1f} m".replace(".", ","))
            if parts:
                h = heights[0] or 0.1
                cone_lit = d.get("cone_on", True) and float(d.get("cone", 3.0)) > 0
                pos = d.get("name_pos") or ("sotto" if cone_lit else "sopra")
                if pos == "sotto":
                    # sotto l'anello: non si mescola con il cono di luce
                    y = pts[0][1] + h * (0.16 * d.get("size", 1.0) + 0.04)
                    labels.append(([pts[0][0], y], "  ·  ".join(parts), True))
                else:
                    labels.append(([pts[0][0], pts[0][1] - h * 1.15], "  ·  ".join(parts)))
        elif kind in ("distanza", "collega") and len(pts) >= 2 and d.get("metrics", True):
            segs = list(zip(pts, pts[1:]))
            sidx = [(i, i + 1) for i in range(len(pts) - 1)]
            if kind == "collega" and len(pts) >= 3 and (d.get("closed") or d.get("fill")):
                segs.append((pts[-1], pts[0]))
                sidx.append((len(pts) - 1, 0))
            for (a, b), si in zip(segs, sidx):
                pa, pb = self.to_pitch(a, idx), self.to_pitch(b, idx)
                if pa is None or pb is None:
                    continue
                m = math.dist(pa, pb)
                labels.append(([(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], f"{m:.1f} m".replace(".", ","), False, si))
        if kind == "collega" and d.get("behind") and pts:
            try:
                self._behind(d, out, pts, idx, labels)
            except Exception:
                out["_behind"] = None
        if kind == "visuale" and len(pts) >= 2:
            try:
                self._fan(d, out, pts, idx)
            except Exception:
                out["_fan"] = None
        if kind == "collega" and d.get("gap_to") and pts:
            try:
                self._gap(d, out, pts, idx, labels)
            except Exception:
                out["_gap"] = None
        out["_labels"] = labels
        if kind == "testo" and d.get("ground") and pts:
            self._ground_text(out, pts[0], idx)
        return out

    def _fan(self, d, out, pts, idx):
        """Visuale del giocatore: ventaglio disteso sul prato, dal giocatore verso il punto (o il compagno) scelto.
        Angolo regolabile, lunghezza fino al punto. Con il campo calibrato è in prospettiva vera."""
        out["_fan"] = None
        ang = math.radians(max(10.0, min(170.0, float(d.get("vis_angle", 50)))))
        n = 28
        H = self.pitch_H(idx)
        if H is not None:
            Hinv = _front_sign(H, np.linalg.inv(H))
            P = np.array(apply(H, [list(pts[0]), list(pts[1])]), float)
            if np.all(np.isfinite(P)):
                c, t = P[0], P[1]
                R = float(d.get("vis_len") or 0) or float(np.hypot(*(t - c)))   # lunghezza scelta o fino al punto
                if 0.5 < R < 120:
                    th = math.atan2(t[1] - c[1], t[0] - c[0]) + math.radians(float(d.get("vis_rot") or 0))
                    ring = [c] + [c + R * np.array([math.cos(th + a), math.sin(th + a)])
                                  for a in np.linspace(-ang / 2, ang / 2, n)]
                    poly = []
                    for q in ring:
                        v = Hinv @ np.array([q[0], q[1], 1.0])
                        if v[2] <= 1e-9:
                            poly = None
                            break
                        poly.append([float(v[0] / v[2]), float(v[1] / v[2])])
                    if poly:
                        out["_fan"] = poly
                        return
        # senza calibrazione: ventaglio piatto sullo schermo
        c, t = np.array(pts[0], float), np.array(pts[1], float)
        R = float(np.hypot(*(t - c)))
        if R < 1e-4:
            return
        th = math.atan2(t[1] - c[1], t[0] - c[0]) + math.radians(float(d.get("vis_rot") or 0))
        out["_fan"] = [list(c)] + [[float(c[0] + R * math.cos(th + a)), float(c[1] + R * math.sin(th + a))]
                                   for a in np.linspace(-ang / 2, ang / 2, n)]

    @staticmethod
    def _moved_label(d, key, p):
        """Posizione di una scritta che l'utente ha trascinato: lo spostamento resta, la scritta segue il disegno."""
        off = (d.get("lab_off") or {}).get(key)
        if off and p:
            return [p[0] + off[0], p[1] + off[1]]
        return p

    def _anchor_points(self, d, idx):
        """Punti di un altro disegno nel fotogramma idx (senza il resto dei calcoli), o None."""
        pts = []
        for an, base in zip(d.get("anchors") or [], d.get("points") or []):
            if an is None:
                pts.append(base)
            elif an["type"] == "track":
                v = self.track_at(an["id"], idx)
                if v is None:
                    return None
                pts.append([v[0], v[1]])
            else:
                q = self.map_from_to(an["p"], an["f"], idx)
                if q is None:
                    return None
                pts.append(q)
        return pts or None

    @staticmethod
    def _on_pitch(P, L, W, m=4.0):
        """I giocatori stanno davvero sul campo? Se uno risulta fuori, è la calibrazione a essere sbagliata qui."""
        return bool(np.all(np.isfinite(P)) and (P[:, 0] >= -m).all() and (P[:, 0] <= L + m).all()
                    and (P[:, 1] >= -m).all() and (P[:, 1] <= W + m).all())

    def _gap(self, d, out, pts, idx, labels):
        """Distanza tra due reparti (questo collegamento e quello scelto): metri in profondità, cioè verso la porta,
        tra le posizioni medie dei due gruppi. Disegna un righello tra le due linee, all'altezza media dei giocatori."""
        out["_gap"] = None
        o = self.project.drawing(d["gap_to"])
        if o is None or o.get("id") == d.get("id"):
            return
        t = idx / float(self.fps or 25)
        if not (o["t"] - 0.05 <= t <= o["t"] + o["dur"] + 0.05):
            return
        q = self._anchor_points(o, idx)
        if not q:
            return
        H = self.pitch_H(idx)
        if H is None:
            labels.append((list(pts[0]), "⚠ distanza tra i reparti: serve 📐 Calibra campo"))
            return
        Hinv = _front_sign(H, np.linalg.inv(H))
        sp = self.pitch_spec(idx)
        L, W = float(sp["L"]), float(sp["W"])
        A = np.array(apply(H, [list(p) for p in pts]), float)
        B = np.array(apply(H, [list(p) for p in q]), float)
        if not (self._on_pitch(A, L, W) and self._on_pitch(B, L, W)):
            labels.append((list(pts[0]), "⚠ campo poco preciso qui: calibra vicino a questo momento"))
            return
        xa, xb = float(A[:, 0].mean()), float(B[:, 0].mean())
        ym = float(np.concatenate([A[:, 1], B[:, 1]]).mean())
        LBL = 4.5   # la scritta sta 4,5 m «sopra» la riga (verso la linea laterale lontana)
        off = (d.get("lab_off") or {}).get("gap")
        if off:
            # scritta spostata: la riga la segue, passando sotto di lei
            try:
                v0 = Hinv @ np.array([(xa + xb) / 2, ym - LBL, 1.0])
                if v0[2] > 1e-9:
                    lp = [float(v0[0] / v0[2]) + off[0], float(v0[1] / v0[2]) + off[1]]
                    py = float(np.array(apply(H, [lp]), float)[0][1]) + LBL
                    if math.isfinite(py):
                        ym = min(W + 2.0, max(-2.0, py))
            except Exception:
                pass

        def img(x, y):
            v = Hinv @ np.array([x, y, 1.0])
            if v[2] <= 1e-9:
                return None
            r = [float(v[0] / v[2]), float(v[1] / v[2])]
            return r if all(math.isfinite(c) and abs(c) < 50 for c in r) else None

        a, b = img(xa, ym), img(xb, ym)
        ticks = [[img(x, ym - 1.6), img(x, ym + 1.6)] for x in (xa, xb)]
        if not (a and b) or not all(p for tk in ticks for p in tk):
            return
        out["_gap"] = {"line": [a, b], "ticks": ticks, "zone": None}
        if d.get("gap_fill") and len(pts) + len(q) >= 3:
            # spazio tra i due reparti: un bordo lungo i giocatori di questo reparto, l'altro lungo quelli dell'altro
            # (ordinati da una linea laterale all'altra), così segue la forma vera delle due linee
            ia = sorted(range(len(pts)), key=lambda k: A[k, 1])
            ib = sorted(range(len(q)), key=lambda k: B[k, 1], reverse=True)
            out["_gap"]["zone"] = [list(pts[k]) for k in ia] + [list(q[k]) for k in ib]
        # la scritta sta sempre al centro della sua riga, poco sopra: trascinandola si sposta solo in su e in giù
        # (cioè da una linea laterale all'altra) e la riga la segue
        mid = img((xa + xb) / 2, ym - LBL)
        if mid:
            labels.append((mid, f"{abs(xa - xb):.1f} m".replace(".", ","), False, None, "gap"))

    def _behind(self, d, out, pts, idx, labels):
        """Spazio dietro l'ultimo uomo dei giocatori collegati: dal giocatore più vicino alla sua porta fino alla linea di
        fondo, su tutta la larghezza del campo. Calcolato in metri sul campo e riportato nell'immagine, quindi segue
        i giocatori e la telecamera. Se il campo in questo momento non è affidabile non disegna niente e lo dice."""
        out["_behind"] = None

        def warn(text):
            labels.append((list(pts[0]), "⚠ " + text))

        H = self.pitch_H(idx)
        if H is None:
            warn("spazio dietro: serve 📐 Calibra campo")
            return
        Hinv = _front_sign(H, np.linalg.inv(H))
        sp = self.pitch_spec(idx)
        L, W = float(sp["L"]), float(sp["W"])
        P = np.array(apply(H, [list(p) for p in pts]), float)
        m = 4.0
        if (not np.all(np.isfinite(P)) or (P[:, 0] < -m).any() or (P[:, 0] > L + m).any()
                or (P[:, 1] < -m).any() or (P[:, 1] > W + m).any()):
            # un giocatore «fuori dal campo»: è il campo a essere sbagliato in questo momento
            warn("campo poco preciso qui: calibra vicino a questo momento")
            return
        side = d.get("behind_side") or "auto"
        end = None
        if side in ("left", "right"):
            a, b = Hinv @ np.array([0.0, W / 2, 1.0]), Hinv @ np.array([L, W / 2, 1.0])
            if a[2] > 1e-9 and b[2] > 1e-9:
                left_end = 0.0 if a[0] / a[2] < b[0] / b[2] else L
                end = left_end if side == "left" else L - left_end
        if end is None:
            end = 0.0 if P[:, 0].mean() < L / 2 else L       # la porta più vicina ai giocatori collegati
        x_last = float(min(P[:, 0], key=lambda x: abs(x - end)))   # l'ultimo uomo: il più vicino alla porta
        # rettangolo sul campo, tagliato dove la telecamera «non vede» (dietro l'orizzonte)
        eps = 1e-6
        rect_ = [(x_last, 0.0), (end, 0.0), (end, W), (x_last, W)]
        wv = lambda q: float(Hinv[2] @ np.array([q[0], q[1], 1.0]))
        poly = []
        for i in range(4):
            p0, p1 = rect_[i], rect_[(i + 1) % 4]
            w0, w1 = wv(p0), wv(p1)
            if w0 > eps:
                poly.append(p0)
            if (w0 > eps) != (w1 > eps):
                t = (eps - w0) / (w1 - w0)
                poly.append((p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t))
        if len(poly) < 3:
            return

        def img(q):
            v = Hinv @ np.array([q[0], q[1], 1.0])
            return [float(v[0] / v[2]), float(v[1] / v[2])]

        ip = [img(q) for q in poly]
        if not all(math.isfinite(c) and abs(c) < 50 for q in ip for c in q):
            return
        edge = [img((x_last, 0.0)), img((x_last, W))] if wv((x_last, 0.0)) > eps and wv((x_last, W)) > eps else None
        out["_behind"] = {"poly": ip, "edge": edge}
        if d.get("behind_label", True):
            cx = sum(q[0] for q in poly) / len(poly)
            cy = sum(q[1] for q in poly) / len(poly)
            labels.append((self._moved_label(d, "behind", img((cx, cy))), f"{abs(end - x_last):.1f} m".replace(".", ","),
                           False, None, "behind"))

    def _space_circle(self, tr, idx, n, p, smooth=False):
        """Con il campo calibrato: cerchio vero sul terreno, di raggio = metri dall'avversario più vicino.
        Ritorna i punti del cerchio nell'immagine, oppure None. smooth = dati nuovi (già ripuliti): media
        morbida invece della mediana."""
        H = self.pitch_H(idx)
        if H is None:
            return None
        ds, seen = [], 0
        acc = ws = 0.0
        o = 8 if smooth else 5
        for k in range(idx - n, idx + n + 1):
            v = tr["data"].get(k)
            if v is None or len(v) < o + 2:
                continue
            seen += 1
            w = 1.0 - abs(k - idx) / (n + 1.0)
            if v[o] < 0:
                acc += w * 8.0   # nessuno vicino: cerchio largo
                ws += w
                continue
            Hk = self.pitch_H(k)
            if Hk is None:
                continue
            a, b = apply(Hk, [v[:2], v[o:o + 2]])
            m = float(np.hypot(a[0] - b[0], a[1] - b[1]))
            ds.append(m)
            acc += w * min(10.0, m)
            ws += w
        if not seen:
            return None
        if smooth:
            if not ws:
                return None
            r = acc / ws
        else:
            ds.sort()
            r = ds[len(ds) // 2] if len(ds) * 2 >= seen else 8.0   # nessuno vicino: cerchio largo
        r = min(10.0, max(0.6, r))
        try:
            Hinv = _front_sign(H, np.linalg.inv(H))
        except np.linalg.LinAlgError:
            return None
        P = apply(H, [p])[0]
        ang = np.linspace(0, 2 * np.pi, 48, endpoint=False)
        ring = np.stack([P[0] + r * np.cos(ang), P[1] + r * np.sin(ang), np.ones(48)], 0)
        q = Hinv @ ring
        if np.any(np.abs(q[2]) < 1e-9):
            return None
        out = (q[:2] / q[2]).T
        if not np.all(np.isfinite(out)) or np.abs(out).max() > 5:
            return None
        return {"pts": [[float(x), float(y)] for x, y in out], "m": round(r, 1)}

    def _ghost(self, out, idx):
        """Fantasma: dove doveva stare il giocatore. Anello vero sul prato (campo calibrato), altezza della sagoma
        secondo la prospettiva, metri tra dove sta e dove doveva stare."""
        a, g = out["points"][0], out["points"][1]
        h = float(out.get("h_fixed") or 0.16)
        size = float(out.get("size", 1.0))
        ra = self._ground_circle(idx, a, 0.75)
        rg = self._ground_circle(idx, g, 0.75 * size)
        hg = None
        if ra and rg:
            wa = max(p[0] for p in ra["pts"]) - min(p[0] for p in ra["pts"])
            wg = max(p[0] for p in rg["pts"]) - min(p[0] for p in rg["pts"])
            if wa > 1e-6:
                hg = h * wg / (wa * size)
            out["_ring_poly"] = rg["pts"]
        if hg is None:   # senza campo calibrato: l'altezza dei giocatori in quella scena cresce scendendo nell'immagine
            fit = out.get("hfit")
            if fit and (fit[0] * a[1] + fit[1]) > 0.01:
                hg = h * max(0.05, fit[0] * g[1] + fit[1]) / (fit[0] * a[1] + fit[1])
            else:
                hg = h * (g[1] + 0.3) / (a[1] + 0.3)
        out["_gh"] = min(max(hg, h * 0.2), h * 3.0) * float(out.get("fig_scale", 1.0))
        labels = []
        if out.get("name"):
            labels.append(([g[0], g[1] + out["_gh"] * 0.12], out["name"], True))
        if out.get("metrics", True):
            pa, pg = self.to_pitch(a, idx), self.to_pitch(g, idx)
            if pa is not None and pg is not None:
                m = math.dist(pa, pg)
                labels.append(([(a[0] + g[0]) / 2, (a[1] + g[1]) / 2], f"{m:.1f} m".replace(".", ",")))
        out["_labels"] = labels
        return out

    def _still_spot(self, out, idx):
        """Giocatore segnato in un fermo immagine (non seguito): anello vero sul prato se il campo è
        calibrato, nome, e cerchio dello spazio con il raggio scelto a mano."""
        p = out["points"][0]
        size = float(out.get("size", 1.0))
        rp = self._ground_circle(idx, p, 0.75 * size)
        if rp:
            out["_ring_poly"] = rp["pts"]
        r = float(out.get("space_r") or 0)
        if out.get("space") and r > 0:
            out["_space"] = r / 1.75   # in altezze-giocatore, per il disegno senza calibrazione
            sp = self._ground_circle(idx, p, r)
            if sp:
                out["_space_poly"] = sp
        if out.get("name"):
            h = out.get("h_fixed") or 0.1
            cone_lit = out.get("cone_on", True) and float(out.get("cone", 3.0)) > 0
            pos = out.get("name_pos") or ("sotto" if cone_lit else "sopra")
            if pos == "sotto":
                out["_labels"] = [([p[0], p[1] + h * (0.16 * size + 0.04)], out["name"], True)]
            else:
                out["_labels"] = [([p[0], p[1] - h * 1.15], out["name"])]
        return out

    def _ground_circle(self, idx, p, r):
        """Cerchio di raggio r metri sul prato centrato nel punto p (immagine), come punti nell'immagine."""
        H = self.pitch_H(idx)
        if H is None:
            return None
        try:
            Hinv = _front_sign(H, np.linalg.inv(H))
        except np.linalg.LinAlgError:
            return None
        P = apply(H, [p])[0]
        ang = np.linspace(0, 2 * np.pi, 40, endpoint=False)
        q = Hinv @ np.stack([P[0] + r * np.cos(ang), P[1] + r * np.sin(ang), np.ones(40)], 0)
        if np.any(np.abs(q[2]) < 1e-9):
            return None
        out = (q[:2] / q[2]).T
        if not np.all(np.isfinite(out)) or np.abs(out).max() > 5:
            return None
        return {"pts": [[float(x), float(y)] for x, y in out]}

    def _ground_text(self, out, p, idx):
        """Testo steso sul campo: matrice che porta le coordinate del testo (decimetri sul prato, centrate
        nel punto p) all'immagine. Il testo si legge da sinistra a destra e «sta in piedi» verso chi guarda."""
        H = self.pitch_H(idx)
        if H is None:
            return out
        try:
            Hinv = _front_sign(H, np.linalg.inv(H))
        except np.linalg.LinAlgError:
            return out
        P = apply(H, [p])[0]
        asp = getattr(self, "aspect", 16 / 9)

        def img(q):
            v = Hinv @ np.array([q[0], q[1], 1.0])
            return np.array([v[0] / v[2], v[1] / v[2]]) if abs(v[2]) > 1e-9 else None

        o = img(P)
        if o is None:
            return out
        best_u, best_v = None, None
        dirs = []
        for ax in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            q = img((P[0] + 0.5 * ax[0], P[1] + 0.5 * ax[1]))
            if q is None:
                continue
            dv = (q - o) * np.array([asp, 1.0])
            n = float(np.hypot(*dv)) or 1e-9
            dirs.append((ax, dv / n))
        if not dirs:
            return out
        best_u = max(dirs, key=lambda e: e[1][0])[0]  # direzione del campo che nell'immagine va più a destra
        perp = [e for e in dirs if e[0][0] * best_u[0] + e[0][1] * best_u[1] == 0]
        if perp:
            best_v = max(perp, key=lambda e: e[1][1])[0]  # e quella che scende verso chi guarda
        if best_v is None:
            return out
        s = 0.1  # decimetri -> metri
        A = np.array([[best_u[0] * s, best_v[0] * s, P[0]],
                      [best_u[1] * s, best_v[1] * s, P[1]],
                      [0.0, 0.0, 1.0]])
        M = Hinv @ A
        out["_ground"] = [float(x) for x in M.flatten()]
        return out

    def to_dict_camera(self):
        return self.cam.to_dict()
