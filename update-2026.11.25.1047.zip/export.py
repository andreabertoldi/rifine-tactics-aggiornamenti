"""Esportazioni: video MP4 (clip/playlist con disegni), foto JPG/PNG, Excel."""
import os
import re
import subprocess
import sys
import tempfile
import wave

import cv2
import numpy as np
from PySide6.QtCore import QRectF
from PySide6.QtGui import QImage, QPainter

from drawing import paint_caption, paint_drawings
from model import fmt_time
import cvsafe

PRESETS = {
    "hq": {"label": "Alta qualità (fino a 1080p)", "max_h": 1080, "crf": 20, "abr": "160k", "max_fps": 60},
    "wa": {"label": "WhatsApp / leggero (720p)", "max_h": 720, "crf": 28, "abr": "96k", "max_fps": 30},
}

AUDIO_RATE = 48000


class Cancelled(Exception):
    pass


LGPL_FFMPEG = os.path.join(os.path.expanduser("~/Library/Application Support"), "AnalisiVideoCalcio",
                           "ffmpeg-lgpl", "ffmpeg")


def ffmpeg_exe():
    """FFmpeg da usare.
    Nell'app: la versione LGPL costruita apposta (senza parti GPL, usa il codificatore video e audio di Apple).
    Avviato da Python: la stessa versione LGPL se è già stata costruita (da «Crea applicazione»), altrimenti
    quella che c'è (imageio-ffmpeg o Homebrew), solo per lo sviluppo."""
    if getattr(sys, "frozen", False):
        p = os.path.join(getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable))), "ffbin", "ffmpeg")
        if os.path.exists(p):
            return p
    if os.path.exists(LGPL_FFMPEG):
        return LGPL_FFMPEG
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        for p in ("/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg", "ffmpeg"):
            if p == "ffmpeg" or os.path.exists(p):
                return p
    return "ffmpeg"


_ENCODERS = {}


def _encoders():
    exe = ffmpeg_exe()
    if exe not in _ENCODERS:
        try:
            _ENCODERS[exe] = subprocess.run([exe, "-hide_banner", "-encoders"], capture_output=True, text=True,
                                            timeout=20).stdout
        except Exception:
            _ENCODERS[exe] = ""
    return _ENCODERS[exe]


def apple_encoder():
    return " h264_videotoolbox " in _encoders()


def video_args(crf, w=1920, h=1080, fps=25.0):
    """Opzioni per comprimere il video. Con il codificatore di Apple (VideoToolbox) la qualità si dà come
    velocità di dati: la ricavo dal «crf» di prima, dalla dimensione e dai fotogrammi al secondo."""
    if apple_encoder():
        mbps = 14.0 * 0.84 ** (float(crf) - 18)                  # crf 18 → 14, 20 → 10, 28 → 2,5 Mbit/s a 1080p25
        mbps *= max(0.15, (w * h) / (1920.0 * 1080.0)) * max(1.0, float(fps) / 25.0) ** 0.6
        mbps = max(1.5, mbps)
        return ["-c:v", "h264_videotoolbox", "-b:v", f"{mbps:.2f}M", "-maxrate", f"{mbps * 1.5:.2f}M",
                "-bufsize", f"{mbps * 2:.2f}M", "-allow_sw", "1", "-profile:v", "high", "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p", "-profile:v", "high"]


def audio_args(bitrate):
    """AAC: quello di Apple (AudioToolbox) se c'è, altrimenti quello di FFmpeg."""
    if " aac_at " in _encoders():
        return ["-c:a", "aac_at", "-b:a", bitrate]
    return ["-c:a", "aac", "-b:a", bitrate]


def has_audio(path):
    try:
        p = subprocess.run([ffmpeg_exe(), "-hide_banner", "-i", path], capture_output=True, text=True,
                           errors="replace", timeout=60)
        return bool(re.search(r"Stream #\S+.*Audio:", p.stderr))
    except Exception:
        return False


def safe_name(s):
    s = re.sub(r"[\\/:*?\"<>|]+", "-", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s[:80] or "clip"


def out_size(w, h, max_h):
    if h > max_h:
        w = w * max_h / h
        h = max_h
    w = int(round(w / 2) * 2)
    h = int(round(h / 2) * 2)
    return max(2, w), max(2, h)


def build_pieces(start, end, stills, use_pause):
    """Divide un segmento [start,end] in pezzi di video e fermi immagine."""
    pauses = sorted((float(s["t"]), float(s["dur"])) for s in (stills or [])
                    if use_pause and start - 1e-3 <= s["t"] < end and s["dur"] > 0)
    pieces = []
    cur = start
    for t, p in pauses:
        if t > cur:
            pieces.append(("src", cur, t))
        pieces.append(("hold", t, p))
        cur = max(cur, t)
    if end > cur:
        pieces.append(("src", cur, end))
    return pieces


def render_frame_image(frame_bgr, size, drawings, t, use_pause=True, caption=None, caption_color="#2ecc71",
                       force_full=None, resolver=None, idx=None):
    """Ritorna un array BGRA (h, w, 4) con disegni e didascalia sovrapposti."""
    w, h = size
    if frame_bgr.shape[1] != w or frame_bgr.shape[0] != h:
        interp = cv2.INTER_AREA if frame_bgr.shape[0] > h else cv2.INTER_LINEAR
        frame_bgr = cvsafe.resize(frame_bgr, (w, h), interpolation=interp)
    arr = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2BGRA)
    arr = np.ascontiguousarray(arr)
    if drawings or caption:
        img = QImage(arr.data, w, h, w * 4, QImage.Format_RGB32)
        p = QPainter(img)
        rect = QRectF(0, 0, w, h)
        if drawings:
            paint_drawings(p, rect, drawings, t, use_pause, force_full=force_full, resolver=resolver, idx=idx)
        if caption:
            paint_caption(p, rect, caption, caption_color)
        p.end()
    return arr


def _write_silence(path, seconds):
    n = int(round(seconds * AUDIO_RATE))
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(AUDIO_RATE)
        w.writeframes(b"\x00\x00\x00\x00" * n)


def _extract_audio(src, a, b, path):
    cmd = [ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{a:.3f}", "-i", src,
           "-t", f"{max(0.01, b - a):.3f}", "-vn", "-ac", "2", "-ar", str(AUDIO_RATE), "-c:a", "pcm_s16le", path]
    r = subprocess.run(cmd, capture_output=True)
    if r.returncode != 0 or not os.path.exists(path):
        _write_silence(path, b - a)


def _concat_wavs(paths, out):
    with wave.open(out, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(AUDIO_RATE)
        for p in paths:
            with wave.open(p, "rb") as r:
                w.writeframes(r.readframes(r.getnframes()))


def export_video(reader, segments, out_path, project, preset="hq", with_drawings=True, use_pause=True,
                 with_caption=True, with_audio=True, progress=None, cancel=None):
    """Esporta uno o più segmenti in un unico MP4.

    segments: lista di dict {"start","end","caption","color"}
    progress(frac, msg) e cancel() -> bool sono callback opzionali.
    """
    pr = PRESETS[preset]
    fps = reader.fps
    step = 2 if fps > pr["max_fps"] + 1 else 1
    out_fps = fps / step
    W, H = out_size(reader.width, reader.height, pr["max_h"])
    drawings_all = project.drawings if with_drawings else []
    from dynamic import Scene
    scene = Scene(project, fps, video_path=reader.path)

    plan = []  # (pieces, caption, color, drawings)
    total_frames = 0
    for seg in segments:
        dws = [d for d in drawings_all if d["t"] < seg["end"] and d["t"] + d["dur"] > seg["start"]]
        pieces = build_pieces(seg["start"], seg["end"], getattr(project, "stills", []), use_pause)
        for kind, a, b in pieces:
            if kind == "src":
                total_frames += len(range(reader.idx_for_time(a), reader.idx_for_time(b), step))
            else:
                total_frames += int(round(b * out_fps))
        plan.append((pieces, seg.get("caption") if with_caption else None, seg.get("color", "#2ecc71"), dws))

    audio_ok = with_audio and has_audio(reader.path)
    tmpdir = tempfile.mkdtemp(prefix="analisivideo_")
    wav_path = None
    try:
        if audio_ok:
            parts = []
            k = 0
            for pieces, _, _, _ in plan:
                for kind, a, b in pieces:
                    pth = os.path.join(tmpdir, f"a{k:04d}.wav")
                    k += 1
                    if kind == "src":
                        _extract_audio(reader.path, a, b, pth)
                    else:
                        _write_silence(pth, b)
                    parts.append(pth)
                    if cancel and cancel():
                        raise Cancelled()
            wav_path = os.path.join(tmpdir, "audio.wav")
            _concat_wavs(parts, wav_path)

        cmd = [ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y",
               "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", f"{out_fps:.6f}", "-i", "-"]
        if wav_path:
            cmd += ["-i", wav_path]
        cmd += ["-map", "0:v"]
        if wav_path:
            cmd += ["-map", "1:a"] + audio_args(pr["abr"])
        cmd += video_args(pr["crf"], W, H, out_fps) + ["-movflags", "+faststart", out_path]
        errlog = open(os.path.join(tmpdir, "ffmpeg.log"), "wb")
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=errlog)
        done = 0
        try:
            for pieces, caption, color, dws in plan:
                for kind, a, b in pieces:
                    if kind == "src":
                        for idx in range(reader.idx_for_time(a), reader.idx_for_time(b), step):
                            fr = reader.frame(idx)
                            if fr is None:
                                continue
                            t = idx / fps
                            arr = render_frame_image(fr, (W, H), dws, t, use_pause, caption, color,
                                                     resolver=scene.resolve, idx=idx)
                            proc.stdin.write(arr.tobytes())
                            done += 1
                            if progress and done % 5 == 0:
                                progress(done / max(1, total_frames), "Creazione video…")
                            if cancel and cancel():
                                raise Cancelled()
                    else:
                        t, dur = a, b
                        fr = reader.frame(reader.idx_for_time(t))
                        if fr is None:
                            continue
                        full = {d["id"] for d in dws if abs(d["t"] - t) < 0.002}
                        arr = render_frame_image(fr, (W, H), dws, t, use_pause, caption, color, force_full=full,
                                                 resolver=scene.resolve, idx=reader.idx_for_time(t))
                        data = arr.tobytes()
                        for _ in range(int(round(dur * out_fps))):
                            proc.stdin.write(data)
                            done += 1
                        if progress:
                            progress(done / max(1, total_frames), "Creazione video…")
            proc.stdin.close()
            rc = proc.wait()
        except Cancelled:
            try:
                proc.stdin.close()
            except Exception:
                pass
            proc.kill()
            proc.wait()
            if os.path.exists(out_path):
                os.remove(out_path)
            raise
        except BrokenPipeError:
            rc = proc.wait()
        errlog.close()
        if rc != 0:
            with open(os.path.join(tmpdir, "ffmpeg.log"), "rb") as f:
                msg = f.read().decode("utf-8", "replace")[-1500:]
            raise RuntimeError("ffmpeg ha restituito un errore:\n" + msg)
        if progress:
            progress(1.0, "Fatto")
        return out_path
    finally:
        for fn in os.listdir(tmpdir):
            try:
                os.remove(os.path.join(tmpdir, fn))
            except Exception:
                pass
        try:
            os.rmdir(tmpdir)
        except Exception:
            pass


def segment_for_event(project, ev):
    return {"start": ev["start"], "end": ev["end"], "caption": project.event_caption(ev),
            "color": project.color_for(ev["type"])}


def export_photo(reader, project, t, out_path, with_drawings=True, caption=None, caption_color="#2ecc71"):
    fr = reader.frame(reader.idx_for_time(t))
    if fr is None:
        raise RuntimeError("Fotogramma non leggibile")
    dws = project.drawings if with_drawings else []
    # in foto i disegni con pausa si mostrano pieni
    full = {d["id"] for d in dws}
    from dynamic import Scene
    scene = Scene(project, reader.fps, video_path=reader.path)
    if hasattr(project, "_scene_cam"):
        scene.cam = project._scene_cam
    arr = render_frame_image(fr, (reader.width, reader.height), dws, t, True, caption, caption_color, force_full=full,
                             resolver=scene.resolve, idx=reader.idx_for_time(t))
    bgr = cv2.cvtColor(arr, cv2.COLOR_BGRA2BGR)
    ext = os.path.splitext(out_path)[1].lower()
    if ext == ".png":
        ok, buf = cv2.imencode(".png", bgr)
    else:
        ok, buf = cv2.imencode(".jpg", bgr, [cv2.IMWRITE_JPEG_QUALITY, 92])
    if not ok:
        raise RuntimeError("Impossibile creare l'immagine")
    with open(out_path, "wb") as f:  # supporta percorsi con accenti
        f.write(buf.tobytes())
    return out_path


def export_excel(project, events, out_path):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Eventi"
    head = ["Minuto", "Tempo (s)", "Evento", "Squadra", "Giocatore", "Nota", "Pos. X (0-100)", "Pos. Y (0-100)"]
    ws.append(head)
    for e in events:
        pos = e.get("pos") or [None, None]
        ws.append([fmt_time(e["t"]), round(e["t"], 1), e["type"], project.teams.get(e["team"], e["team"]),
                   project.player_label(e.get("player")), e.get("note", ""),
                   None if pos[0] is None else round(pos[0] * 100, 1),
                   None if pos[1] is None else round(pos[1] * 100, 1)])
    _style_sheet(ws, Font, PatternFill, Alignment, get_column_letter)

    ws2 = wb.create_sheet("Statistiche")
    sub = type(project)()
    sub.teams, sub.roster, sub.event_types, sub.events = project.teams, project.roster, project.event_types, events
    rows, cols, counts = sub.stats_matrix()
    ws2.append(["Giocatore / Squadra"] + cols + ["Totale"])
    for r in rows:
        vals = [counts[(r, c)] for c in cols]
        if r[1] != "TOT" and sum(vals) == 0:
            continue
        ws2.append([sub.row_label(r)] + vals + [sum(vals)])
        if r[1] == "TOT":
            for cell in ws2[ws2.max_row]:
                cell.font = Font(bold=True)
                cell.fill = PatternFill("solid", fgColor="EEF2F7")
    _style_sheet(ws2, Font, PatternFill, Alignment, get_column_letter)
    wb.save(out_path)
    return out_path


def _style_sheet(ws, Font, PatternFill, Alignment, get_column_letter):
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F3A5F")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    for i, col in enumerate(ws.columns, start=1):
        width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
        ws.column_dimensions[get_column_letter(i)].width = min(45, max(10, width + 2))


# ---------- condivisione (macOS) ----------

def reveal_in_finder(path):
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path])
        elif sys.platform.startswith("win"):
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
        else:
            subprocess.Popen(["xdg-open", os.path.dirname(path)])
    except Exception:
        pass


def share_files(widget, paths):
    """Apre il menu Condividi di macOS (AirDrop, Messaggi, Mail, WhatsApp…). Ritorna True se riuscito."""
    if sys.platform != "darwin":
        return False
    try:
        import ctypes

        import objc
        from AppKit import NSSharingServicePicker
        from Foundation import NSURL
        view = objc.objc_object(c_void_p=ctypes.c_void_p(int(widget.winId())))
        urls = [NSURL.fileURLWithPath_(p) for p in paths]
        picker = NSSharingServicePicker.alloc().initWithItems_(urls)
        widget._share_picker = picker  # mantiene il riferimento
        picker.showRelativeToRect_ofView_preferredEdge_(view.bounds(), view, 1)
        return True
    except Exception:
        return False
