"""cv2.resize "sicuro".

Su Mac con chip Apple, alcune versioni di OpenCV usano una libreria interna (KleidiCV) che a volte
legge un pezzetto oltre la fine dell'immagine: se l'immagine finisce proprio al bordo della memoria
il programma si chiude di colpo (segmentation fault). Qui l'immagine viene messa in un buffer con
qualche riga in più, così quella lettura cade su memoria valida."""
import cv2
import numpy as np


def resize(img, dsize, fx=0, fy=0, interpolation=cv2.INTER_LINEAR):
    h = img.shape[0]
    buf = np.empty((h + 4,) + img.shape[1:], img.dtype)
    buf[:h] = img
    return cv2.resize(buf[:h], dsize, fx=fx, fy=fy, interpolation=interpolation)
