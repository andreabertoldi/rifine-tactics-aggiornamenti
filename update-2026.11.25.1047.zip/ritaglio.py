"""Ritaglio di un giocatore dal fotogramma: serve al «fantasma» (copia semitrasparente del giocatore vero).

Si usa SAM 2 (se c'è) con il riquadro del giocatore; se non c'è o non riesce, GrabCut di OpenCV.
Il risultato è una piccola immagine PNG con trasparenza, salvata dentro il disegno.
"""
import base64

import cv2
import numpy as np


def _grabcut(crop, box):
    h, w = crop.shape[:2]
    mask = np.full((h, w), cv2.GC_BGD, np.uint8)
    x, y, bw, bh = [int(v) for v in box]
    mask[max(0, y):y + bh, max(0, x):x + bw] = cv2.GC_PR_BGD
    # il centro del riquadro è quasi sicuramente il giocatore
    cx0, cx1 = x + int(bw * 0.3), x + int(bw * 0.7)
    cy0, cy1 = y + int(bh * 0.2), y + int(bh * 0.75)
    mask[cy0:cy1, cx0:cx1] = cv2.GC_FGD
    mask[y + int(bh * 0.05):y + int(bh * 0.95), x + int(bw * 0.15):x + int(bw * 0.85)][
        mask[y + int(bh * 0.05):y + int(bh * 0.95), x + int(bw * 0.15):x + int(bw * 0.85)] == cv2.GC_PR_BGD] = cv2.GC_PR_FGD
    bgd, fgd = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
    cv2.grabCut(crop, mask, None, bgd, fgd, 5, cv2.GC_INIT_WITH_MASK)
    return ((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD)).astype(np.uint8)


LAST_ERR = ""


def _sam(crop, box):
    global LAST_ERR
    import samfollow
    LAST_ERR = ""
    if not samfollow.available():
        LAST_ERR = "SAM 2 non disponibile"
        return None
    try:
        rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
        m = samfollow.segment_box(rgb, [box[0], box[1], box[0] + box[2], box[1] + box[3]])
        return None if m is None else m.astype(np.uint8)
    except Exception as e:  # noqa
        import traceback
        LAST_ERR = (f"{type(e).__name__}: {e} @ " + traceback.format_exc().strip().splitlines()[-3].strip())[:400]
        return None


def make(frame, box):
    """frame: immagine BGR; box: (x, y, larghezza, altezza) del giocatore in pixel.
    Ritorna {"png": base64, "foot": [x, y], "h": altezza in pixel, "method": "SAM 2"/"GrabCut"} oppure None."""
    H, W = frame.shape[:2]
    x, y, bw, bh = [float(v) for v in box]
    mx, my = 0.30 * bw, 0.12 * bh
    x0, y0 = int(max(0, x - mx)), int(max(0, y - my))
    x1, y1 = int(min(W, x + bw + mx)), int(min(H, y + bh + my))
    crop = np.ascontiguousarray(frame[y0:y1, x0:x1])
    rb = (x - x0, y - y0, bw, bh)
    method, m = "SAM 2", _sam(crop, rb)
    if m is None or m.sum() < 0.04 * bw * bh:
        method, m = "GrabCut", _grabcut(crop, rb)
    if m is None or m.sum() < 0.04 * bw * bh:
        return None
    # una sola sagoma (quella che tocca il centro del riquadro), bordi lisci
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, stats, _c = cv2.connectedComponentsWithStats(m, connectivity=8)
    if n > 1:
        cy, cx = int(rb[1] + rb[3] / 2), int(rb[0] + rb[2] / 2)
        k = lab[min(max(cy, 0), lab.shape[0] - 1), min(max(cx, 0), lab.shape[1] - 1)]
        if k == 0:
            k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        m = (lab == k).astype(np.uint8)
    ys, xs = np.nonzero(m)
    if len(xs) < 30:
        return None
    a, b, c, d = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    alpha = cv2.GaussianBlur(m[b:d, a:c].astype(np.float32), (3, 3), 0)
    bgr = crop[b:d, a:c]
    rgba = np.dstack([bgr, (alpha * 255).astype(np.uint8)])
    ok, buf = cv2.imencode(".png", rgba)
    if not ok:
        return None
    return {"png": base64.b64encode(buf.tobytes()).decode(), "foot": [float((c - a) / 2.0), float(d - b)],
            "h": float(d - b), "bh": bh, "method": method, "sam_err": LAST_ERR, "crop": [int(x0), int(y0), int(x1), int(y1)]}


_cache = {}


def tinted(cut, color_rgb, key, opacity=0.8):
    """Immagine BGRA del fantasma: il giocatore con i suoi colori (appena velati), bordo netto e alone del colore scelto."""
    k = (key, color_rgb, round(opacity, 2))
    if k in _cache:
        return _cache[k]
    raw = np.frombuffer(base64.b64decode(cut["png"]), np.uint8)
    im = cv2.imdecode(raw, cv2.IMREAD_UNCHANGED)
    if im is None or im.shape[2] != 4:
        return None
    h = im.shape[0]
    t = max(2, int(round(h * 0.022)))          # spessore del bordo: proporzionale alla grandezza del giocatore
    pad = 3 * t + 2
    im = cv2.copyMakeBorder(im, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=(0, 0, 0, 0))
    a = im[:, :, 3].astype(np.float32) / 255.0
    col = np.array(color_rgb[::-1], np.float32)
    body = im[:, :, :3].astype(np.float32) * 0.80 + col * 0.20
    solid = (a > 0.5).astype(np.uint8)
    edge = cv2.dilate(solid, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * t + 1, 2 * t + 1))) - solid
    glow = cv2.GaussianBlur(cv2.dilate(solid, cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (4 * t + 1, 4 * t + 1))).astype(np.float32), (0, 0), t * 1.2)
    out = np.zeros(im.shape, np.float32)
    out[:, :, :3] = col
    out[:, :, 3] = glow * 120
    inside = a > 0.02
    out[inside, :3] = body[inside]
    out[inside, 3] = np.maximum(out[inside, 3], a[inside] * opacity * 255)
    e = edge > 0
    out[e, :3] = col
    out[e, 3] = 255
    out = np.clip(out, 0, 255).astype(np.uint8)
    if len(_cache) > 24:
        _cache.clear()
    _cache[k] = (out, pad)
    return _cache[k]
