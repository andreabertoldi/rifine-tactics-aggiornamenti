"""Finestre per il testo sul video e per il cono di luce sui giocatori."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (QCheckBox, QColorDialog, QDialog, QDialogButtonBox, QFontComboBox, QFormLayout,
                               QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QSlider, QSpinBox, QVBoxLayout)

DEFAULT_FONT = "Helvetica"


class _ColorBtn(QPushButton):
    def __init__(self, color, parent=None):
        super().__init__(parent)
        self.setFixedSize(54, 26)
        self.set(color)
        self.clicked.connect(self._pick)

    def set(self, c):
        self.color = QColor(c).name()
        self.setStyleSheet(f"background:{self.color}; border:1px solid #888; border-radius:4px;")

    def _pick(self):
        c = QColorDialog.getColor(QColor(self.color), self, "Colore")
        if c.isValid():
            self.set(c.name())


class TextDialog(QDialog):
    """Scrivi o modifica un testo: carattere, grandezza, colore, grassetto, sfondo; Invio va a capo."""

    def __init__(self, parent=None, d=None, color="#ffeb3b"):
        super().__init__(parent)
        d = d or {}
        self.setWindowTitle("Testo sul video" if not d.get("text") else "Modifica testo")
        self.resize(480, 320)
        lay = QVBoxLayout(self)
        self.edit = QPlainTextEdit(d.get("text", ""))
        self.edit.setPlaceholderText("Scrivi qui. Invio = vai a capo.")
        lay.addWidget(self.edit, 1)
        form = QFormLayout()
        row = QHBoxLayout()
        self.font = QFontComboBox()
        self.font.setCurrentFont(QFont(d.get("font", DEFAULT_FONT)))
        row.addWidget(self.font, 1)
        self.size = QSpinBox()
        self.size.setRange(8, 200)
        self.size.setValue(int(d.get("fsize", 26)))
        self.size.setToolTip("Grandezza del testo (riferita a un video alto 720 punti)")
        row.addWidget(self.size)
        form.addRow("Carattere", row)
        row = QHBoxLayout()
        self.color = _ColorBtn(d.get("color", color))
        row.addWidget(self.color)
        self.bold = QCheckBox("Grassetto")
        self.bold.setChecked(d.get("bold", True))
        row.addWidget(self.bold)
        self.italic = QCheckBox("Corsivo")
        self.italic.setChecked(d.get("italic", False))
        row.addWidget(self.italic)
        self.bg = QCheckBox("Riquadro scuro dietro")
        self.bg.setChecked(d.get("bg", True))
        row.addWidget(self.bg)
        row.addStretch()
        form.addRow("Colore", row)
        self.ground = QCheckBox("Stesa sul campo, in prospettiva (come «4-4-2 LOW BLOCK»; serve il campo calibrato)")
        self.ground.setChecked(bool(d.get("ground", False)))
        form.addRow("", self.ground)
        lay.addLayout(form)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("OK")
        bb.button(QDialogButtonBox.Cancel).setText("Annulla")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.edit.setFocus()

    def values(self):
        return {"text": self.edit.toPlainText().rstrip(), "font": self.font.currentFont().family(),
                "fsize": self.size.value(), "color": self.color.color, "bold": self.bold.isChecked(),
                "italic": self.italic.isChecked(), "bg": self.bg.isChecked(), "ground": self.ground.isChecked()}


class ConeDialog(QDialog):
    """Regola il cono di luce: larghezza del cerchio a terra, altezza del cono, intensità, colore.
    Le modifiche si vedono subito sul video (on_change)."""

    def __init__(self, parent, d, on_change):
        super().__init__(parent)
        self.setWindowTitle("Anello e cono di luce")
        self.d, self.on_change = d, on_change
        self._orig = {k: d.get(k) for k in ("size", "cone", "light", "color", "ring", "cone_on")}
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Anello sotto il giocatore e, se vuoi, il cono di luce dall'alto. "
                             "Le modifiche si vedono subito."))
        form = QFormLayout()
        from PySide6.QtWidgets import QCheckBox, QComboBox
        self.ring = QComboBox()
        self.ring.addItem("Tratteggiato (come nelle analisi FIFA)", "tratteggiato")
        self.ring.addItem("Pieno", "pieno")
        self.ring.setCurrentIndex(0 if d.get("ring") == "tratteggiato" else 1)
        self.ring.currentIndexChanged.connect(self._apply)
        form.addRow("Anello", self.ring)
        self.cone_on = QCheckBox("Cono di luce dall'alto")
        self.cone_on.setChecked(bool(d.get("cone_on", True)))
        self.cone_on.toggled.connect(self._apply)
        form.addRow("", self.cone_on)

        def slider(lo, hi, val):
            s = QSlider(Qt.Horizontal)
            s.setRange(lo, hi)
            s.setValue(int(round(val)))
            s.valueChanged.connect(self._apply)
            return s
        self.s_size = slider(40, 300, 100 * d.get("size", 1.0))
        form.addRow("Larghezza a terra", self.s_size)
        self.s_cone = slider(5, 100, max(5, 10 * d.get("cone", 3.0)))
        form.addRow("Altezza del cono", self.s_cone)
        self.s_light = slider(5, 100, 100 * d.get("light", 0.35))
        form.addRow("Intensità della luce", self.s_light)
        self.color = _ColorBtn(d.get("color", "#ffeb3b"))
        self.color.clicked.connect(self._apply)
        form.addRow("Colore", self.color)
        lay.addLayout(form)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Cancel).setText("Annulla")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self._cancel)
        lay.addWidget(bb)

    def _apply(self, *_):
        self.d["size"] = self.s_size.value() / 100
        self.d["cone"] = self.s_cone.value() / 10
        self.d["light"] = self.s_light.value() / 100
        self.d["color"] = self.color.color
        self.d["ring"] = self.ring.currentData()
        self.d["cone_on"] = self.cone_on.isChecked()
        self.s_cone.setEnabled(self.cone_on.isChecked())
        self.on_change()

    def _cancel(self):
        for k, v in self._orig.items():
            if v is None:
                self.d.pop(k, None)
            else:
                self.d[k] = v
        self.on_change()
        self.reject()
