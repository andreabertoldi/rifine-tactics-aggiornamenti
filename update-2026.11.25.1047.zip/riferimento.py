"""Prova di riferimento per misurare il tracciamento dei giocatori.

Il programma sceglie 15 spezzoni da 6 secondi sparsi nella partita. In ognuno clicchi un giocatore in un
momento difficile (vicino ad altri) e poi, un secondo alla volta, clicchi di nuovo LO STESSO giocatore.
Alla fine il programma salva i clic e i 15 spezzoni in AnalisiVideo/prova_riferimento/<video>/, così il
tracciamento si può misurare in automatico contro le risposte giuste.
"""
import paths
import json
import os
import subprocess
import time

from PySide6.QtWidgets import QMessageBox

N_CLIPS = 15
STEPS = 6          # secondi dopo il primo clic (7 clic per spezzone)
OUT_ROOT = os.path.join(paths.BASE, "prova_riferimento")


class RefSession:
    def __init__(self, win):
        self.win = win
        rd = win.reader
        self.fps = rd.fps
        dur = rd.frame_count / rd.fps
        margin = min(60.0, dur * 0.05)
        span = max(1.0, dur - 2 * margin - STEPS - 1)
        self.starts = [round(margin + span * (k + 0.5) / N_CLIPS, 2) for k in range(N_CLIPS)]
        stem = os.path.splitext(os.path.basename(rd.path))[0]
        self.dir = os.path.join(OUT_ROOT, "".join(c if c.isalnum() or c in " -_." else "_" for c in stem))
        os.makedirs(self.dir, exist_ok=True)
        self.path = os.path.join(self.dir, "prova.json")
        self.data = {"video": rd.path, "fps": rd.fps, "width": rd.width, "height": rd.height, "clips": []}
        if os.path.exists(self.path):
            try:
                with open(self.path, encoding="utf-8") as f:
                    old = json.load(f)
                if old.get("video") == rd.path:
                    self.data = old
            except (OSError, ValueError):
                pass
        done = {c["k"] for c in self.data["clips"]}
        self.todo = [k for k in range(N_CLIPS) if k not in done]
        self.k = None
        self.j = 0
        self.points = []

    # ---------- giro dei clic ----------
    def start(self):
        if not self.todo:
            self._finish()
            return
        self._next_clip()

    def _next_clip(self):
        if not self.todo:
            self._finish()
            return
        self.k = self.todo.pop(0)
        self.j = 0
        self.points = []
        self._ask()

    def _t(self):
        return self.starts[self.k] + self.j

    def _ask(self):
        w = self.win
        w.stop()
        w.seek_time(self._t())
        n = N_CLIPS - len(self.todo)
        if self.j == 0:
            msg = (f"🎯 Prova {n}/{N_CLIPS}: clicca un giocatore VICINO AD ALTRI (contrasto, mischia) "
                   f"· tasti ← → per scegliere il momento · Esc = salta questo spezzone")
        else:
            msg = (f"🎯 Prova {n}/{N_CLIPS} – secondo {self.j} di {STEPS}: clicca LO STESSO giocatore "
                   f"· Esc = salta lo spezzone")
        w.view.pick = {"idx": w.idx, "boxes": [], "color": "#00e5ff", "ref": True, "text": msg,
                       "cb": self._clicked}
        w.view.update()

    def _clicked(self, nx, ny):
        import tracking
        w = self.win
        if self.j == 0:
            # il primo clic può essere in un momento scelto con ← →: lo spezzone parte da lì
            self.first_idx = int(w.idx)
            self.starts[self.k] = round(w.idx / self.fps, 4)
        box = None
        try:
            box = tracking.pick_player(w.reader.frame(w.idx), nx, ny)
        except Exception:
            box = None
        W, H = w.reader.width, w.reader.height
        p = {"j": self.j, "t": round(w.t, 3), "idx": int(w.idx), "click": [round(nx, 5), round(ny, 5)]}
        if box is not None:
            p["box"] = [round(float(box[0]) / W, 5), round(float(box[1]) / H, 5),
                        round(float(box[2]) / W, 5), round(float(box[3]) / H, 5)]
        self.points.append(p)
        self.j += 1
        if self.j > STEPS:
            self._save_clip()
            self._next_clip()
        else:
            self._ask()

    def skip(self):
        """Esc: salta lo spezzone (non salva niente di questo spezzone)."""
        self.win.view.pick = None
        self._next_clip()

    # ---------- salvataggio ----------
    def _save_clip(self):
        t0 = self.starts[self.k]
        clip = {"k": self.k, "start": t0, "first_idx": self.first_idx, "file": f"spezzone_{self.k + 1:02d}.mp4",
                "points": self.points}  # fotogramma dello spezzone = idx - first_idx
        self.data["clips"] = [c for c in self.data["clips"] if c["k"] != self.k] + [clip]
        self.data["saved"] = time.strftime("%Y-%m-%d %H:%M")
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    def _finish(self):
        w = self.win
        w.view.pick = None
        w.view.update()
        clips = sorted(self.data["clips"], key=lambda c: c["k"])
        if not clips:
            QMessageBox.information(w, "Prova di riferimento", "Nessuno spezzone fatto: non c'è niente da salvare.")
            return
        import export as exp
        ff = exp.ffmpeg_exe()
        video = self.data["video"]

        def work(progress, cancelled):
            out = []
            for i, c in enumerate(clips):
                if cancelled():
                    break
                dst = os.path.join(self.dir, c["file"])
                progress(i / len(clips), f"Preparo lo spezzone {i + 1} di {len(clips)}…")
                if not os.path.exists(dst):
                    # ricodificato (non copiato) così il fotogramma 0 è esattamente l'inizio dello spezzone
                    ss = max(0.0, (c["first_idx"] - 0.5) / self.fps)  # mezzo fotogramma prima: parte proprio da lì
                    cmd = [ff, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{ss:.4f}", "-i", video,
                           "-t", f"{STEPS + 0.6:.2f}", "-an"] + exp.video_args(18) + [dst]
                    subprocess.run(cmd, capture_output=True)
                out.append(dst)
            progress(1.0, "Fatto")
            return out

        def done(paths):
            QMessageBox.information(w, "Prova di riferimento",
                                    f"Fatto, grazie! Salvati {len(clips)} spezzoni con i tuoi clic in:\n{self.dir}\n\n"
                                    "Scrivi a Claude che hai finito: misurerà il tracciamento con queste risposte.")

        w._run_job("Prova di riferimento", work, done)
