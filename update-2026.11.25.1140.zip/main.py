"""Analisi Video Calcio — finestra principale."""
import base64
import paths
import json
import math
import os
import sys
import time

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from PySide6.QtCore import QEvent, QObject, QSettings, QSize, Qt, QThread, QTimer, Signal, Slot
from PySide6.QtGui import QAction, QColor, QIcon, QKeySequence, QPalette, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QAbstractSpinBox, QApplication, QButtonGroup, QCheckBox,
                               QColorDialog, QComboBox, QDoubleSpinBox, QFileDialog, QFrame, QGridLayout,
                               QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QMainWindow, QMenu, QMessageBox, QPlainTextEdit, QProgressDialog, QPushButton,
                               QScrollArea, QSizePolicy, QSplitter, QTableWidget, QTableWidgetItem, QTabWidget, QTextEdit,
                               QToolButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

import numpy as np

import export as exp
from dialogs import Bridge, EventDialog, ExportVideoDialog, PanelDialog, Worker
from model import DRAWING_KINDS, Project, fmt_time, project_path_for_video
from video import Prefetcher, VideoReader
from viewer import VideoView
from audio import Audio
import tracking
from calib import CalibDialog
from camera import apply as cam_apply


class _RowScroll(QScrollArea):
    """Una riga di comandi che scorre in orizzontale quando non ci sta: così la finestra non si allarga
    oltre lo schermo. La barra di scorrimento occupa spazio solo quando serve davvero."""

    def __init__(self, layout):
        super().__init__()
        layout.setContentsMargins(0, 0, 0, 0)
        w = QWidget()
        w.setLayout(layout)
        self._w = w
        self.setFrameShape(QFrame.NoFrame)
        self.setWidgetResizable(True)
        self.setWidget(w)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setMinimumWidth(0)
        self._fit()

    def _fit(self):
        need = self._w.minimumSizeHint().width() > self.width()
        h = self._w.minimumSizeHint().height() + (self.horizontalScrollBar().sizeHint().height() if need else 0)
        if self.height() != h or self.minimumHeight() != h:
            self.setFixedHeight(h)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._fit()


def _row_scroll(layout):
    return _RowScroll(layout)
from dynamic import Scene, pitch_lines
from model import new_id
from widgets import FieldWidget
from timeline2 import TrackTimeline

APP_NAME = "Rifine Tactics"
VIDEO_FILTER = "Video (*.mp4 *.mov *.m4v *.avi *.mkv *.mts *.m2ts *.MP4 *.MOV *.M4V *.AVI *.MKV *.MTS)"

TOOL_ICONS = [
    (None, "↖", "Seleziona / sposta disegni"),
    ("freccia", "➜", "Freccia"),
    ("movimento", "⇢", "Movimento (freccia tratteggiata)"),
    ("curva", "↷", "Freccia curva: trascina dall'inizio alla fine, poi tira il pallino in mezzo per curvarla"),
    ("linea", "╱", "Linea"),
    ("cerchio", "◯", "Cerchio"),
    ("spotlight", "◉", "Evidenzia e SEGUI un giocatore: clicca sul giocatore (scia, velocità, distanza dalla porta)"),
    ("cono", "💡", "Cono di luce FISSO: clicca un giocatore o un punto qualsiasi. Non lo segue: resta dove lo metti"),
    ("fantasma", "👻", "Fantasma: clicca il giocatore, poi il punto dove doveva stare (sagoma, freccia e metri)"),
    ("zona", "▭", "Zona rettangolare"),
    ("area", "⬠", "Area riempita: CLICCA i punti uno alla volta per avere lati dritti (doppio clic per chiudere), oppure trascina per disegnarla a mano libera"),
    ("mano", "✎", "Disegno a mano libera"),
    ("testo", "T", "Testo"),
    ("distanza", "📏", "Distanza in metri tra due giocatori o punti del campo (clicca il primo e il secondo)"),
    ("collega", "⛓", "Collega giocatori (linea difensiva…): clicca i giocatori, doppio clic o Invio per finire"),
    ("visuale", "◔", "Visuale del giocatore: clicca il giocatore, poi il punto (o il compagno) verso cui guarda"),
    ("palla", "⚽", "Traiettoria della palla: clicca sulla palla quando parte il passaggio, il programma la segue"),
]
COLORS = ["#ffeb3b", "#ff5252", "#40c4ff", "#69f0ae", "#ffffff", "#ff9100", "#e040fb", "#000000"]


def PERF_EVENT(text):
    try:
        p = os.path.join(paths.BASE, "registro_tempi.txt")
        with open(p, "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S") + " | " + text + "\n")
    except OSError:
        pass


SNAP_DIR = os.path.join(paths.BASE, "registro_immagini")


SNAP_ON = [False]  # immagini per l'assistenza: spente (si accendono da Aiuto)


def move_to_trash(path):
    """Sposta un file o una cartella nel Cestino del Mac (si può sempre recuperare da lì)."""
    if not os.path.exists(path):
        return True
    try:
        from Foundation import NSFileManager, NSURL
        ok, _url, _err = NSFileManager.defaultManager().trashItemAtURL_resultingItemURL_error_(
            NSURL.fileURLWithPath_(path), None, None)
        if ok:
            return True
    except Exception:
        pass
    try:
        import subprocess
        p = path.replace('"', '\\"')
        r = subprocess.run(["osascript", "-e", f'tell application "Finder" to delete (POSIX file "{p}")'],
                           capture_output=True, timeout=20)
        return r.returncode == 0
    except Exception:
        return False


def cleanup_once():
    """Pulizia richiesta dall'utente: video di prova e immagini del registro nel Cestino (una volta)."""
    if paths.FROZEN:
        return
    root = paths.BASE
    marker = os.path.join(root, "app", ".pulizia_2")
    if os.path.exists(marker):
        return
    ok = all([move_to_trash(os.path.join(root, name)) for name in ("_prova_temporanea", "registro_immagini")])
    PERF_EVENT("pulizia: file di prova e immagini " + ("spostati nel Cestino" if ok else "NON spostati nel Cestino"))
    if ok:
        try:
            open(marker, "w").close()
        except OSError:
            pass


def save_snap(widget, name, mark=None):
    """Salva una piccola immagine di quello che si vede (per l'assistenza), tiene le ultime 200."""
    if not SNAP_ON[0]:
        return
    try:
        os.makedirs(SNAP_DIR, exist_ok=True)
        pm = widget.grab()
        if mark is not None:
            from PySide6.QtGui import QPainter as _P, QPen as _Pen, QColor as _C
            p = _P(pm)
            p.setPen(_Pen(_C("#ff00ff"), 4))
            p.drawEllipse(mark, 14, 14)
            p.end()
        pm = pm.scaledToWidth(960)
        pm.save(os.path.join(SNAP_DIR, time.strftime("%H%M%S") + f"_{name}.jpg"), "JPG", 70)
        files = sorted(os.listdir(SNAP_DIR))
        for fn in files[:-200]:
            os.remove(os.path.join(SNAP_DIR, fn))
    except Exception:
        pass


class Perf:
    """Registro dei tempi durante la riproduzione (per capire cosa rallenta): ogni 3 secondi una riga
    nel file «registro_tempi.txt» nella cartella del programma."""

    def __init__(self):
        self.path = os.path.join(paths.BASE, "registro_tempi.txt")
        self.reset()

    def reset(self):
        self.t0 = time.perf_counter()
        self.sums, self.maxs, self.ns, self.counts = {}, {}, {}, {}
        self.frames = 0
        self.ticks = []

    def add(self, k, dt):
        self.sums[k] = self.sums.get(k, 0) + dt
        self.maxs[k] = max(self.maxs.get(k, 0), dt)
        self.ns[k] = self.ns.get(k, 0) + 1

    def event(self, text):
        try:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(time.strftime("%H:%M:%S") + " | " + text + "\n")
        except OSError:
            pass

    def count(self, k):
        self.counts[k] = self.counts.get(k, 0) + 1

    def tick(self, win):
        now = time.perf_counter()
        if self.ticks:
            self.add("intervallo tra i tick", now - self.ticks[-1])
        self.ticks = [now]
        if now - self.t0 > 3:
            self.flush(win)

    def flush(self, win=None):
        el = time.perf_counter() - self.t0
        if el < 0.5 or not self.ns:
            self.reset()
            return
        parts = [f"{k}: media {1000 * self.sums[k] / self.ns[k]:.0f} ms, max {1000 * self.maxs[k]:.0f} ms"
                 for k in self.sums]
        parts += [f"{k}: {v}" for k, v in self.counts.items()]
        if win is not None and getattr(win, "scene", None) is not None and getattr(win.scene, "stats", None):
            parts += [f"{k}: {v}" for k, v in win.scene.stats.items()]
            win.scene.stats = {}
        shown = self.ns.get("lettura video", 0)
        extra = ""
        if win is not None:
            extra = (f" | giocatori in calcolo: {len(win._followers)} | velocità {win.speed:g}x"
                     f" | calibrazioni: {len(win.project.calibrations)}")
        head = time.strftime("%H:%M:%S") + f" | fotogrammi mostrati al secondo: {shown / el:.1f}"
        if win is not None and win.reader:
            head += f" (video {win.reader.fps:.0f})"
        line = head + extra + " | " + " | ".join(parts)
        try:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass
        self.reset()


class FollowWorker(QObject):
    """Segue un giocatore in sottofondo, mentre il video va avanti, e manda i risultati a blocchi."""
    batch = Signal(str, object, bool, str)  # id traccia, dati, finito, motivo

    def __init__(self, vpath, cam, tid, start, box, limit_frames):
        super().__init__()
        self.vpath, self.cam, self.tid, self.start, self.box = vpath, cam, tid, start, box
        self.limit = limit_frames
        self._stop = False

    def stop(self):
        self._stop = True

    @Slot()
    def run(self):
        rd = None
        reason = "stop"
        raw = {}
        try:
            rd = VideoReader(self.vpath)
            det = tracking.Detector(tracking.MODEL_PATH)
            end = min(rd.frame_count - 1, self.start + self.limit)
            chunk = max(10, int(rd.fps * 2))
            cam_done = self.start
            tr = None
            sent = self.start
            i = self.start
            t_start = time.perf_counter()
            n_done = 0
            while i < end and not self._stop:
                if cam_done <= i:
                    b = min(end, i + chunk)
                    self.cam.ensure(rd, cam_done, b, cancel=lambda: self._stop)
                    cam_done = b
                if tr is None:
                    # il giocatore si cerca ~10 volte al secondo (basta e avanza): con video a 25-60
                    # fotogrammi al secondo il calcolo resta al passo con il video
                    stride = max(1, int(math.ceil(rd.fps / 9.0)))
                    tr = tracking.PlayerTracker(rd, self.cam, self.start, self.box, det, stride=stride)
                    raw[self.start] = tr.first
                    last_k = self.start
                prev_i = i
                i = min(end, i + tr.stride)
                if cam_done < i:
                    b = min(end, i + chunk)
                    self.cam.ensure(rd, cam_done, b, cancel=lambda: self._stop)
                    cam_done = b
                v = tr.step(i)
                n_done += i - prev_i
                if n_done % 60 < tr.stride:
                    el = time.perf_counter() - t_start
                    PERF_EVENT(f"calcolo giocatore: {n_done / el:.1f} fotogrammi al secondo (video {rd.fps:.0f}, "
                               f"cercato ogni {tr.stride})")
                if v is not None:
                    raw[i] = v
                    # posizioni dei fotogrammi in mezzo: a metà strada tra le due trovate
                    if last_k is not None and 1 < i - last_k <= 3 * tr.stride:
                        a = raw[last_k]
                        for k in range(last_k + 1, i):
                            t = (k - last_k) / (i - last_k)
                            raw[k] = [a[j] * (1 - t) + v[j] * t for j in range(3)] + [min(a[3], v[3])]
                    last_k = i
                else:
                    last_k = None
                if tr.finished:
                    reason = tr.reason
                    if reason == "doubt" and tr.doubt:
                        reason = "doubt:" + json.dumps(tr.doubt)
                    break
                if i - sent >= 8:
                    tail = {k: raw[k] for k in raw if k >= sent - 8}
                    sm = tracking.smooth_track(tail)
                    out = {k: v for k, v in sm.items() if sent - 2 < k <= i - 3}
                    if out:
                        self.batch.emit(self.tid, out, False, "")
                    sent = i - 3
            else:
                if not self._stop:
                    reason = "end"
            tail = {k: raw[k] for k in raw if k >= sent - 8}
            sm = tracking.smooth_track(tail)
            self.batch.emit(self.tid, {k: v for k, v in sm.items() if k > sent - 2}, True, reason)
        except Exception as e:  # noqa
            self.batch.emit(self.tid, {}, True, "errore: " + str(e))
        finally:
            if rd is not None:
                rd.close()


class FollowBridge(QObject):
    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self.fn = fn

    @Slot(str, object, bool, str)
    def batch(self, tid, data, finished, reason):
        self.fn(tid, data, finished, reason)


ACT_PATH = os.path.join(paths.BASE, "registro_azioni.txt")


def _dd(d):
    """Descrizione corta di un disegno per il registro azioni."""
    if not d:
        return "?"
    return f"{d.get('kind', '?')} #{d.get('id', '?')} (a {d.get('t', 0):.1f} s)"


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = QSettings("AnalisiVideo", "AnalisiVideoCalcio")
        self.project = Project()
        self._load_last_panel()
        self.reader = None
        self.idx = 0
        self.playing = False
        self.speed = 1.0
        self.team = "home"
        self.player = None
        self._digits = ""
        self._digit_time = 0
        self.pending_pos = None
        self.undo = []
        self.playlist = None  # [(start, end)], index
        self._hold_until = 0
        self._hold = None
        self._paused_done = set()
        self._threads = []
        self._followers = {}  # id traccia -> (thread, worker, bridge)
        self._who_queue = []  # inseguimenti fermi in attesa di "chi è?"
        self._pf = None
        self.perf = Perf()
        self._waiting = False
        self._dirty = False
        self.prog = None  # lavoro (progetto) aperto
        self.audio = Audio(self)
        self.audio.set_muted(self.settings.value("audio_muted", False, type=bool))

        self.setWindowTitle(APP_NAME)
        scr = QApplication.primaryScreen().availableGeometry()
        self.resize(min(1440, scr.width() - 16), min(900, scr.height() - 40))
        self._build_ui()
        self._build_menus()
        self.play_timer = QTimer(self)
        self.play_timer.setTimerType(Qt.PreciseTimer)
        self.play_timer.setInterval(8)
        self.play_timer.timeout.connect(self._tick)
        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.setInterval(800)
        self.save_timer.timeout.connect(self.save_project)
        QApplication.instance().installEventFilter(self)
        self.refresh_all()
        self._update_player_label()

    # ================= UI =================
    def _build_ui(self):
        root = QSplitter(Qt.Horizontal)
        self.setCentralWidget(root)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(6, 6, 6, 6)
        lv.setSpacing(5)

        # --- barra disegno
        dbar = QHBoxLayout()
        dbar.setSpacing(3)
        self.tool_group = QButtonGroup(self)
        self.tool_group.setExclusive(True)
        self.tool_buttons = {}
        for kind, icon, tip in TOOL_ICONS:
            b = QToolButton()
            b.setText(icon)
            b.setToolTip(tip)
            b.setCheckable(True)
            b.setFixedSize(34, 30)
            b.setObjectName("toolbtn")
            self.tool_group.addButton(b)
            self.tool_buttons[kind] = b
            b.clicked.connect(lambda _=False, k=kind: self.set_tool(k))
            dbar.addWidget(b)
        self.tool_buttons[None].setChecked(True)
        dbar.addSpacing(8)
        self.color_buttons = []
        for c in COLORS:
            b = QToolButton()
            b.setFixedSize(22, 22)
            b.setCheckable(True)
            b.setStyleSheet(f"QToolButton{{background:{c}; border:1px solid #555; border-radius:11px;}}"
                            f"QToolButton:checked{{border:3px solid white;}}")
            b.clicked.connect(lambda _=False, col=c: self.set_color(col))
            self.color_buttons.append((c, b))
            dbar.addWidget(b)
        self.color_buttons[0][1].setChecked(True)
        dbar.addSpacing(8)
        dbar.addWidget(QLabel("Spessore"))
        self.width_cb = QComboBox()
        for w in (2, 3, 4, 6, 8, 12):
            self.width_cb.addItem(str(w), w)
        self.width_cb.setCurrentIndex(2)
        self.width_cb.currentIndexChanged.connect(self.set_width)
        dbar.addWidget(self.width_cb)
        dbar.addSpacing(8)
        self.dur_sp = QDoubleSpinBox()
        self.dur_sp.setRange(0.5, 600)
        self.dur_sp.setDecimals(1)
        self.dur_sp.setValue(float(self.settings.value("draw_dur", 4.0)))
        self.dur_sp.setSuffix(" s")
        self.dur_sp.setToolTip("Per quanti secondi il disegno resta sul video mentre scorre, poi sparisce.\n"
                               "Se è su un giocatore, lo segue per tutti questi secondi.")
        dbar.addStretch()

        # --- FERMO IMMAGINE (come DigitalLog): un pezzo fermo nel video, con i disegni sopra
        mbar = QHBoxLayout()
        mbar.setSpacing(8)
        b = QPushButton("📷+  Fermo immagine")
        b.setObjectName("mode_freeze")
        b.setCheckable(False)
        b.setFocusPolicy(Qt.NoFocus)
        b.setMinimumHeight(30)
        b.setToolTip("Aggiunge un fermo immagine nel punto in cui sei: il video si ferma lì per i secondi che "
                     "scegli.\nI disegni che fai sopra stanno dentro il fermo. Tasto F.")
        b.clicked.connect(self.add_still)
        self.still_btn = b
        mbar.addWidget(b)
        self.mode_help = QLabel("Ferma il video dove vuoi → 📷+ → disegna. Un disegno fatto fuori da un fermo "
                                "scorre col video per")
        self.mode_help.setStyleSheet("color:#8a93a3")
        mbar.addWidget(self.mode_help)
        mbar.addWidget(self.dur_sp)
        mbar.addStretch()
        lv.addWidget(_row_scroll(mbar))
        lv.addWidget(_row_scroll(dbar))

        # --- opzioni disegni dinamici
        obar = QHBoxLayout()
        obar.setSpacing(6)
        self.anchor_chk = QCheckBox("📌 Disegni agganciati al campo")
        self.anchor_chk.setToolTip("Frecce, zone e cerchi restano sul punto del campo anche quando la telecamera si muove")
        self.anchor_chk.setChecked(self.settings.value("anchor", "true") == "true")
        self.anchor_chk.toggled.connect(lambda v: self.settings.setValue("anchor", "true" if v else "false"))
        obar.addWidget(self.anchor_chk)
        obar.addSpacing(14)
        self._lbl_follow = QLabel("Giocatore seguito:")
        obar.addWidget(self._lbl_follow)
        self.follow_sp = QDoubleSpinBox()
        self.follow_sp.setRange(0, 600)
        self.follow_sp.setDecimals(0)
        self.follow_sp.setPrefix("per ")
        self.follow_sp.setSuffix(" s")
        self.follow_sp.setSpecialValueText("finché lo fermo")
        if not self.settings.value("follow_default_10", False, type=bool):
            # di base segue per 10 secondi (prima: fino a 10 minuti avanti); si cambia qui nella barra
            self.settings.setValue("follow_default_10", True)
            self.settings.setValue("follow_secs", 10)
        self.follow_sp.setValue(float(self.settings.value("follow_secs", 10)))
        self.follow_sp.setToolTip("Per quanti secondi seguirlo e misurarlo. «finché lo fermo»: tasto destro sul "
                                  "giocatore → Smetti di seguirlo (o tasto S)")
        self.follow_sp.valueChanged.connect(lambda v: self.settings.setValue("follow_secs", v))
        obar.addWidget(self.follow_sp)
        self.sam_chk = QCheckBox("🎯 preciso")
        self.sam_chk.setToolTip("Segui con precisione (SAM 2): segue la sagoma del giocatore e sbaglia molto meno nei "
                                "contrasti, ma calcola più lentamente (circa 1 s per ogni secondo di video e per ogni giocatore). "
                                "Di base è acceso: spegnilo solo se hai fretta o segui a lungo. Vale per i giocatori che segui da adesso.")
        self.sam_chk.setFocusPolicy(Qt.NoFocus)
        import samfollow as _sf
        self.sam_chk.setChecked(self.settings.value("sam_on", True, type=bool) and _sf.available())
        self.sam_chk.toggled.connect(self._set_sam)
        obar.addWidget(self.sam_chk)
        self.lens_chk = QCheckBox("🔍 lente")
        self.lens_chk.setToolTip("Lente d'ingrandimento vicino al puntatore quando devi cliccare un giocatore.\n"
                                 "Togli la spunta per non vederla.")
        self.lens_chk.setFocusPolicy(Qt.NoFocus)
        self.lens_chk.setChecked(self.settings.value("lens", True, type=bool))
        self.lens_chk.toggled.connect(self._set_lens)
        obar.addWidget(self.lens_chk)
        # scia e dati del giocatore non stanno più nella barra: si scelgono nel pannello «Proprietà» del
        # giocatore. Queste caselle (non mostrate) ricordano solo l'ultima scelta, per i prossimi giocatori.
        self.trail_sp = QDoubleSpinBox()
        self.trail_sp.setRange(0, 15)
        self.trail_sp.setDecimals(0)
        self.trail_sp.setSuffix(" s")
        self.trail_sp.setSpecialValueText("no")
        self.trail_sp.setValue(float(self.settings.value("trail", 3)))
        self.trail_sp.setToolTip("Giocatore seguito: la riga che lascia dietro di sé, cioè il percorso fatto\n"
                                 "negli ultimi secondi indicati (3 s = si vede da dove arriva). «no» = niente riga.")
        self.speed_chk = QCheckBox("velocità")
        self.speed_chk.setChecked(self.settings.value("show_speed", "true") == "true")
        self.goal_chk = QCheckBox("distanza porta")
        self.goal_chk.setChecked(self.settings.value("show_goal", "false") == "true")
        self.run_chk = QCheckBox("metri percorsi")
        self.run_chk.setChecked(self.settings.value("show_run", "false") == "true")
        self.link_cb = QComboBox()
        self.link_cb.addItem("➖ Linea", "linea")
        self.link_cb.addItem("⬡ Figura chiusa", "chiusa")
        self.link_cb.addItem("⬢ Figura riempita", "riempita")
        self.link_cb.setToolTip("Collega giocatori:\n➖ Linea = i giocatori uniti in fila (es. linea difensiva)\n"
                                "⬡ Figura chiusa = l'ultimo si collega al primo (triangolo, quadrato…)\n"
                                "⬢ Figura riempita = come la chiusa, con l'interno colorato\n"
                                "Vale per i nuovi collegamenti e per quello selezionato.")
        self.link_cb.setFocusPolicy(Qt.NoFocus)
        self.link_cb.currentIndexChanged.connect(self._link_changed)
        obar.addWidget(self.link_cb)
        self.anchor_chk.setFocusPolicy(Qt.NoFocus)
        self.magnet_chk = QCheckBox("🧲 sui giocatori")
        self.magnet_chk.setToolTip("Un cerchio, una freccia o un testo disegnati su un giocatore lo seguono mentre si muove")
        self.magnet_chk.setChecked(self.settings.value("magnet", "true") == "true")
        self.magnet_chk.toggled.connect(lambda v: self.settings.setValue("magnet", "true" if v else "false"))
        self.magnet_chk.setFocusPolicy(Qt.NoFocus)
        obar.insertWidget(1, self.magnet_chk)
        self._move_only = [self.anchor_chk, self.magnet_chk, self._lbl_follow, self.follow_sp, self.link_cb]
        obar.addStretch()
        self.calib_lbl = QLabel()
        obar.addWidget(self.calib_lbl)
        self.lines_chk = QCheckBox("📐 mostra linee")
        self.lines_chk.setToolTip("Disegna sul video le linee del campo come le ha calcolate l'app: se restano sulle "
                                  "linee vere in tutto il video, la calibrazione (e quindi metri e km/h) è giusta")
        self.lines_chk.setFocusPolicy(Qt.NoFocus)
        self.lines_chk.toggled.connect(self._toggle_lines)
        obar.addWidget(self.lines_chk)
        b = QPushButton("📐 Calibra campo")
        b.setFocusPolicy(Qt.NoFocus)
        b.setToolTip("Indica 4 punti noti del campo: servono per metri e km/h")
        b.clicked.connect(self.calibrate)
        obar.addWidget(b)
        lv.addWidget(_row_scroll(obar))

        # --- video
        self.view = VideoView()
        self.view.playing_fn = lambda: self.playing
        self.view.perf = self.perf
        self.view.drawingCreated.connect(self.on_drawing_created)
        self.view.drawingSelected.connect(self.on_view_drawing_selected)
        self.view.drawingMoved.connect(self.on_drawing_moved)
        self.view.playerClicked.connect(self.on_player_clicked)
        self.view.coneClicked.connect(self.on_cone_clicked)
        self.view.ghostClicked.connect(self.on_ghost_clicked)
        self.view.multiCreated.connect(self.on_multi_created)
        self.view.contextRequested.connect(self.on_video_context)
        self.view.drawingDouble.connect(self.on_drawing_double)
        self.view.fileDropped.connect(self.open_path)
        self.view.scrubbed.connect(self.step)
        # video sopra, comandi e linea del tempo sotto: il bordo tra i due si trascina per dare più spazio al video
        vsplit = QSplitter(Qt.Vertical)
        vsplit.setChildrenCollapsible(False)
        vsplit.addWidget(self.view)
        bottom = QWidget()
        bl = QVBoxLayout(bottom)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(5)
        lv.addWidget(vsplit, 1)
        self.vsplit = vsplit

        self.timeline = TrackTimeline()
        self.timeline.seek.connect(self.seek_out)
        self.timeline.cutMenu.connect(self._cut_menu)
        self.timeline.drawingClicked.connect(self._tl_drawing_clicked)
        self.timeline.drawingEdited.connect(self._tl_drawing_edited)
        self.timeline.pieceEdited.connect(self._tl_piece_edited)
        self.timeline.drawingMenu.connect(self._tl_drawing_menu)
        self.timeline.stillClicked.connect(lambda sid: None)
        self.timeline.stillEdited.connect(lambda sid: self.set_still_dur(sid, self.project.still(sid)["dur"]))
        self.timeline.stillMenu.connect(self._tl_still_menu)
        self.timeline.stillDouble.connect(self._tl_still_dur_dialog)

        # --- trasporto
        tr = QHBoxLayout()
        def tbtn(text, tip, fn, w=40):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.setFixedWidth(w)
            b.setFocusPolicy(Qt.NoFocus)
            b.clicked.connect(fn)
            tr.addWidget(b)
            return b
        tbtn("⏮", "Inizio del video", lambda: self.seek_time(0), 36)
        tbtn("−5s", "Indietro 5 secondi (⇧←)", lambda: self.seek_time(self.t - 5), 46)
        tbtn("◀︎|", "Fotogramma precedente (←)", lambda: self.step(-1))
        self.play_btn = tbtn("▶︎", "Play / pausa (spazio)", self.toggle_play, 54)
        tbtn("|▶︎", "Fotogramma successivo (→)", lambda: self.step(1))
        tbtn("+5s", "Avanti 5 secondi (⇧→)", lambda: self.seek_time(self.t + 5), 46)
        tbtn("⏭", "Fine del video", lambda: self.seek_time(self.reader.duration - 0.05) if self.reader else None, 36)
        self.time_lbl = QLabel("00:00.0 / 00:00")
        self.time_lbl.setObjectName("timelbl")
        self.time_lbl.setMinimumWidth(130)
        tr.addSpacing(8)
        tr.addWidget(self.time_lbl)
        tr.addWidget(QLabel("Velocità"))
        self.speed_cb = QComboBox()
        for s in (0.25, 0.5, 0.75, 1.0, 1.5, 2.0):
            self.speed_cb.addItem(f"{s:g}×", s)
        self.speed_cb.setCurrentIndex(3)
        self.speed_cb.setFocusPolicy(Qt.NoFocus)
        self.speed_cb.currentIndexChanged.connect(lambda: self.set_speed(self.speed_cb.currentData()))
        tr.addWidget(self.speed_cb)
        self.mute_btn = QToolButton()
        self.mute_btn.setCheckable(True)
        self.mute_btn.setChecked(self.audio.muted)
        self.mute_btn.setText("🔇" if self.audio.muted else "🔊")
        self.mute_btn.setToolTip("Audio del video: clic per togliere o rimettere il suono")
        self.mute_btn.setFocusPolicy(Qt.NoFocus)
        self.mute_btn.toggled.connect(self.set_muted)
        tr.addWidget(self.mute_btn)
        self.pause_chk = QCheckBox("Fermati sui fermi immagine")
        self.pause_chk.setChecked(True)
        self.pause_chk.setFocusPolicy(Qt.NoFocus)
        self.pause_chk.setToolTip("In riproduzione il video si ferma sui fermi immagine (pezzi arancioni)")
        self.pause_chk.toggled.connect(self._on_pause_toggle)
        tr.addWidget(self.pause_chk)
        tr.addStretch()
        # esportazione semplice di un pezzo di video
        self.in_btn = QPushButton("[ Inizio")
        self.in_btn.setToolTip("Segna qui l'inizio del pezzo da esportare (tasto I)")
        self.in_btn.setFocusPolicy(Qt.NoFocus)
        self.in_btn.clicked.connect(self.mark_in)
        tr.addWidget(self.in_btn)
        self.out_btn = QPushButton("Fine ]")
        self.out_btn.setToolTip("Segna qui la fine del pezzo da esportare (tasto O)")
        self.out_btn.setFocusPolicy(Qt.NoFocus)
        self.out_btn.clicked.connect(self.mark_out)
        tr.addWidget(self.out_btn)
        self.clear_piece_btn = QPushButton("✕")
        self.clear_piece_btn.setToolTip("Togli il pezzo segnato (tasto X)")
        self.clear_piece_btn.setFocusPolicy(Qt.NoFocus)
        self.clear_piece_btn.setMaximumWidth(34)
        self.clear_piece_btn.clicked.connect(self.clear_piece)
        self.clear_piece_btn.hide()
        tr.addWidget(self.clear_piece_btn)
        b = QPushButton("💾 Esporta pezzo")
        b.setToolTip("Esporta in MP4 il pezzo tra Inizio e Fine, con i disegni (tasto E)")
        b.setFocusPolicy(Qt.NoFocus)
        b.clicked.connect(self.export_piece)
        tr.addWidget(b)
        b = QPushButton("✂ Togli pezzo")
        b.setToolTip("Toglie dal video il pezzo tra Inizio e Fine (tempi morti, pause…): viene saltato in "
                     "riproduzione e nei video esportati. Il file originale NON viene toccato e il pezzo si "
                     "può rimettere (tasto destro sulla barra del tempo).")
        b.setFocusPolicy(Qt.NoFocus)
        b.clicked.connect(self.cut_piece)
        tr.addWidget(b)
        b = QPushButton("➕ Raccolta")
        b.setToolTip("Aggiunge il pezzo tra Inizio e Fine alla raccolta (anche da video diversi), da esportare "
                     "tutta insieme in un unico video o pezzo per pezzo")
        b.setFocusPolicy(Qt.NoFocus)
        b.clicked.connect(self.add_to_raccolta)
        tr.addWidget(b)
        b = QPushButton("📷 Foto")
        b.setToolTip("Salva il fotogramma attuale con i disegni (JPG/PNG)")
        b.setFocusPolicy(Qt.NoFocus)
        b.clicked.connect(self.export_photo_current)
        tr.addWidget(b)
        b = QPushButton("☰ Linea del tempo")
        b.setToolTip("Mostra o nascondi la linea del tempo, per avere il video più grande (⌘L)")
        b.setFocusPolicy(Qt.NoFocus)
        b.clicked.connect(self.toggle_timeline)
        tr.addWidget(b)
        b = QPushButton("⛶ Schermo intero")
        b.setToolTip("Video a schermo intero con tutte le barre di lavoro (⌘F, Esc per uscire)")
        b.setFocusPolicy(Qt.NoFocus)
        b.clicked.connect(self.toggle_focus)
        tr.addWidget(b)
        self.full_btn = b
        bl.addWidget(_row_scroll(tr))
        zb = QHBoxLayout()
        zb.setSpacing(2)
        for txt, tip, fn in (("−", "Rimpicciolisci la linea del tempo (o rotella del mouse)", lambda: self.timeline.zoom(1.5)),
                             ("+", "Ingrandisci la linea del tempo (o rotella del mouse)", lambda: self.timeline.zoom(0.66)),
                             ("⤢", "Mostra tutto il video", self.timeline.fit)):
            b = QPushButton(txt)
            b.setFixedSize(30, 22)
            b.setToolTip(tip)
            b.setFocusPolicy(Qt.NoFocus)
            b.clicked.connect(fn)
            zb.addWidget(b)
        zb.addWidget(QLabel("<span style='color:#8a93a3'>linea del tempo: rotella = zoom, ⇧+rotella = scorri</span>"))
        zb.addStretch()
        self.tl_box = QWidget()
        tlb = QVBoxLayout(self.tl_box)
        tlb.setContentsMargins(0, 0, 0, 0)
        tlb.setSpacing(3)
        tlb.addWidget(self.timeline, 1)
        tlb.addWidget(_row_scroll(zb))
        bl.addWidget(self.tl_box, 1)
        vsplit.addWidget(bottom)
        vsplit.setStretchFactor(0, 1)
        vsplit.setStretchFactor(1, 0)
        saved = self.settings.value("split_video")
        if saved:
            try:
                vsplit.setSizes([int(x) for x in saved])
            except (TypeError, ValueError):
                pass
        vsplit.splitterMoved.connect(lambda *_: self.settings.setValue("split_video", vsplit.sizes()))
        if self.settings.value("tl_hidden", False, type=bool):
            self.tl_box.hide()

        # --- pannello tagging
        tagbox = QFrame()
        tagbox.setObjectName("tagbox")
        th = QHBoxLayout(tagbox)
        th.setContentsMargins(6, 6, 6, 6)
        self.tag_grid_w = QWidget()
        self.tag_grid = QGridLayout(self.tag_grid_w)
        self.tag_grid.setSpacing(4)
        self.tag_grid.setContentsMargins(0, 0, 0, 0)
        th.addWidget(self.tag_grid_w, 3)
        side = QVBoxLayout()
        side.setSpacing(4)
        tb = QHBoxLayout()
        self.team_btns = {}
        self.team_group = QButtonGroup(self)
        for k in ("home", "away"):
            b = QPushButton()
            b.setCheckable(True)
            b.setFocusPolicy(Qt.NoFocus)
            b.setObjectName("teambtn")
            b.clicked.connect(lambda _=False, kk=k: self.set_team(kk))
            self.team_group.addButton(b)
            self.team_btns[k] = b
            tb.addWidget(b)
        self.team_btns["home"].setChecked(True)
        side.addLayout(tb)
        self.player_lbl = QLabel()
        self.player_lbl.setObjectName("playerlbl")
        self.player_lbl.setWordWrap(True)
        side.addWidget(self.player_lbl)
        self.player_cb = QComboBox()
        self.player_cb.setFocusPolicy(Qt.NoFocus)
        self.player_cb.activated.connect(self._player_from_combo)
        side.addWidget(self.player_cb)
        self.askpos_chk = QCheckBox("Chiedi posizione dopo ogni tag")
        self.askpos_chk.setFocusPolicy(Qt.NoFocus)
        self.askpos_chk.setChecked(self.settings.value("ask_pos", "false") == "true")
        self.askpos_chk.toggled.connect(lambda v: self.settings.setValue("ask_pos", "true" if v else "false"))
        side.addWidget(self.askpos_chk)
        b = QPushButton("⚙︎ Pannello e rosa…")
        b.setFocusPolicy(Qt.NoFocus)
        b.clicked.connect(self.edit_panel)
        side.addWidget(b)
        side.addStretch()
        th.addLayout(side, 1)
        self.mini_field = FieldWidget(interactive=True, compact=True)
        self.mini_field.setFixedWidth(230)
        self.mini_field.setToolTip("Clicca per salvare la posizione dell'ultimo evento (o di quello selezionato)")
        self.mini_field.clicked.connect(self.on_field_click)
        th.addWidget(self.mini_field)
        lv.addWidget(tagbox)
        tagbox.hide()  # tagging manuale tolto su richiesta
        self.tagbox = tagbox
        root.addWidget(left)

        # --- schede a destra
        self.tabs = QTabWidget()
        self.tabs.setMinimumWidth(380)
        root.addWidget(self.tabs)
        root.setStretchFactor(0, 3)
        root.setStretchFactor(1, 1)
        saved = self.settings.value("split_main")
        if saved:
            root.setSizes([int(x) for x in saved])
        else:
            root.setSizes([1040, 400])
        root.splitterMoved.connect(lambda *_: self.settings.setValue("split_main", root.sizes()))
        self.splitter = root

        # Eventi
        w = QWidget()
        v = QVBoxLayout(w)
        fl = QGridLayout()
        self.f_type = QComboBox()
        self.f_team = QComboBox()
        self.f_player = QComboBox()
        for cb in (self.f_type, self.f_team, self.f_player):
            cb.setFocusPolicy(Qt.NoFocus)
            cb.currentIndexChanged.connect(self.refresh_events)
        fl.addWidget(QLabel("Evento"), 0, 0)
        fl.addWidget(self.f_type, 0, 1)
        fl.addWidget(QLabel("Squadra"), 1, 0)
        fl.addWidget(self.f_team, 1, 1)
        fl.addWidget(QLabel("Giocatore"), 2, 0)
        fl.addWidget(self.f_player, 2, 1)
        v.addLayout(fl)
        self.ev_table = QTableWidget(0, 5)
        self.ev_table.setHorizontalHeaderLabels(["Tempo", "Evento", "Squadra", "Giocatore", "Nota"])
        self.ev_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.ev_table.verticalHeader().setVisible(False)
        self.ev_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ev_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ev_table.itemSelectionChanged.connect(self._on_event_selection)
        self.ev_table.cellDoubleClicked.connect(self._on_event_double)
        self.ev_table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.ev_table.customContextMenuRequested.connect(self._events_menu)
        v.addWidget(self.ev_table, 1)
        self.ev_count = QLabel()
        v.addWidget(self.ev_count)
        bh = QHBoxLayout()
        for text, fn in (("▶︎ Rivedi", self.play_selected), ("Modifica…", self.edit_selected_event),
                         ("Elimina", self.delete_selected_events)):
            b = QPushButton(text)
            b.setFocusPolicy(Qt.NoFocus)
            b.clicked.connect(fn)
            bh.addWidget(b)
        self.export_btn = QPushButton("Esporta ▾")
        self.export_btn.setFocusPolicy(Qt.NoFocus)
        bh.addWidget(self.export_btn)
        v.addLayout(bh)
        self._tab_eventi = w

        # Disegni
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(QLabel("Disegni sul video (clic per andare al momento, poi modifica):"))
        self.dr_list = QListWidget()
        self.dr_list.itemSelectionChanged.connect(self._on_drawing_list_sel)
        v.addWidget(self.dr_list, 2)
        from props import PropsPanel
        self.props = PropsPanel(self)
        v.addWidget(self.props, 5)
        self._tab_disegni = w
        g = QGridLayout()
        self.sel_kind_lab = QLabel("")
        self.sel_kind_lab.setWordWrap(True)
        g.addWidget(self.sel_kind_lab, 2, 0, 1, 3)
        self.sel_dur_lab = QLabel("Resta sul video per")
        g.addWidget(self.sel_dur_lab, 0, 0)
        self.sel_dur = QDoubleSpinBox()
        self.sel_dur.setRange(0.5, 600)
        self.sel_dur.setSuffix(" s")
        self.sel_dur.setDecimals(1)
        g.addWidget(self.sel_dur, 0, 1)
        self.sel_pause_lab = QLabel("Durata del fermo")
        g.addWidget(self.sel_pause_lab, 1, 0)
        self.sel_pause = QDoubleSpinBox()
        self.sel_pause.setRange(0, 60)
        self.sel_pause.setSuffix(" s")
        self.sel_pause.setDecimals(1)
        self.sel_pause.setSpecialValueText("—")
        self.sel_pause.setToolTip("Durata del fermo immagine in cui sta il disegno")
        g.addWidget(self.sel_pause, 1, 1)
        b = QPushButton("Applica")
        b.clicked.connect(self.apply_drawing_edit)
        g.addWidget(b, 0, 2, 2, 1)
        v.addLayout(g)
        bh = QHBoxLayout()
        b = QPushButton("Sposta qui (tempo attuale)")
        b.setToolTip("Fa partire il disegno selezionato dal momento attuale del video")
        b.clicked.connect(self.move_drawing_here)
        bh.addWidget(b)
        b = QPushButton("Elimina disegno")
        b.clicked.connect(self.delete_selected_drawing)
        bh.addWidget(b)
        v.addLayout(bh)
        self.tabs.addTab(w, "Disegni")
        self._build_prog_tab()

        # Statistiche
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(QLabel("Clicca un numero per vedere quegli eventi nella lista."))
        self.st_table = QTableWidget()
        self.st_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.st_table.cellClicked.connect(self._on_stat_click)
        v.addWidget(self.st_table, 1)
        b = QPushButton("Esporta statistiche in Excel…")
        b.clicked.connect(self.export_excel)
        v.addWidget(b)
        self._tab_stats = w

        # Campo
        w = QWidget()
        v = QVBoxLayout(w)
        self.field_info = QLabel()
        self.field_info.setWordWrap(True)
        v.addWidget(self.field_info)
        self.big_field = FieldWidget(interactive=True)
        self.big_field.clicked.connect(self.on_field_click)
        v.addWidget(self.big_field, 1)
        self.field_legend = QLabel()
        self.field_legend.setWordWrap(True)
        v.addWidget(self.field_legend)
        b = QPushButton("Esporta immagine del campo…")
        b.clicked.connect(self.export_field_png)
        v.addWidget(b)
        self._tab_campo = w
        self.statusBar().showMessage("Apri un video per iniziare (⌘O o trascinalo nella finestra).")

    def _build_menus(self):
        mb = self.menuBar()
        m = mb.addMenu("File")
        self._act(m, "I tuoi lavori (apri o nuovo)…", self.show_projects, QKeySequence("Ctrl+Shift+O"))
        self._act(m, "Aggiungi video al lavoro…", self.add_videos_to_project)
        m.addSeparator()
        self._act(m, "Apri video…", self.open_video_dialog, QKeySequence.Open)
        self._act(m, "Apri analisi salvata…", self.open_project_dialog)
        self._act(m, "Salva", self.save_project, QKeySequence.Save)
        self._act(m, "Ricomincia l'analisi da zero…", self.new_analysis)
        m.addSeparator()
        self._act(m, "Esci", self.close, QKeySequence.Quit)
        m = mb.addMenu("Modifica")
        self._act(m, "Annulla ultimo disegno", self.undo_last, QKeySequence.Undo)
        m.addSeparator()
        self._act(m, "Togli dal video il pezzo tra Inizio e Fine", self.cut_piece)
        self._act(m, "Rimetti tutti i pezzi tolti", self.restore_all_cuts)
        m = mb.addMenu("Esporta")
        self.export_menu = m
        self._act(m, "Pezzo di video (tra Inizio e Fine)…", self.export_piece)
        self._act(m, "Video intero senza i pezzi tolti…", self.export_without_cuts)
        self._act(m, "Foto del fotogramma attuale…", self.export_photo_current, QKeySequence("Ctrl+E"))
        m = mb.addMenu("Raccolta")
        self._act(m, "Aggiungi il pezzo (tra Inizio e Fine) alla raccolta", self.add_to_raccolta)
        self._act(m, "Apri la raccolta (ordina, titoli, esporta)…", self.open_raccolta)
        m = mb.addMenu("Campo")
        self._act(m, "Calibra il campo su questo fotogramma…", self.calibrate)
        self._act(m, "Elimina tutte le calibrazioni", self.clear_calibrations)
        m = mb.addMenu("Vista")
        self._act(m, "Schermo intero", self.toggle_focus, QKeySequence("Ctrl+F"))
        self._act(m, "Mostra/nascondi la linea del tempo", self.toggle_timeline, QKeySequence("Ctrl+L"))
        la = m.addAction("Lente d'ingrandimento quando scegli un giocatore")
        la.setCheckable(True)
        la.setChecked(self.settings.value("lens", True, type=bool))
        la.toggled.connect(self._set_lens)
        self._lens_act = la
        self.view.lens_on = la.isChecked()
        m = mb.addMenu("Aiuto")
        self._act(m, "💬 Segnala un errore, un miglioramento o un cambiamento…", self.open_report)
        self._upd_act = self._act(m, "Cerca aggiornamenti", lambda: self.check_updates(manual=True))
        self._act(m, "Novità di questa versione", lambda: self.show_whats_new(force=True))
        self._act(m, "Informazioni e licenze…", self.show_licenses)
        if licenza_needed():
            self._act(m, "Inserisci una nuova chiave…", self.enter_new_key)
        m.addSeparator()
        self._act(m, "Scorciatoie da tastiera", self.show_help)
        self._act(m, "Prova di riferimento per il tracciamento (clicca i giocatori giusti)…", self.start_reference)
        a = m.addAction("Registra immagini per l'assistenza (1 al secondo)")
        a.setCheckable(True)
        a.toggled.connect(lambda v: SNAP_ON.__setitem__(0, bool(v)))

    def enter_new_key(self):
        import licenza
        self.act('inserisci nuova chiave')
        ok, exp = licenza.check_key(licenza.saved_key()) if licenza.saved_key() else (False, "")
        info = ""
        if ok:
            info = (f"La tua chiave vale fino al {exp.strftime('%d/%m/%Y')}." if exp else
                    "La tua chiave vale senza scadenza.")
        elif exp:
            info = str(exp)
        licenza.key_dialog(self, info, "Inserisci una nuova chiave")

    def _license_ok(self):
        """Controlla la chiave; se non vale più salva il lavoro e chiude il programma (non si può annullare)."""
        import licenza
        if not licenza.needed():
            return True
        ok, why = licenza.check_key(licenza.saved_key())
        if ok:
            return True
        self.stop()
        saved = False
        if self._dirty and self.reader and self.project.path:
            self.save_project()
            saved = not self._dirty
        mb = QMessageBox(self)
        mb.setIcon(QMessageBox.Warning)
        mb.setWindowTitle("Rifine Tactics")
        mb.setText(str(why))
        mb.setInformativeText(("Il lavoro è stato salvato. " if saved else "") +
                              "Il programma si chiude. Se hai già una chiave nuova, inseriscila adesso.")
        b_key = mb.addButton("Inserisci la chiave nuova", QMessageBox.AcceptRole)
        mb.addButton("Chiudi il programma", QMessageBox.RejectRole)
        mb.exec()
        if mb.clickedButton() == b_key and licenza.key_dialog(self, str(why), "Inserisci una nuova chiave"):
            return True
        _quit_now(0)
        return False

    def show_licenses(self):
        from PySide6.QtWidgets import QDialog
        import aggiorna
        here = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
        try:
            with open(os.path.join(here, "LICENZE.txt"), encoding="utf-8") as f:
                txt = f.read()
        except OSError:
            txt = "File delle licenze non trovato."
        dlg = QDialog(self)
        dlg.setWindowTitle("Informazioni e licenze")
        dlg.resize(720, 560)
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel(f"<b style='font-size:15px'>{APP_NAME}</b> · versione {aggiorna.current_version()}"))
        te = QTextEdit()
        te.setReadOnly(True)
        te.setPlainText(txt)
        v.addWidget(te, 1)
        b = QPushButton("Chiudi")
        b.clicked.connect(dlg.accept)
        v.addWidget(b)
        dlg.exec()

    def open_report(self, kind=0, text=""):
        import segnala
        r = segnala.dialog(self, kind, text, self.settings.value("tester_name", "", type=str))
        if r and r[0] and r[0] != "(senza nome)":
            self.settings.setValue("tester_name", r[0])

    def show_whats_new(self, force=False):
        """Al primo avvio di una versione nuova mostra cosa è cambiato (una volta sola); dal menù Aiuto sempre."""
        import aggiorna
        ver = aggiorna.current_version()
        note = aggiorna.current_note()
        if not force and (not note or self.settings.value("novita_viste", "") == ver):
            return
        self.settings.setValue("novita_viste", ver)
        QMessageBox.information(self, "Novità", f"Versione {ver}\n\n" + (note or "Nessuna nota per questa versione."))

    def check_updates(self, manual=False, quiet=False):
        """Cerca un aggiornamento in un thread. All'avvio (o a richiesta) lo propone con una finestra;
        a programma aperto (quiet) mostra solo un avviso discreto in basso, per non interrompere il lavoro."""
        import threading
        import aggiorna
        if not paths.FROZEN and not manual:
            return
        box = {}

        def work():
            box["info"] = aggiorna.check()
            box["done"] = True
        th = threading.Thread(target=work, daemon=True)
        th.start()

        def poll():
            if not box.get("done"):
                QTimer.singleShot(400, poll)
                return
            info = box.get("info")
            if not info:
                if manual:
                    QMessageBox.information(self, "Aggiornamenti", f"Il programma è aggiornato (versione {aggiorna.current_version()}).")
                return
            if info["version"] == getattr(self, "_upd_installed", None):
                return   # già scaricato: serve solo riaprire il programma
            self._upd_info = info
            self._show_update_badge(info)
            if not quiet:
                self._offer_update(info)
        poll()

    def _show_update_badge(self, info):
        """Avviso discreto: scritta in basso e voce evidenziata nel menu Aiuto."""
        b = getattr(self, "_upd_badge", None)
        if b is None:
            b = QPushButton()
            b.setFlat(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("QPushButton { color: #8fd19e; font-weight: 600; padding: 0 8px; border: none; }"
                            "QPushButton:hover { text-decoration: underline; }")
            b.clicked.connect(lambda: self._offer_update(getattr(self, "_upd_info", None)))
            self.statusBar().addPermanentWidget(b)
            self._upd_badge = b
        b.setText(f"⬆ Aggiornamento disponibile ({info['version']}): clicca per vedere")
        b.show()
        if getattr(self, "_upd_act", None) is not None:
            self._upd_act.setText("⬆ Aggiornamento disponibile…")

    def _hide_update_badge(self, text=None):
        b = getattr(self, "_upd_badge", None)
        if b is not None:
            if text:
                b.setText(text)
                b.setEnabled(False)
            else:
                b.hide()
        if getattr(self, "_upd_act", None) is not None:
            self._upd_act.setText("Cerca aggiornamenti")

    def _offer_update(self, info):
        import aggiorna
        if not info:
            self.check_updates(manual=True)
            return
        self.act(f"proposta aggiornamento {info['version']}")
        mb = QMessageBox(self)
        mb.setWindowTitle("Aggiornamento disponibile")
        mb.setText(f"C'è una versione nuova: {info['version']} (adesso hai la {aggiorna.current_version()}).")
        note = str(info.get("note") or "").strip()
        mb.setInformativeText(("Cosa cambia:\n" + note) if note else "Nessuna descrizione delle novità.")
        yes = mb.addButton("Aggiorna ora", QMessageBox.AcceptRole)
        mb.addButton("Più tardi", QMessageBox.RejectRole)
        mb.exec()
        if mb.clickedButton() != yes:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        ok, why = aggiorna.install(info)
        QApplication.restoreOverrideCursor()
        if ok:
            self._upd_installed = info["version"]
            self._hide_update_badge("✓ Aggiornamento pronto: chiudi e riapri il programma")
            QMessageBox.information(self, "Aggiornamenti", "Fatto. Chiudi il programma e riaprilo per usare la versione nuova.")
        else:
            QMessageBox.warning(self, "Aggiornamenti", why)

    def _clone_menu(self, src):
        menu = QMenu(self)
        for a in src.actions():
            if a.isSeparator():
                menu.addSeparator()
            else:
                na = menu.addAction(a.text())
                na.triggered.connect(a.trigger)
        return menu

    def _act(self, menu, text, fn, shortcut=None):
        a = QAction(text, self)
        if shortcut is not None:
            a.setShortcut(shortcut)
        a.triggered.connect(fn)
        menu.addAction(a)
        return a

    # ================= stato / refresh =================
    @property
    def t(self):
        return self.reader.time_for_idx(self.idx) if self.reader else 0.0

    def mark_dirty(self):
        if not self._dirty:
            self._dirty = True
            self._update_title()

    def _update_title(self):
        name = os.path.basename(self.reader.path) if self.reader else ""
        star = " • modifiche non salvate" if self._dirty and self.reader else ""
        parts = [APP_NAME] + ([self.prog.name] if self.prog else []) + ([name] if name else [])
        self.setWindowTitle(" — ".join(parts) + star)

    def maybe_save(self):
        """Chiede se salvare le modifiche. Ritorna False se l'utente annulla."""
        if not self._dirty or not self.reader:
            return True
        self.stop()
        mb = QMessageBox(self)
        mb.setIcon(QMessageBox.Question)
        mb.setWindowTitle("Salvare le modifiche?")
        mb.setText(f"Vuoi salvare le modifiche all'analisi di «{os.path.basename(self.reader.path)}»?")
        mb.setInformativeText("Se non salvi, la prossima volta ritrovi l'analisi com'era all'ultimo salvataggio.")
        b_save = mb.addButton("Salva", QMessageBox.AcceptRole)
        b_no = mb.addButton("Non salvare", QMessageBox.DestructiveRole)
        mb.addButton("Annulla", QMessageBox.RejectRole)
        mb.setDefaultButton(b_save)
        mb.exec()
        if mb.clickedButton() == b_save:
            self.save_project()
            return not self._dirty
        if mb.clickedButton() == b_no:
            self._dirty = False
            return True
        return False

    def new_analysis(self):
        """Ricomincia l'analisi di questo video da zero (eventi, disegni, giocatori seguiti, calibrazione)."""
        if not self.reader:
            return
        r = QMessageBox.question(self, "Ricomincia da zero",
                                 "Togliere tutti gli eventi, i disegni, i giocatori seguiti e la calibrazione di "
                                 "questo video?\nIl file salvato cambia solo se poi salvi.")
        if r != QMessageBox.Yes:
            return
        self._who_queue = []
        self.view.pick = None
        for tid in list(self._followers):
            self._stop_follow(tid)
        p = self.project
        p.events, p.drawings, p.tracks, p.calibrations, p.pitch_refs = [], [], {}, [], {}
        self.scene.invalidate()
        self.undo = []
        self.mark_dirty()
        self.refresh_all()
        self._update_calib_label()
        self.show_idx(self.idx)

    def refresh_all(self):
        self.refresh_tag_panel()
        self.refresh_filters()
        self.refresh_events()
        self.refresh_drawings()
        self.refresh_stats()
        self.refresh_fields()

    def refresh_tag_panel(self):
        while self.tag_grid.count():
            it = self.tag_grid.takeAt(0)
            wdg = it.widget()
            if wdg is not None:
                wdg.hide()
                wdg.setParent(None)
                wdg.deleteLater()
        cols = 4
        for i, et in enumerate(self.project.event_types):
            b = QPushButton(f"{et['name']}" + (f"  [{et['key']}]" if et.get("key") else ""))
            b.setFocusPolicy(Qt.NoFocus)
            b.setMinimumHeight(34)
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            c = QColor(et["color"])
            fg = "#111" if c.lightnessF() > 0.6 else "#fff"
            b.setStyleSheet(f"QPushButton{{background:{et['color']}; color:{fg}; font-weight:600; border-radius:6px;"
                            f" border:1px solid rgba(0,0,0,0.35); padding:4px 6px;}}"
                            f"QPushButton:pressed{{background:{c.darker(130).name()};}}")
            b.clicked.connect(lambda _=False, n=et["name"]: self.tag(n))
            self.tag_grid.addWidget(b, i // cols, i % cols)
        self.team_btns["home"].setText(self.project.teams["home"])
        self.team_btns["away"].setText(self.project.teams["away"])
        self.player_cb.clear()
        self.player_cb.addItem("— nessun giocatore —", None)
        for p in sorted(self.project.roster, key=lambda x: int(x["num"])):
            self.player_cb.addItem(f"#{p['num']} {p['name']}", int(p["num"]))

    def refresh_filters(self):
        for cb in (self.f_type, self.f_team, self.f_player):
            cb.blockSignals(True)
        cur = (self.f_type.currentData(), self.f_team.currentData(), self.f_player.currentData())
        self.f_type.clear()
        self.f_type.addItem("Tutti", None)
        names = [et["name"] for et in self.project.event_types]
        names += sorted({e["type"] for e in self.project.events} - set(names))
        for n in names:
            self.f_type.addItem(n, n)
        self.f_team.clear()
        self.f_team.addItem("Tutte", None)
        self.f_team.addItem(self.project.teams["home"], "home")
        self.f_team.addItem(self.project.teams["away"], "away")
        self.f_player.clear()
        self.f_player.addItem("Tutti", None)
        self.f_player.addItem("— senza giocatore —", -1)
        nums = sorted({int(p["num"]) for p in self.project.roster} |
                      {int(e["player"]) for e in self.project.events if e.get("player") is not None})
        for n in nums:
            self.f_player.addItem(self.project.player_label(n), n)
        for cb, val in zip((self.f_type, self.f_team, self.f_player), cur):
            i = cb.findData(val)
            cb.setCurrentIndex(max(0, i))
            cb.blockSignals(False)

    def filtered_events(self):
        ft, fteam, fp = self.f_type.currentData(), self.f_team.currentData(), self.f_player.currentData()
        out = []
        for e in self.project.events:
            if ft and e["type"] != ft:
                continue
            if fteam and e["team"] != fteam:
                continue
            if fp is not None:
                if fp == -1 and e.get("player") is not None:
                    continue
                if fp != -1 and (e.get("player") is None or int(e["player"]) != fp):
                    continue
            out.append(e)
        return out

    def refresh_events(self):
        sel = set(self.selected_event_ids())
        evs = self.filtered_events()
        self.ev_table.blockSignals(True)
        self.ev_table.setRowCount(len(evs))
        for r, e in enumerate(evs):
            it = QTableWidgetItem(fmt_time(e["t"]) + (" 📍" if e.get("pos") else ""))
            it.setData(Qt.UserRole, e["id"])
            self.ev_table.setItem(r, 0, it)
            ti = QTableWidgetItem(e["type"])
            pm = QPixmap(10, 10)
            pm.fill(QColor(self.project.color_for(e["type"])))
            ti.setIcon(QIcon(pm))
            self.ev_table.setItem(r, 1, ti)
            self.ev_table.setItem(r, 2, QTableWidgetItem(self.project.teams.get(e["team"], "")))
            self.ev_table.setItem(r, 3, QTableWidgetItem(self.project.player_label(e.get("player"))))
            self.ev_table.setItem(r, 4, QTableWidgetItem(e.get("note", "")))
        self.ev_table.resizeColumnsToContents()
        self.ev_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        for r in range(len(evs)):
            if evs[r]["id"] in sel:
                self.ev_table.selectRow(r) if len(sel) == 1 else self._add_row_selection(r)
        self.ev_table.blockSignals(False)
        tot = len(self.project.events)
        self.ev_count.setText(f"{len(evs)} eventi mostrati" + (f" (su {tot})" if len(evs) != tot else ""))
        self.timeline.events = self.project.events
        self.timeline.colors = {et["name"]: et["color"] for et in self.project.event_types}
        self.timeline.selected = sel
        self.timeline.update()
        self.refresh_fields()

    def _add_row_selection(self, r):
        from PySide6.QtCore import QItemSelectionModel
        idx = self.ev_table.model().index(r, 0)
        self.ev_table.selectionModel().select(idx, QItemSelectionModel.Select | QItemSelectionModel.Rows)

    def selected_event_ids(self):
        ids = []
        for r in sorted({i.row() for i in self.ev_table.selectedIndexes()}):
            it = self.ev_table.item(r, 0)
            if it:
                ids.append(it.data(Qt.UserRole))
        return ids

    def selected_events(self):
        return [e for e in (self.project.event(i) for i in self.selected_event_ids()) if e]

    def refresh_drawings(self):
        # un disegno che parte proprio su un fermo immagine si vede subito pieno nel fermo (niente dissolvenza:
        # nel fermo il tempo è fermo e resterebbe quasi trasparente)
        for d in self.project.drawings:
            if not d.get("freeze"):
                st = self.project.still_at(d["t"], 0.05) if self.project.stills else None
                if st:
                    d["no_fade"] = True
                elif d.get("no_fade"):
                    d.pop("no_fade", None)
        self.view.drawings = self.project.drawings
        self.timeline.project = self.project
        self.timeline.drawings = self.project.drawings
        self.timeline.selected_id = self.view.selected_id
        self.timeline.update()
        self.view.update()
        cur = self.view.selected_id
        self.dr_list.blockSignals(True)
        self.dr_list.clear()
        for d in self.project.drawings:
            txt = f"{fmt_time(d['t'], True)}   {DRAWING_KINDS.get(d['kind'], d['kind'])}"
            if d["kind"] == "testo":
                txt += f" «{d.get('text', '')}»"
            if d.get("freeze"):
                st = self.project.still_at(d["t"], 0.002)
                txt += f"   ⏸ nel fermo immagine" + (f" {st['dur']:g}s" if st else "")
            else:
                txt += f"   ({d['dur']:g}s)"
            kinds = {a["type"] for a in (d.get("anchors") or []) if a}
            if "track" in kinds:
                txt += "  👣 segue giocatore"
            elif "field" in kinds:
                txt += "  📌 campo"
            it = QListWidgetItem(txt)
            pm = QPixmap(12, 12)
            pm.fill(QColor(d.get("color", "#ffeb3b")))
            it.setIcon(QIcon(pm))
            it.setData(Qt.UserRole, d["id"])
            self.dr_list.addItem(it)
            if d["id"] == cur:
                it.setSelected(True)
        self.dr_list.blockSignals(False)
        if hasattr(self, "props"):
            dcur = self.project.drawing(cur) if cur else None
            self.props.set_drawing(dcur)
            if dcur is not None and hasattr(self, "sel_dur"):
                self._fill_sel(dcur)
        if getattr(self, "_tab_prog", None) is not None and self.tabs.currentWidget() is self._tab_prog \
                and self._sel_is_open():
            self._refresh_prog_detail()

    def refresh_stats(self):
        rows, cols, counts = self.project.stats_matrix()
        self._stat_rows, self._stat_cols = rows, cols
        self.st_table.clear()
        self.st_table.setRowCount(len(rows))
        self.st_table.setColumnCount(len(cols) + 1)
        self.st_table.setHorizontalHeaderLabels(cols + ["Totale"])
        self.st_table.setVerticalHeaderLabels([self.project.row_label(r) for r in rows])
        for i, r in enumerate(rows):
            tot = 0
            for j, c in enumerate(cols):
                k = counts[(r, c)]
                tot += k
                it = QTableWidgetItem(str(k) if k else "·")
                it.setTextAlignment(Qt.AlignCenter)
                if r[1] == "TOT":
                    f = it.font()
                    f.setBold(True)
                    it.setFont(f)
                    it.setBackground(QColor("#2a3342"))
                self.st_table.setItem(i, j, it)
            it = QTableWidgetItem(str(tot))
            it.setTextAlignment(Qt.AlignCenter)
            f = it.font()
            f.setBold(True)
            it.setFont(f)
            self.st_table.setItem(i, len(cols), it)
        self.st_table.resizeColumnsToContents()

    def refresh_fields(self):
        if not hasattr(self, "big_field"):
            return
        evs = self.filtered_events()
        selected = set(self.selected_event_ids())
        pts = []
        for e in evs:
            if e.get("pos"):
                lbl = f"{e['player']}" if e.get("player") is not None else ""
                pts.append((e["pos"][0], e["pos"][1], self.project.color_for(e["type"]), lbl, e["id"] in selected))
        self.big_field.points = pts
        self.big_field.update()
        recent = [e for e in self.project.events if e.get("pos")][-12:]
        self.mini_field.points = [(e["pos"][0], e["pos"][1], self.project.color_for(e["type"]), "",
                                   e["id"] in selected) for e in recent]
        self.mini_field.update()
        with_pos = sum(1 for e in evs if e.get("pos"))
        self.field_info.setText(f"Posizioni degli eventi filtrati nella scheda «Eventi»: {with_pos} su {len(evs)} "
                                f"hanno una posizione. Clicca sul campo per assegnare la posizione all'evento "
                                f"selezionato.")
        types = sorted({e["type"] for e in evs if e.get("pos")})
        self.field_legend.setText("   ".join(
            f"<span style='color:{self.project.color_for(t)}'>●</span> {t}" for t in types))

    # ================= video =================
    def open_video_dialog(self):
        if self.prog:
            self.add_videos_to_project()
            return
        d = self.settings.value("last_dir", os.path.expanduser("~/Movies"))
        path, _ = QFileDialog.getOpenFileName(self, "Apri video", d, VIDEO_FILTER + ";;Tutti i file (*)")
        if path:
            self.open_path(path)

    def open_project_dialog(self):
        d = self.settings.value("last_dir", os.path.expanduser("~"))
        path, _ = QFileDialog.getOpenFileName(self, "Apri analisi", d, "Analisi (*.analisi.json *.json)")
        if path:
            self.open_path(path)

    def open_path(self, path, analysis_path=None):
        if not self._license_ok():
            return
        if not path:
            return
        if self.prog and analysis_path is None and not path.lower().endswith(".json"):
            e = self.prog.find(path) or self.prog.add(path)
            self.open_entry(e)
            return
        if not self.maybe_save():
            return
        if path.lower().endswith(".json"):
            try:
                proj = Project.load(path)
            except Exception as e:
                QMessageBox.critical(self, "Errore", f"Impossibile leggere il file:\n{e}")
                return
            vp = proj.video_path
            if not vp or not os.path.exists(vp):
                cand = os.path.join(os.path.dirname(path), os.path.basename(vp or ""))
                if vp and os.path.exists(cand):
                    vp = cand
                else:
                    QMessageBox.information(self, "Video non trovato",
                                            "Il video di questa analisi è stato spostato. Indica dove si trova.")
                    vp, _ = QFileDialog.getOpenFileName(self, "Dov'è il video?", os.path.dirname(path), VIDEO_FILTER)
                    if not vp:
                        return
                proj.video_path = vp
            self._load_video(vp, proj)
            return
        self.settings.setValue("last_dir", os.path.dirname(path))
        proj = None
        if analysis_path and os.path.exists(analysis_path):
            try:
                proj = Project.load(analysis_path)
                proj.video_path = path
                proj.path = analysis_path
            except Exception as e:
                QMessageBox.warning(self, "Analisi", f"Non riesco a leggere l'analisi salvata di questo video:\n{e}")
                proj = None
            if proj is not None:
                self._load_video(path, proj)
                return
        pp = project_path_for_video(path)          # vecchio posto: accanto al video (solo per ritrovarle)
        alt = self._central_path(path)
        old_alt = os.path.join(os.path.expanduser("~/Documents"), "Analisi Video",
                               os.path.splitext(os.path.basename(path))[0] + ".analisi.json")
        legacy = None
        for cand in (alt, old_alt, pp):
            if os.path.exists(cand):
                if cand != alt:
                    legacy = cand
                try:
                    proj = Project.load(cand)
                    proj.video_path = path
                    break
                except Exception:
                    proj = None
                    legacy = None
        if proj is not None and not (proj.events or proj.drawings or proj.calibrations):
            legacy = None
        if proj is not None and (proj.events or proj.drawings or proj.calibrations):
            mb = QMessageBox(self)
            mb.setWindowTitle("Analisi già salvata")
            mb.setText(f"Per questo video c'è un'analisi salvata ({len(proj.events)} eventi, "
                       f"{len(proj.drawings)} disegni, {len(proj.calibrations)} calibrazioni).")
            b_keep = mb.addButton("Riprendila", QMessageBox.AcceptRole)
            b_new = mb.addButton("Ricomincia da zero", QMessageBox.DestructiveRole)
            b_keep_cal = mb.addButton("Tieni solo la calibrazione", QMessageBox.ActionRole)
            mb.setDefaultButton(b_keep)
            mb.exec()
            if analysis_path:
                proj.path = analysis_path  # l'analisi vecchia resta com'è: si salva dentro il lavoro
            if mb.clickedButton() == b_new:
                keep_path = proj.path
                proj = Project.from_dict({"video_path": path, "teams": proj.teams, "roster": proj.roster,
                                          "event_types": proj.event_types})
                proj.path = keep_path
            elif mb.clickedButton() == b_keep_cal:
                keep_path = proj.path
                proj = Project.from_dict({"video_path": path, "teams": proj.teams, "roster": proj.roster,
                                          "event_types": proj.event_types, "calibrations": proj.calibrations,
                                          "camera": proj.camera, "pitch": proj.pitch, "pitch_refs": proj.pitch_refs})
                proj.path = keep_path
        if proj is not None and analysis_path:
            proj.path = analysis_path
        if proj is None:
            proj = Project()
            proj.video_path = path
            proj.apply_panel(self._last_panel or {})
            proj.path = analysis_path or alt
        elif not analysis_path:
            proj.path = alt          # da ora l'analisi si salva sempre nella cartella centrale
        self._load_video(path, proj)
        if legacy and not analysis_path and os.path.exists(legacy):
            self._offer_move_legacy(legacy, alt)

    def _offer_move_legacy(self, legacy, alt):
        """Un'analisi vecchia stava accanto al video: la sposta nella cartella centrale, chiedendo prima."""
        if os.path.abspath(legacy) == os.path.abspath(alt):
            return
        mb = QMessageBox(self)
        mb.setWindowTitle("Ordine dei file")
        mb.setText("L'analisi di questo video stava accanto al video:\n" + legacy +
                   "\n\nVuoi spostarla nella cartella unica «Documenti ▸ Analisi Video ▸ Analisi»?\n"
                   "(Il video non viene toccato.)")
        yes = mb.addButton("Sposta", QMessageBox.AcceptRole)
        mb.addButton("Lascia dov'è", QMessageBox.RejectRole)
        mb.exec()
        if mb.clickedButton() != yes:
            return
        try:
            self.save_project()
            if os.path.exists(alt):
                os.replace(legacy, legacy + ".vecchia")
            else:
                os.remove(legacy)
            self.statusBar().showMessage("Analisi spostata in Documenti ▸ Analisi Video ▸ Analisi", 6000)
        except OSError as e:
            QMessageBox.warning(self, "Ordine dei file", f"Non sono riuscito a spostarla:\n{e}")

    def _central_dir(self):
        d = os.path.join(os.path.expanduser("~/Documents"), "Analisi Video", "Analisi")
        os.makedirs(d, exist_ok=True)
        return d

    def _central_path(self, video_path):
        """Dove vive l'analisi di un video aperto fuori da un lavoro: sempre nella cartella
        Documenti/Analisi Video/Analisi, mai accanto al video."""
        import hashlib
        h = hashlib.md5(os.path.abspath(video_path).encode()).hexdigest()[:6]
        name = os.path.splitext(os.path.basename(video_path))[0]
        return os.path.join(self._central_dir(), f"{name}-{h}.analisi.json")

    def _fallback_project_path(self, video_path):
        return self._central_path(video_path)

    def _load_video(self, path, proj):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            reader = VideoReader(path)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Video non apribile", str(e))
            return
        QApplication.restoreOverrideCursor()
        self.stop()
        if self.reader:
            self.reader.close()
        if self._pf:
            self._pf.close()
            self._pf = None
        self.reader = reader
        self.audio.load(path)
        self.project = proj
        self.piece_in = self.piece_out = None
        self._who_queue = []
        self.view.pick = None
        for tid in list(self._followers):
            self._stop_follow(tid)
        self.scene = Scene(proj, reader.fps, video_path=path)
        self.scene.aspect = reader.width / max(1, reader.height)
        self.view.resolver = self.scene.resolve
        if self.lines_chk.isChecked():
            self._toggle_lines(True)
        self.undo = []
        self.pending_pos = None
        self.playlist = None
        self.timeline.project = proj
        self.timeline.duration = reader.duration
        self.timeline.fit()
        self._update_piece()
        self._refresh_cuts()
        self._dirty = False
        self._update_title()
        self.view.placeholder = ""
        self.refresh_all()
        self._update_calib_label()
        self.show_idx(0)
        self.statusBar().showMessage(
            f"{os.path.basename(path)} · {reader.width}×{reader.height} · {reader.fps:.2f} fps · "
            f"{fmt_time(reader.duration)}  —  ⌘S per salvare l'analisi", 15000)

    def _pf_size(self):
        r = self.view.video_rect()
        dpr = self.view.devicePixelRatioF()
        return (max(2, int(r.width() * dpr)), max(2, int(r.height() * dpr)))

    def _pf_step(self):
        return max(1, int(round(self.speed))) if self.speed > 1.5 else 1

    def show_idx(self, idx):
        if not self.reader:
            return
        self.idx = max(0, min(self.reader.frame_count - 1, int(idx)))
        t = self.t
        self.view.t = t
        self.view.idx = self.idx
        if not getattr(self, "_hold", None):
            self.view.hold_ids = set()
        t0 = time.perf_counter()
        fr = self.reader.frame(self.idx)
        t1 = time.perf_counter()
        self.view.set_frame(fr, (self.reader.width, self.reader.height))
        self._maybe_anchor(fr)
        if self.playing:
            self.perf.add("lettura video", t1 - t0)
            self.perf.add("preparazione immagine", time.perf_counter() - t1)
        self._set_tl_time(self.project.out_time(t))
        if self.project.cuts:
            self._cut_hint()
        self._update_still_badge()
        if self._who_queue:
            self._maybe_ask_who()

    # ---------- campo ri-agganciato alle linee dipinte (contro lo "scivolamento") ----------
    ANCHOR_EVERY = 25

    def _maybe_anchor(self, fr):
        """Ogni mezzo secondo circa, in sottofondo, riallinea il campo calcolato alle linee bianche vere."""
        self._anchor_poll()
        if fr is None or not self.project.calibrations or not hasattr(self, "scene"):
            return
        fut = getattr(self, "_anchor_fut", None)
        if fut is not None:
            return
        idx = self.idx
        last = getattr(self, "_anchor_last", None)
        if last is not None and last[0] == self.reader.path and abs(idx - last[1]) < self.ANCHOR_EVERY:
            return
        refs = [int(c["idx"]) for c in self.project.calibrations] + [int(k) for k in self.project.pitch_refs]
        if any(abs(idx - f) < self.ANCHOR_EVERY // 2 for f in refs):
            self._anchor_last = (self.reader.path, idx)
            return
        H = self.scene.pitch_H(idx)
        if H is None:
            return
        self._anchor_last = (self.reader.path, idx)
        lines = pitch_lines(self.scene.pitch_spec(idx))
        if getattr(self, "_anchor_pool", None) is None:
            # in un processo a parte: il calcolo non rallenta la riproduzione
            import multiprocessing as mp
            from concurrent.futures import ProcessPoolExecutor
            try:
                self._anchor_pool = ProcessPoolExecutor(max_workers=1, mp_context=mp.get_context("spawn"))
            except Exception:
                from concurrent.futures import ThreadPoolExecutor
                self._anchor_pool = ThreadPoolExecutor(max_workers=1)
            self._anchor_timer = QTimer(self)
            self._anchor_timer.timeout.connect(self._anchor_poll)
            self._anchor_timer.start(200)
        import calib_math as CM
        self._anchor_fut = (self.reader.path, idx, self._anchor_pool.submit(CM.refine_homography, H, fr.copy(), lines))

    def _anchor_poll(self):
        job = getattr(self, "_anchor_fut", None)
        if job is None or not job[2].done():
            return
        self._anchor_fut = None
        path, idx, fut = job
        try:
            Hn, before, after = fut.result()
        except Exception:
            return
        self.perf.count("campo: controlli sulle linee")
        if Hn is not None and self.reader and self.reader.path == path and hasattr(self, "scene"):
            self.perf.count("campo: riagganciato alle linee")
            self.scene.add_anchor(idx, Hn)
            if self.view.lines_fn is not None:
                self.view.update()

    def _set_tl_time(self, to):
        self.timeline.t = to
        self.timeline.follow_cursor()
        self.timeline.update()
        tot = self.reader.duration + self.project.stills_total() if self.reader else 0
        self.time_lbl.setText(f"{fmt_time(to, True)} / {fmt_time(tot)}")

    def _still_here(self):
        if not self.reader:
            return None
        return self.project.still_at(self.t, 0.5 / self.reader.fps + 1e-3)

    def _update_still_badge(self):
        s = self._still_here()
        if hasattr(self, "mode_help"):
            if s and not self.playing:
                self.mode_help.setText(f"⏸ Sei in un FERMO IMMAGINE di {s['dur']:g} s: quello che disegni ora si vede "
                                       "solo durante il fermo.")
                self.mode_help.setStyleSheet("color:#ff9100; font-weight:bold")
                self.dur_sp.setVisible(False)
            else:
                self.mode_help.setText("▶ Video che scorre: quello che disegni resta sul video per")
                self.mode_help.setStyleSheet("color:#c9d1dc")
                self.dur_sp.setVisible(True)
        if s and not self.playing:
            n = len(self.project.still_drawings(s))
            self.view.mode_badge = (f"⏸ FERMO IMMAGINE {s['dur']:g} s — quello che disegni qui sta nel fermo"
                                    + (f" ({n})" if n else ""), "#ff9100")
        else:
            self.view.mode_badge = None
        self.view.update()

    def act(self, text):
        """Registro delle azioni: ora, video e secondo del video, così si può rivedere cosa è stato fatto e dove."""
        try:
            if os.path.exists(ACT_PATH) and os.path.getsize(ACT_PATH) > 600_000:
                os.replace(ACT_PATH, ACT_PATH + ".vecchio")
            name = os.path.basename(self.reader.path) if self.reader else "-"
            t = f"{self.t:.2f}" if self.reader else "-"
            with open(ACT_PATH, "a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%d/%m %H:%M:%S')} | {name} | video {t} s | {text}\n")
        except Exception:
            pass

    def seek_time(self, t, keep_playlist=False):
        if not self.reader:
            return
        if not keep_playlist:
            self.playlist = None
        self._paused_done = {i for i in self._paused_done if self.project.still(i) and self.project.still(i)["t"] < t}
        self._hold = None
        self._hold_until = 0
        self.view.overlay_hint = ""
        self.show_idx(self.reader.idx_for_time(max(0.0, t)))
        if self.playing:
            self._rebase()
            self.audio.play_at(self.t, self.speed)

    def seek_out(self, to):
        """Clic sulla linea del tempo (tempo montato, con i fermi immagine)."""
        if not self.reader:
            return
        ts, st, el = self.project.src_time(max(0.0, to))
        self.seek_time(ts)
        if st is not None:
            if self.playing and self.pause_chk.isChecked():
                self._start_hold(st, el)
            else:
                self._set_tl_time(to)

    def _start_hold(self, st, elapsed=0.0):
        now = time.perf_counter()
        self._paused_done.add(st["id"])
        self.show_idx(self.reader.idx_for_time(st["t"]))
        self.view.hold_ids = {d["id"] for d in self.project.still_drawings(st)}
        self._hold = (st, now - elapsed)
        self.audio.pause()
        self._hold_until = now + max(0.05, st["dur"] - elapsed)
        self.view.overlay_hint = f"⏸ fermo immagine {st['dur']:g} s"
        self.view.mode_badge = None
        self.view.update()

    def step(self, n):
        if not self.reader:
            return
        self.stop()
        self.show_idx(self.idx + n)

    def toggle_play(self):
        self.act('stop' if self.playing else 'play')
        if self.playing:
            self.stop()
        else:
            self.play()

    def play(self):
        if not self.reader:
            return
        if self.idx >= self.reader.frame_count - 1:
            self.show_idx(0)
        self.playing = True
        self.play_btn.setText("⏸")
        self._hold_until = 0
        self._rebase()
        self.audio.play_at(self.t, self.speed)
        # parti proprio da un fermo immagine: resta fermo con i disegni, poi riparte
        st = self._still_here()
        if st and self.pause_chk.isChecked():
            to = self.timeline.t
            el = min(max(0.0, to - self.project.out_time(st["t"])), st["dur"] - 0.05)
            self._start_hold(st, el if el < st["dur"] - 0.1 else 0.0)
        self.view.mode_badge = None
        self.play_timer.start()

    def stop(self):
        was = self.playing
        self.playing = False
        self.play_btn.setText("▶︎")
        self.play_timer.stop()
        self.audio.pause()
        self.perf.flush()
        self._hold_until = 0
        self._hold = None
        self.view.hold_ids = set()
        self.view.overlay_hint = ""
        self._update_still_badge()

    def set_speed(self, s):
        self.speed = float(s)
        self.audio.set_rate(self.speed)
        if self.playing:
            self._rebase()

    def set_muted(self, m):
        self.audio.set_muted(m)
        self.mute_btn.setText("🔇" if m else "🔊")
        self.settings.setValue("audio_muted", bool(m))

    def _on_pause_toggle(self, v):
        self.view.use_pause = v
        self.view.update()

    def _rebase(self):
        self._base_idx = self.idx
        self._base_time = time.perf_counter()
        self._last_show_t = self._base_time

    def _tick(self):
        if not self.reader or not self.playing:
            return
        now = time.perf_counter()
        if self._hold_until:
            if now < self._hold_until:
                if self._hold and now - getattr(self, "_last_hold_draw", 0) > 0.04:
                    self._last_hold_draw = now
                    st, t0 = self._hold
                    self._set_tl_time(self.project.out_time(st["t"]) + (now - t0))
                return
            self._hold_until = 0
            self._hold = None
            self.view.hold_ids = set()
            self.view.overlay_hint = ""
            self._rebase()
            self.audio.play_at(self.t, self.speed)
        target = self._base_idx + int((now - self._base_time) * self.reader.fps * self.speed)
        self.perf.tick(self)
        if now - getattr(self, "_last_snap", 0) > 1.0:
            self._last_snap = now
            save_snap(self.view, f"f{self.idx}" + ("_segue" if self._followers else ""))
        if now - getattr(self, "_last_async", 0) > 0.3:
            self._last_async = now
            if self._waiting:
                self.audio.pause()
            else:
                self.audio.keep(self.t, self.speed)
        lim = self._follow_frontier()
        if lim is not None and target > lim:
            # il calcolo del giocatore seguito non è ancora arrivato qui: aspetta invece di perderlo
            target = lim
            self.perf.count("attese del calcolo giocatore")
            if not self._waiting:
                self._waiting = True
                self.view.overlay_hint = "👣 calcolo il giocatore…"
                self.view.update()
            if target <= self.idx:
                self._rebase()
                return
        elif self._waiting:
            self._waiting = False
            self.view.overlay_hint = ""
        if target <= self.idx:
            return
        prev_t = self.t
        new_t = self.reader.time_for_idx(target)
        # playlist: salto alla clip successiva
        if self.playlist:
            clips, i = self.playlist
            if new_t >= clips[i][1]:
                i += 1
                if i >= len(clips):
                    self.playlist = None
                    self.stop()
                    self.statusBar().showMessage("Fine della revisione", 3000)
                    return
                self.playlist = (clips, i)
                self.show_idx(self.reader.idx_for_time(clips[i][0]))
                self._rebase()
                return
        # fermi immagine
        if self.pause_chk.isChecked():
            for st in self.project.stills:
                if prev_t + 1e-6 < st["t"] <= new_t + 1e-6 and st["id"] not in self._paused_done:
                    self._start_hold(st)
                    return
        # pezzi tolti: salta oltre
        c = self.project.cut_at(new_t)
        if c:
            if c[1] >= self.reader.duration - 0.05:
                self.show_idx(self.reader.frame_count - 1)
                self.stop()
                return
            self.show_idx(self.reader.idx_for_time(c[1]))
            self._rebase()
            return
        if target >= self.reader.frame_count - 1:
            self.show_idx(self.reader.frame_count - 1)
            self.stop()
            return
        self.show_idx(target)

    # ================= tagging =================
    def set_team(self, team):
        self.team = team
        self.team_btns[team].setChecked(True)
        self._update_player_label()

    def set_player(self, num):
        self.player = num
        self._update_player_label()

    def _player_from_combo(self, i):
        self.set_player(self.player_cb.itemData(i))

    def _update_player_label(self):
        tn = self.project.teams.get(self.team, "")
        pl = self.project.player_label(self.player) if self.player is not None else "nessun giocatore"
        self.player_lbl.setText(f"<b>{tn}</b> · {pl}<br><span style='color:#8a93a3'>Tab = cambia squadra · "
                                f"numeri = giocatore · Esc = azzera</span>")
        i = self.player_cb.findData(self.player)
        self.player_cb.setCurrentIndex(i if i >= 0 else 0)

    def tag(self, type_name):
        self._digits = ""
        if not self.reader:
            self.statusBar().showMessage("Apri prima un video.", 3000)
            return
        ev = self.project.add_event(type_name, self.t, self.reader.duration, self.team, self.player)
        self.undo.append(("event", ev["id"]))
        txt = f"✓ {type_name} · {self.project.teams[self.team]}"
        if self.player is not None:
            txt += f" · {self.project.player_label(self.player)}"
        self.view.flash(txt, self.project.color_for(type_name))
        self.last_event_id = ev["id"]
        if self.askpos_chk.isChecked():
            self.pending_pos = ev["id"]
            self.mini_field.hint = "Clicca la posizione"
            self.mini_field.update()
        self.player = None
        self._update_player_label()
        self.mark_dirty()
        self.refresh_filters()
        self.refresh_events()
        self.refresh_stats()

    def on_field_click(self, x, y):
        target = None
        if self.pending_pos:
            target = self.project.event(self.pending_pos)
        if target is None:
            sel = self.selected_events()
            if sel:
                target = sel[0]
        if target is None and getattr(self, "last_event_id", None):
            target = self.project.event(self.last_event_id)
        if target is None:
            self.statusBar().showMessage("Prima tagga o seleziona un evento, poi clicca la sua posizione sul campo.", 4000)
            return
        self.undo.append(("pos", target["id"], target.get("pos")))
        target["pos"] = [round(x, 4), round(y, 4)]
        self.pending_pos = None
        self.mini_field.hint = ""
        self.statusBar().showMessage(f"Posizione salvata per: {self.project.event_caption(target)}", 3000)
        self.mark_dirty()
        self.refresh_events()

    # ================= disegni =================
    def add_still(self):
        """📷+ : fermo immagine nel punto attuale (chiede quanti secondi)."""
        if not self.reader:
            return
        self.stop()
        st = self._still_here()
        cur = st["dur"] if st else float(self.settings.value("freeze_secs", 2.0))
        v, ok = QInputDialog.getDouble(self, "Fermo immagine",
                                       "Per quanti secondi il video resta fermo qui?" if not st else
                                       "Qui c'è già un fermo immagine. Quanti secondi deve durare?",
                                       cur, 0.5, 120, 1)
        if not ok:
            return
        self.settings.setValue("freeze_secs", v)
        if st:
            st["dur"] = round(v, 2)
        else:
            st = self.project.add_still(self.reader.time_for_idx(self.idx), v)
            self.undo.append(("still", st["id"]))
        self.mark_dirty()
        self.refresh_drawings()
        self.show_idx(self.idx)
        if self.view.tool is None:
            self.set_tool("freccia")
        self.view.flash(f"⏸ Fermo immagine di {v:g} s: ora disegna sopra", "#ff9100", 1800)

    def _tl_drawing_clicked(self, did):
        d = self.project.drawing(did)
        if not d:
            return
        self.stop()
        self.view.selected_id = did
        self.seek_time(d["t"] + (0 if d.get("freeze") else 0.001))
        self.refresh_drawings()

    def _tl_drawing_edited(self, did):
        d = self.project.drawing(did)
        if not d:
            return
        if d.get("follow"):
            d["follow_end"] = self.reader.idx_for_time(d["t"] + d["dur"]) + 1
            d["dur_fixed"] = True
            self._extend_follow(d)
        self.mark_dirty()
        self.refresh_drawings()
        self._ensure_dynamic(d)
        self.show_idx(self.idx)

    def _extend_follow(self, d):
        self.act('allungata la durata su ' + _dd(d))
        """Hai allungato la barra di un giocatore seguito: riprendo a seguirlo da dove ero arrivato fino alla
        nuova fine (prima la barra si allungava ma l'anello spariva dove finiva il calcolo)."""
        end = d.get("follow_end")
        lost = 0
        for an in d.get("anchors") or []:
            if not an or an.get("type") != "track":
                continue
            tid = an["id"]
            tr = self.project.tracks.get(tid)
            if not tr or tid in self._followers or end is None or tr["to"] >= end - 1:
                continue
            if tr.get("lost_at") == tr["to"] and tr.get("end_reason") not in (None, "end", "stop"):
                lost += 1   # perso davvero (uscito dall'inquadratura, cambio di scena, dubbio)
                continue
            tr.pop("lost_at", None)
            v = tr["data"][tr["to"]]
            box = self._box_at(v[0], v[1], tr["to"], v[2])
            if box is None:
                h = v[2] * self.reader.height
                box = (v[0] * self.reader.width - 0.2 * h, v[1] * self.reader.height - h, 0.4 * h, h)
            self._start_follow(tid, tr["to"], box, end)
        if lost:
            self.statusBar().showMessage("Il giocatore era stato perso in quel punto: per continuare vai lì, tasto destro "
                                         "→ «🔄 È un altro: correggi da qui» e cliccalo.", 9000)
        else:
            self.statusBar().showMessage("👣 Continuo a seguire il giocatore fino alla nuova fine della barra…", 5000)

    def _tl_drawing_menu(self, did, gp):
        d = self.project.drawing(did)
        if not d:
            return
        m = QMenu(self)
        a_go = m.addAction("Vai al disegno")
        a_dur = None if d.get("freeze") else m.addAction(f"Durata… (ora {d['dur']:g} s)")
        m.addSeparator()
        a_del = m.addAction("🗑 Elimina disegno")
        a = m.exec(gp)
        if a == a_go:
            self._tl_drawing_clicked(did)
        elif a_dur is not None and a == a_dur:
            v, ok = QInputDialog.getDouble(self, "Durata del disegno", "Per quanti secondi resta sul video?",
                                           d["dur"], 0.3, 600, 1)
            if ok:
                d["dur"] = v
                d["dur_fixed"] = True
                self._tl_drawing_edited(did)
        elif a == a_del:
            self.view.selected_id = did
            self.delete_selected_drawing()

    def _tl_still_menu(self, sid, gp):
        st = self.project.still(sid)
        if not st:
            return
        m = QMenu(self)
        a_go = m.addAction("Vai al fermo immagine (per disegnarci)")
        a_dur = m.addAction(f"Durata… (ora {st['dur']:g} s)")
        m.addSeparator()
        a_del = m.addAction("🗑 Togli il fermo immagine")
        a = m.exec(gp)
        if a == a_go:
            self.stop()
            self.seek_time(st["t"])
        elif a == a_dur:
            self._tl_still_dur_dialog(sid)
        elif a == a_del:
            self.remove_still(sid)

    def _tl_still_dur_dialog(self, sid):
        st = self.project.still(sid)
        if not st:
            return
        v, ok = QInputDialog.getDouble(self, "Fermo immagine", "Per quanti secondi il video resta fermo qui?",
                                       st["dur"], 0.3, 120, 1)
        if ok:
            self.set_still_dur(sid, v)

    def remove_still(self, sid):
        st = self.project.still(sid)
        if not st:
            return
        n = len(self.project.still_drawings(st))
        if n and QMessageBox.question(self, "Togli fermo immagine", f"Togliere il fermo immagine e i suoi {n} "
                                      "disegni?") != QMessageBox.Yes:
            return
        self.stop()
        self.project.remove_still(sid)
        self.mark_dirty()
        self.refresh_drawings()
        self.show_idx(self.idx)

    def set_still_dur(self, sid, dur):
        st = self.project.still(sid)
        if st:
            st["dur"] = round(max(0.3, float(dur)), 2)
            self.mark_dirty()
            self.refresh_drawings()
            self._set_tl_time(self.project.out_time(self.t))

    def set_tool(self, kind):
        self.view.tool = kind
        self.tool_buttons[kind].setChecked(True)
        if kind:
            self.statusBar().showMessage(f"Strumento: {DRAWING_KINDS[kind]} — disegna sul video. "
                                         f"Esc per tornare alla selezione.", 4000)
        self.view.update()

    def set_color(self, col):
        self.view.color = col
        for c, b in self.color_buttons:
            b.setChecked(c == col)
        d = self.project.drawing(self.view.selected_id) if self.view.selected_id else None
        if d:
            d["color"] = col
            self.mark_dirty()
            self.refresh_drawings()

    @staticmethod
    def _link_mode(d):
        if d.get("fill"):
            return "riempita"
        return "chiusa" if d.get("closed") else "linea"

    def _apply_link_mode(self, d, mode):
        d["fill"] = mode == "riempita"
        d["closed"] = mode in ("chiusa", "riempita")

    def _set_link_from_menu(self, d, mode):
        self.act(f'collegamento: {mode} su ' + _dd(d))
        self._apply_link_mode(d, mode)
        self.mark_dirty()
        self.refresh_drawings()
        self.view.update()
        if self.view.selected_id == d.get("id"):
            self._show_style_of(d)

    def _link_changed(self, *_):
        """La scelta linea / figura chiusa / riempita vale per i nuovi collegamenti e per quello selezionato."""
        mode = self.link_cb.currentData()
        d = self.project.drawing(self.view.selected_id) if self.view.selected_id else None
        if d and d.get("kind") == "collega" and self._link_mode(d) != mode:
            self.act(f'collegamento: {mode}')
            self._apply_link_mode(d, mode)
            self.mark_dirty()
            self.refresh_drawings()
            self.props.refresh()
            self.view.update()

    def set_width(self, *_):
        w = self.width_cb.currentData()
        self.view.width_px = w
        d = self.project.drawing(self.view.selected_id) if self.view.selected_id else None
        if d and d.get("width") != w:
            self.act(f'spessore {w} su ' + _dd(d))
            d["width"] = w      # anche il disegno selezionato cambia spessore
            self.mark_dirty()
            self.refresh_drawings()

    def on_drawing_created(self, d):
        self.act('disegno creato: ' + _dd(d) + (' · segue giocatore' if d.get('follow') else '') + (' · riempi' if d.get('fill') else ''))
        if not self.reader:
            return
        if d.get("kind") in ("zona", "area"):
            d.setdefault("hatch", True)  # zone nuove a righe diagonali con bordo, come nelle analisi FIFA
        if d.get("kind") == "spotlight":
            d.setdefault("ring", "tratteggiato")
            d.setdefault("cone_on", False)
        st = None if self.playing else self._still_here()
        if st:
            # dentro un FERMO IMMAGINE: il disegno sta nel fermo e sparisce quando il video riparte
            d["freeze"] = True
            d["pause"] = 0.0
            d["dur"] = round(1.0 / self.reader.fps, 4)
            d["t"] = st["t"]
            self.project.add_drawing(d)
            self.undo.append(("drawing", d["id"]))
            self.mark_dirty()
            self.refresh_drawings()
            self._update_still_badge()
            self.statusBar().showMessage(f"Disegno nel fermo immagine ({st['dur']:g} s). Premi ▶︎ per vederlo: "
                                         "resta fermo, poi riparte e il disegno sparisce.", 6000)
            return
        # VIDEO IN CORSO = disegno dinamico
        d["dur"] = float(self.dur_sp.value())
        d["pause"] = 0.0
        self.settings.setValue("draw_dur", d["dur"])
        if self.anchor_chk.isChecked() and hasattr(self, "scene"):
            d["anchors"] = [{"type": "field", "f": self.idx, "p": list(p)} for p in d["points"]]
        starts = self._attach_to_players(d) if self.magnet_chk.isChecked() and hasattr(self, "scene") else []
        self.project.add_drawing(d)
        self._paused_done.add(d["id"])  # appena disegnato: non rifermarsi subito
        self.undo.append(("drawing", d["id"]))
        self.mark_dirty()
        self.refresh_drawings()
        if starts:
            for tid, box in starts:
                self._start_follow(tid, self.idx, box, d["follow_end"])
            self.view.flash("🧲 Disegno agganciato al giocatore: lo segue", d.get("color", "#ffeb3b"), 1600)
        elif d.get("anchors"):
            self._ensure_dynamic(d)

    def _players_now(self):
        """Giocatori nel fotogramma attuale (con cache)."""
        cache = getattr(self, "_det_cache", None)
        if cache and cache[0] == (self.reader.path, self.idx):
            return cache[1]
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            boxes, _sc = tracking.Detector.get().detect(self.reader.frame(self.idx))
        finally:
            QApplication.restoreOverrideCursor()
        boxes = [tuple(float(v) for v in b) for b in boxes]
        self._det_cache = ((self.reader.path, self.idx), boxes)
        return boxes

    def _attach_to_players(self, d):
        """Aggancia i punti del disegno ai giocatori su cui è stato fatto. Ritorna i giocatori da seguire."""
        kind = d["kind"]
        if kind in ("zona", "area", "mano"):
            return []
        W, H = self.reader.width, self.reader.height
        try:
            boxes = list(self._players_now() or [])
        except Exception:
            boxes = []

        def on_player(nx, ny, loose=False):
            px, py = nx * W, ny * H
            best, bd = None, 1e9
            for k, (x, y, w, h) in enumerate(boxes):
                mx, top, bot = (0.6 if loose else 0.35) * w, (1.2 if loose else 0.2) * h, 0.35 * h
                if x - mx <= px <= x + w + mx and y - top <= py <= y + h + bot:
                    dd = np.hypot(px - (x + w / 2), py - (y + h / 2))
                    if dd < bd:
                        best, bd = k, dd
            return best

        pts = d["points"]
        which = [None] * len(pts)
        if kind == "cerchio" and len(pts) >= 2:
            cx, cy = (pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2
            rx, ry = abs(pts[1][0] - pts[0][0]) / 2 * W, abs(pts[1][1] - pts[0][1]) / 2 * H
            best, bd = None, 1e9
            for k, (x, y, w, h) in enumerate(boxes):
                bx, by = x + w / 2, y + h / 2
                ell = lambda qx, qy: ((qx - cx * W) / max(rx, 1)) ** 2 + ((qy - cy * H) / max(ry, 1)) ** 2
                # cerchio attorno al giocatore, oppure ellisse disegnata sotto i piedi
                inside = ell(bx, by) <= 1.3 or ell(bx, y + h) <= 1.5
                dd = min(np.hypot(bx - cx * W, by - cy * H), np.hypot(bx - cx * W, y + h - cy * H))
                if inside and dd < bd:
                    best, bd = k, dd
            if best is None:
                # giocatore piccolo/lontano: guardo da vicino (centro del cerchio, poi appena sopra)
                frame = self.reader.frame(self.idx)
                for qy in (cy, cy - max(ry, 8) / H):
                    b = tracking.pick_player(frame, cx, qy)
                    if b is not None:
                        boxes.append(tuple(float(v) for v in b))
                        best = len(boxes) - 1
                        break
            which = [best, best]
        elif kind == "testo":
            which = [on_player(pts[0][0], pts[0][1], loose=True)]
        else:  # freccia, movimento, linea: ogni estremo per conto suo
            which = [on_player(p[0], p[1]) for p in pts]
        if all(w is None for w in which):
            return []
        tids, starts = {}, []
        anchors = d.get("anchors") or [{"type": "field", "f": self.idx, "p": list(p)} for p in pts]
        for i, k in enumerate(which):
            if k is None:
                continue
            x, y, w, h = boxes[k]
            fx, fy = x + w / 2, y + h
            if k not in tids:
                tid = new_id()
                tids[k] = tid
                self.project.tracks[tid] = {"from": self.idx, "to": self.idx,
                                            "data": {self.idx: [fx / W, fy / H, h / H, 1.0]}}
                starts.append((tid, (x, y, w, h)))
            px, py = pts[i][0] * W, pts[i][1] * H
            anchors[i] = {"type": "track", "id": tids[k], "off": [(px - fx) / h, (py - fy) / h], "ar": H / W}
        d["anchors"] = anchors
        d["follow"] = True
        # il disegno segue il giocatore per tutto il tempo in cui è visibile
        d["follow_end"] = self.idx + int(d["dur"] * self.reader.fps) + 1
        return starts

    def on_view_drawing_selected(self, did):
        self.timeline.selected_id = did
        self.timeline.update()
        self.dr_list.blockSignals(True)
        for i in range(self.dr_list.count()):
            it = self.dr_list.item(i)
            it.setSelected(it.data(Qt.UserRole) == did)
        self.dr_list.blockSignals(False)
        d = self.project.drawing(did) if did else None
        if hasattr(self, "props"):
            self.props.set_drawing(d)
        if d:
            self._fill_sel(d)
            self._show_style_of(d)
            # le opzioni del disegno sono nella scheda «Disegni»: la porto davanti
            if self.tabs.currentWidget() is not self._tab_disegni and not self.isFullScreen():
                self.tabs.setCurrentWidget(self._tab_disegni)

    def show_props(self, d):
        """Seleziona il disegno e mostra le sue opzioni (scheda «Disegni»)."""
        self.view.selected_id = d["id"]
        self.on_view_drawing_selected(d["id"])
        self.tabs.setCurrentWidget(self._tab_disegni)
        self.view.update()

    def remember_data(self, d):
        """Scia e dati scelti per un giocatore seguito valgono anche per i prossimi."""
        self.trail_sp.setValue(float(d.get("trail") or 0))
        self.speed_chk.setChecked(bool(d.get("speed")))
        self.goal_chk.setChecked(bool(d.get("goal")))
        self.run_chk.setChecked(bool(d.get("run")))

    def remember_cone(self, d):
        """Le scelte di anello e cono valgono anche per i prossimi giocatori."""
        self.settings.setValue("cone", {"size": d.get("size", 1.0), "cone": d.get("cone", 3.0),
                                        "light": d.get("light", 0.35), "ring": d.get("ring", "pieno"),
                                        "cone_on": "true" if d.get("cone_on", True) else "false",
                                        "cone_style": d.get("cone_style") or ""})

    def _show_style_of(self, d):
        """La barra mostra colore e spessore del disegno selezionato: da lì li cambi e il disegno si aggiorna."""
        if d.get("kind") == "collega":
            self.link_cb.blockSignals(True)
            self.link_cb.setCurrentIndex(max(0, self.link_cb.findData(self._link_mode(d))))
            self.link_cb.blockSignals(False)
        col = d.get("color")
        if col:
            self.view.color = col
            for c, b in self.color_buttons:
                b.setChecked(c == col)
        k = self.width_cb.findData(d.get("width"))
        if k >= 0:
            self.width_cb.blockSignals(True)
            self.width_cb.setCurrentIndex(k)
            self.width_cb.blockSignals(False)
            self.view.width_px = d.get("width")

    def _on_drawing_list_sel(self):
        items = self.dr_list.selectedItems()
        if not items:
            return
        did = items[0].data(Qt.UserRole)
        d = self.project.drawing(did)
        if not d:
            return
        self.stop()
        self.view.selected_id = did
        self._fill_sel(d)
        self.props.set_drawing(d)
        self.seek_time(d["t"] + (0 if d.get("freeze") else 0.001))
        self.view.hold_ids = {did}
        self.view.update()

    def _fill_sel(self, d):
        st = self.project.still_at(d["t"], 0.002) if d.get("freeze") else None
        fz = bool(d.get("freeze"))
        # disegno del fermo: si cambia solo la durata del fermo; disegno del video: solo quanto resta sul video
        for w_ in (self.sel_dur, self.sel_dur_lab):
            w_.setVisible(not fz)
        for w_ in (self.sel_pause, self.sel_pause_lab):
            w_.setVisible(fz)
        self.sel_dur.setEnabled(not fz)
        self.sel_pause.setEnabled(st is not None)
        self.sel_dur.setValue(d["dur"] if not fz else 0.5)
        self.sel_pause.setValue(st["dur"] if st else 0)
        if fz:
            self.sel_kind_lab.setText("<span style='color:#ff9100'>⏸ Questo disegno sta nel FERMO IMMAGINE: si vede "
                                      "solo mentre il video è fermo lì.</span>")
        else:
            on_still = self.project.still_at(d["t"], 0.05) if self.project.stills else None
            extra = (" Parte su un fermo immagine: si vede nel fermo e poi per questi secondi di video."
                     if on_still else "")
            self.sel_kind_lab.setText("<span style='color:#8a93a3'>▶ Questo disegno scorre con il video." + extra
                                      + "</span>")

    def apply_drawing_edit(self):
        d = self.project.drawing(self.view.selected_id) if self.view.selected_id else None
        if not d:
            self.statusBar().showMessage("Seleziona un disegno.", 3000)
            return
        if d.get("freeze"):
            st = self.project.still_at(d["t"], 0.002)
            if st and self.sel_pause.value() > 0:
                st["dur"] = float(self.sel_pause.value())
        else:
            if abs(d.get("dur", 0) - float(self.sel_dur.value())) > 1e-6:
                d["dur_fixed"] = True
            d["dur"] = float(self.sel_dur.value())
        self.mark_dirty()
        self.refresh_drawings()
        self._ensure_dynamic(d)

    def move_drawing_here(self):
        d = self.project.drawing(self.view.selected_id) if self.view.selected_id else None
        if not d:
            self.statusBar().showMessage("Seleziona un disegno.", 3000)
            return
        if d.get("freeze"):
            QMessageBox.information(self, "Disegno del fermo immagine",
                                    "Questo disegno sta dentro un fermo immagine e resta lì.\n"
                                    "Per averlo in un altro momento rifallo in quel punto.")
            return
        if any(a and a["type"] == "track" for a in (d.get("anchors") or [])):
            QMessageBox.information(self, "Disegno che segue un giocatore",
                                    "Questo disegno segue un giocatore dal momento in cui l'hai creato.\n"
                                    "Per usarlo in un altro momento eliminalo e rifallo lì.")
            return
        d["t"] = round(self.t, 3)
        self.project.drawings.sort(key=lambda x: x["t"])
        self.mark_dirty()
        self.refresh_drawings()
        self.view.update()
        self._ensure_dynamic(d)

    def delete_selected_drawing(self):
        self.act('disegno cancellato: ' + _dd(self.project.drawing(self.view.selected_id) if self.view.selected_id else None))
        did = self.view.selected_id
        if not did:
            items = self.dr_list.selectedItems()
            did = items[0].data(Qt.UserRole) if items else None
        if not did:
            return False
        self.project.remove_drawing(did)
        self._cleanup_followers()
        self.view.selected_id = None
        self.mark_dirty()
        self.refresh_drawings()
        return True

    # ================= disegni dinamici (giocatori seguiti, campo, misure) =================
    def _drawing_range(self, d):
        s = self.reader.idx_for_time(d["t"])
        e = min(self.reader.frame_count - 1, self.reader.idx_for_time(d["t"] + d["dur"]) + 1)
        return s, e

    def _needs_metrics(self, d):
        return d["kind"] in ("distanza", "collega", "visuale") or (
            d["kind"] == "spotlight" and (d.get("speed") or d.get("goal") or d.get("run")))

    def _nearest_calib(self, idx):
        cs = sorted(self.project.calibrations, key=lambda c: abs(c["idx"] - idx))
        return cs[0] if cs else None

    def _cam_ranges_for(self, d):
        s, e = self._drawing_range(d)
        rng = [(s, e)]
        return [r for r in rng if self.scene.cam.missing(*r)]

    def _box_at(self, nx, ny, idx, h_norm=None):
        """Box del giocatore vicino al punto; se non c'è, una box stimata."""
        frame = self.reader.frame(idx)
        box = tracking.pick_player(frame, nx, ny)
        if box is None and h_norm:
            hp = h_norm * self.reader.height
            box = (nx * self.reader.width - 0.2 * hp, ny * self.reader.height - hp, 0.4 * hp, hp)
        return box

    def _run_dynamic(self, title, cam_ranges, track_jobs, on_done):
        vpath = self.reader.path
        cam = self.scene.cam

        def work(progress, cancelled):
            rd = VideoReader(vpath)
            try:
                total = max(1, len(cam_ranges) + len(track_jobs))
                k = 0
                for a, b in cam_ranges:
                    cam.ensure(rd, a, b, cancel=cancelled,
                               progress=lambda f, k=k: progress((k + f) / total, "Analizzo il movimento della telecamera…"))
                    k += 1
                results = {}
                for j in track_jobs:
                    results[j["tid"]] = (j["start"], tracking.track_player(
                        rd, cam, j["start"], j["end"], j["box"], cancel=cancelled,
                        progress=lambda f, k=k: progress((k + f) / total, "Seguo il giocatore…")))
                    k += 1
                if cancelled():
                    raise exp.Cancelled()
                return results
            finally:
                rd.close()

        def done(res):
            self.scene.invalidate()
            on_done(res or {})
            self.mark_dirty()
            self.refresh_drawings()
            self.show_idx(self.idx)

        self._run_job(title, work, done)

    def _store_track(self, tid, start, data):
        tr = self.project.tracks.get(tid) or {"from": start, "to": start, "data": {}}
        merged = {k: v for k, v in tr["data"].items() if k < start}
        merged.update(data)
        if not merged:
            return
        ks = sorted(merged)
        self.project.tracks[tid] = {"from": ks[0], "to": ks[-1], "data": merged}

    def _ensure_dynamic(self, d):
        if not d.get("anchors") or not self.reader:
            return
        s, e = self._drawing_range(d)
        jobs = []
        for an in d["anchors"]:
            if an and an["type"] == "track":
                tr = self.project.tracks.get(an["id"])
                if an["id"] in self._followers or d.get("follow"):
                    continue
                if tr and s <= tr["to"] < e - 1 and tr.get("lost_at") != tr["to"]:
                    v = tr["data"][tr["to"]]
                    box = self._box_at(v[0], v[1], tr["to"], v[2])
                    if box is not None:
                        jobs.append({"tid": an["id"], "start": tr["to"], "end": e, "box": box})
        ranges = self._cam_ranges_for(d)
        if not ranges and not jobs:
            self.scene.invalidate()
            self.view.update()
            return

        def done(res):
            for tid, (start, data) in res.items():
                self._store_track(tid, start, data)
                if max(data, default=start) < e - 1:
                    self.project.tracks[tid]["lost_at"] = self.project.tracks[tid]["to"]

        self.show_idx(self.idx)
        self._run_dynamic("Preparo il disegno", ranges, jobs, done)

    def _set_sam(self, on):
        import samfollow
        if on and not samfollow.available():
            self.sam_chk.blockSignals(True)
            self.sam_chk.setChecked(False)
            self.sam_chk.blockSignals(False)
            r = QMessageBox.question(
                self, "Segui con precisione",
                "Per seguire i giocatori con precisione serve installare SAM 2 (di Meta) e PyTorch dentro il programma: "
                "sono alcune centinaia di MB e qualche minuto.\n\nNelle prove sui tuoi spezzoni segue il giocatore "
                "giusto 93 volte su 100, contro 50 del modo normale.\n\nLo installo adesso?")
            if r != QMessageBox.Yes:
                return

            def done(err):
                if err:
                    QMessageBox.warning(self, "Segui con precisione", str(err))
                    return
                self.sam_chk.blockSignals(True)
                self.sam_chk.setChecked(True)
                self.sam_chk.blockSignals(False)
                self.settings.setValue("sam_on", True)
                self.statusBar().showMessage("🎯 Inseguimento preciso attivo: vale per i giocatori che segui da adesso.",
                                             8000)
            self._run_job("Installo SAM 2", samfollow.install, done)
            return
        self.settings.setValue("sam_on", bool(on))

    def _snap_player(self, nx, ny):
        """Il giocatore sotto il clic: (piedi normalizzati, altezza normalizzata) oppure (punto cliccato, None)."""
        W, H = self.reader.width, self.reader.height
        foot, h = [float(nx), float(ny)], None
        try:
            boxes = list(self._players_now() or [])
        except Exception:
            boxes = []
        px, py = nx * W, ny * H
        best, bd = None, 1e9
        for (x, y, w, hh) in boxes:
            if x - 0.25 * w <= px <= x + 1.25 * w and y - 0.1 * hh <= py <= y + 1.1 * hh:
                dd = np.hypot(px - (x + w / 2), py - (y + hh / 2))
                if dd < bd:
                    best, bd = (x, y, w, hh), dd
        if best is not None:
            foot = [float((best[0] + best[2] / 2) / W), float((best[1] + best[3]) / H)]
            h = float(best[3]) / H
        elif boxes:
            near = min(boxes, key=lambda b: abs((b[1] + b[3]) - py))
            h = float(near[3]) / H
        # come cambia l'altezza dei giocatori con la profondità (più in alto nell'immagine = più lontano = più piccoli)
        self._hfit = None
        try:
            bs = [(float((y + hh) / H), float(hh / H)) for (x, y, w, hh) in boxes if hh > 8]
            if len(bs) >= 4:
                ys, hs = np.array([b[0] for b in bs]), np.array([b[1] for b in bs])
                keep = np.ones(len(ys), bool)
                for _ in range(2):
                    if keep.sum() < 4 or np.ptp(ys[keep]) < 0.08:
                        break
                    a_, b_ = np.polyfit(ys[keep], hs[keep], 1)
                    res = np.abs(hs - (a_ * ys + b_))
                    keep = res < max(0.012, 2.0 * np.median(res[keep]))
                if keep.sum() >= 4 and np.ptp(ys[keep]) >= 0.08 and a_ > 0.02:
                    self._hfit = [float(a_), float(b_)]
        except Exception:
            self._hfit = None
        return foot, h, best

    def on_ghost_clicked(self, nx, ny):
        """Strumento 👻, primo clic: il giocatore com'è. Il secondo clic dice dove doveva stare."""
        if not self.reader:
            return
        self.stop()
        foot, h, box = self._snap_player(nx, ny)
        col = self.view.color
        frame0 = self.reader.frame(self.idx) if box is not None else None

        def second(gx, gy):
            self.view.pick = None
            d = {"kind": "fantasma", "color": col, "width": self.view.width_px, "t": round(self.t, 3),
                 "points": [foot, [float(gx), float(gy)]], "h_fixed": h or 0.16,
                 "dur": float(self.dur_sp.value()), "pause": 0.0, "figure": True, "arrow": True,
                 "metrics": True, "id": new_id()}
            if getattr(self, "_hfit", None):
                d["hfit"] = list(self._hfit)
            if box is not None and frame0 is not None:
                import ritaglio
                QApplication.setOverrideCursor(Qt.WaitCursor)
                self.statusBar().showMessage("Ritaglio il giocatore…", 0)
                QApplication.processEvents()
                try:
                    cut = ritaglio.make(frame0, box)
                except Exception as e:  # noqa
                    cut = None
                    self.act(f"ritaglio non riuscito: {e}")
                finally:
                    QApplication.restoreOverrideCursor()
                if cut:
                    import cv2
                    try:   # copia di controllo, per capire se il ritaglio è venuto bene
                        raw = base64.b64decode(cut["png"])
                        dbg = os.path.join(paths.BASE, "ritagli_prova")
                        os.makedirs(dbg, exist_ok=True)
                        with open(os.path.join(dbg, d["id"] + ".png"), "wb") as fh:
                            fh.write(raw)
                        cv2.imwrite(os.path.join(dbg, d["id"] + "_fotogramma.jpg"),
                                    frame0[cut["crop"][1]:cut["crop"][3], cut["crop"][0]:cut["crop"][2]])
                    except Exception:
                        pass
                    self.act(f"ritaglio: {cut['method']} · box {[int(v) for v in box]} · {cut.get('sam_err', '')}")
                    d["cutout"] = cut
                    d["use_cut"] = True
                    self.statusBar().showMessage(f"Giocatore ritagliato ({cut['method']}).", 5000)
                else:
                    self.statusBar().showMessage("Non sono riuscito a ritagliare il giocatore: uso la sagoma.", 6000)
            if self._still_here():
                self.on_drawing_created(d)
            else:
                self.act('disegno creato: ' + _dd(d))
                self.project.add_drawing(d)
                self._paused_done.add(d["id"])
                self.undo.append(("drawing", d["id"]))
                self.mark_dirty()
                self.refresh_drawings()
            self.show_props(d)
            self.view.flash("👻 Fantasma: opzioni nella scheda «Disegni»", col, 2400)
        self.view.pick = {"idx": self.idx, "boxes": [], "color": col, "ghost": True,
                          "text": "👻 Ora clicca dove doveva stare (i piedi)  ·  Esc = annulla", "cb": second}
        self.view.update()

    def on_cone_clicked(self, nx, ny):
        """Strumento 💡: cono di luce fisso su un giocatore o su un punto qualsiasi. Non segue nessuno."""
        if not self.reader:
            return
        self.stop()
        W, H = self.reader.width, self.reader.height
        foot, h = [float(nx), float(ny)], None
        try:
            boxes = list(self._players_now() or [])
        except Exception:
            boxes = []
        px, py = nx * W, ny * H
        best, bd = None, 1e9
        for (x, y, w, hh) in boxes:
            if x - 0.25 * w <= px <= x + 1.25 * w and y - 0.1 * hh <= py <= y + 1.1 * hh:
                dd = np.hypot(px - (x + w / 2), py - (y + hh / 2))
                if dd < bd:
                    best, bd = (x, y, w, hh), dd
        if best is not None:
            # clic su un giocatore: il cono si appoggia ai suoi piedi ed è alto come lui
            foot = [float((best[0] + best[2] / 2) / W), float((best[1] + best[3]) / H)]
            h = float(best[3]) / H
        elif boxes:
            # punto vuoto: alto come il giocatore che sta più o meno alla stessa profondità
            near = min(boxes, key=lambda b: abs((b[1] + b[3]) - py))
            h = float(near[3]) / H
        d = {"kind": "spotlight", "color": self.view.color, "width": self.view.width_px, "t": round(self.t, 3),
             "points": [foot], "h_fixed": h or 0.16, "dur": float(self.dur_sp.value()), "pause": 0.0,
             "ring": "tratteggiato", "cone_on": True, "id": new_id()}
        try:
            cs = self.settings.value("cone") or {}
            for key in ("size", "cone", "light"):
                if key in cs:
                    d[key] = float(cs[key])
            d["ring"] = cs.get("ring", "tratteggiato")
            d["cone_style"] = cs.get("cone_style") or ""
        except Exception:
            pass
        if self._still_here():
            self.on_drawing_created(d)      # dentro un fermo immagine: sta nel fermo
        else:
            self.act('disegno creato: ' + _dd(d) + ' · cono fisso')
            self.project.add_drawing(d)
            self._paused_done.add(d["id"])
            self.undo.append(("drawing", d["id"]))
            self.mark_dirty()
            self.refresh_drawings()
        self.show_props(d)
        self.view.flash("💡 Cono di luce fisso: non segue nessuno. Opzioni nella scheda «Disegni»", d["color"], 2400)

    def on_player_clicked(self, nx, ny):
        if not self.reader:
            return
        self._click_pt = (nx, ny, self.idx)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            box = tracking.pick_player(self.reader.frame(self.idx), nx, ny)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Errore", str(e))
            return
        QApplication.restoreOverrideCursor()
        save_snap(self.view, f"clic_f{self.idx}_{'preso' if box is not None else 'NON_trovato'}",
                  mark=self.view.to_widget((nx, ny)))
        if box is None:
            PERF_EVENT(f"clic su giocatore: NESSUN giocatore trovato (punto {nx:.3f},{ny:.3f}, fotogramma {self.idx})")
            self.view.flash("Nessun giocatore lì: clicca proprio sul giocatore", "#ff5252", 2200)
            return
        PERF_EVENT(f"clic su giocatore: preso, riquadro {[int(v) for v in box]} al fotogramma {self.idx}")
        W, H = self.reader.width, self.reader.height
        tid = new_id()
        foot = [float((box[0] + box[2] / 2) / W), float((box[1] + box[3]) / H)]
        if not self.playing and self._still_here():
            # dentro un FERMO IMMAGINE: anello/cono fisso su quel giocatore, senza seguirlo
            d = {"kind": "spotlight", "color": self.view.color, "width": self.view.width_px, "t": round(self.t, 3),
                 "points": [foot], "h_fixed": float(box[3]) / H, "dur": 0.2, "pause": 0.0}
            try:
                cs = self.settings.value("cone") or {}
                for key in ("size", "cone", "light"):
                    if key in cs:
                        d[key] = float(cs[key])
                d["ring"] = cs.get("ring", "tratteggiato")
                d["cone_on"] = str(cs.get("cone_on", "false")).lower() == "true"
                d["cone_style"] = cs.get("cone_style") or ""
            except Exception:
                pass
            d["id"] = new_id()
            self.on_drawing_created(d)
            self.view.flash("◎ Giocatore segnato in questo fermo immagine: cono, nome e spazio nella scheda «Disegni»",
                            d["color"], 2600)
            return
        d = {"kind": "spotlight", "color": self.view.color, "width": self.view.width_px, "t": round(self.t, 3),
             "points": [foot], "anchors": [{"type": "track", "id": tid}], "follow": True,
             "dur": 0.2, "pause": 0.0, "follow_end": self._follow_end(self.idx),
             "trail": float(self.trail_sp.value()), "speed": self.speed_chk.isChecked(),
             "goal": self.goal_chk.isChecked(), "run": self.run_chk.isChecked(),
             "ring": "tratteggiato", "cone_on": False}
        try:
            cs = self.settings.value("cone") or {}
            for key in ("size", "cone", "light"):
                if key in cs:
                    d[key] = float(cs[key])
            # di base: anello tratteggiato e niente cono (il cono si accende a parte, se lo vuoi)
            d["ring"] = cs.get("ring", "tratteggiato")
            d["cone_on"] = str(cs.get("cone_on", "false")).lower() == "true"
        except Exception:
            pass
        self.settings.setValue("show_run", "true" if d["run"] else "false")
        self.settings.setValue("trail", d["trail"])
        self.settings.setValue("show_speed", "true" if d["speed"] else "false")
        self.settings.setValue("show_goal", "true" if d["goal"] else "false")
        s = self.idx
        self.project.tracks[tid] = {"from": s, "to": s, "data": {s: foot + [float(box[3]) / H, 1.0]}}
        self._add_dynamic(d)
        self._paused_done.add(d["id"])
        self.refresh_drawings()
        self._start_follow(tid, s, box, d["follow_end"])
        self.view.flash("👣 Seguo il giocatore" + ("" if d["follow_end"] else " — tasto S per fermarlo"),
                        d["color"], 1800)
        if (d["speed"] or d["goal"] or d["run"]) and not self.project.calibrations:
            self.statusBar().showMessage("Per vedere km/h e metri calibra il campo (📐 Calibra campo).", 8000)

    # ---------- inseguimento in sottofondo ----------
    def _follow_end(self, start):
        """Ultimo fotogramma da seguire, secondo «segui per» (None = finché lo fermo)."""
        secs = self.follow_sp.value()
        return None if secs <= 0 else start + int(secs * self.reader.fps)

    def _start_follow(self, tid, start, box, end=None):
        self.act(f'inizio a seguire giocatore {tid} dal fotogramma {start}' + (' (preciso SAM 2)' if getattr(self, 'sam_chk', None) is not None and self.sam_chk.isChecked() else ''))
        self._stop_follow(tid)
        th = QThread(self)
        limit = (end - start) if end is not None else int(self.reader.fps * 600)
        import samfollow
        if self.sam_chk.isChecked() and samfollow.available():
            cp = getattr(self, "_click_pt", None)
            pt = (cp[0], cp[1]) if cp and cp[2] == start else None
            wk = samfollow.SamWorker(self.reader.path, tid, start, box, max(1, limit), point=pt)
            self.statusBar().showMessage("🎯 Seguo con precisione (SAM 2): il calcolo è più lento del video, "
                                         "la riproduzione lo aspetta.", 6000)
        else:
            wk = FollowWorker(self.reader.path, self.scene.cam, tid, start, box, max(1, limit))
        wk.moveToThread(th)
        th.started.connect(wk.run)
        br = FollowBridge(self._on_follow_batch, self)
        wk.batch.connect(br.batch, Qt.QueuedConnection)
        self._followers[tid] = (th, wk, br)
        th.start()

    def _start_ball(self, p):
        """Traiettoria della palla: un clic sulla palla, poi la segue da sola (al massimo 10 secondi)."""
        self.stop()
        tid = new_id()
        s = self.idx
        self.project.tracks[tid] = {"from": s, "to": s, "data": {s: [float(p[0]), float(p[1]), 0.012, 1.0]},
                                    "ball": True}
        d = {"kind": "palla", "color": "#ffeb3b", "width": 3, "t": round(self.t, 3), "dur": 0.2, "pause": 0.0,
             "follow": True, "follow_end": None, "anchors": [{"type": "track", "id": tid}],
             "points": [[float(p[0]), float(p[1])]], "glow": False, "fade": True}
        self._add_dynamic(d)
        self.refresh_drawings()
        self.act(f"traiettoria della palla dal fotogramma {s}")
        self._start_ball_worker(tid, s, p)
        self.view.flash("⚽ Seguo la palla", d["color"], 1500)

    def _start_ball_worker(self, tid, start, p):
        import palla
        self._stop_follow(tid)
        th = QThread(self)
        W, H = self.reader.width, self.reader.height
        wk = palla.BallWorker(self.reader.path, tid, start, (p[0] * W, p[1] * H), int(self.reader.fps * 10))
        wk.moveToThread(th)
        th.started.connect(wk.run)
        br = FollowBridge(self._on_follow_batch, self)
        wk.batch.connect(br.batch, Qt.QueuedConnection)
        self._followers[tid] = (th, wk, br)
        th.start()

    def _stop_follow(self, tid, wait=True):
        f = self._followers.pop(tid, None)
        if f:
            th, wk, br = f
            wk.stop()
            try:
                wk.batch.disconnect()
            except Exception:
                pass
            th.quit()
            if wait:
                th.wait(4000)

    def _follow_drawings(self, tid):
        return [d for d in self.project.drawings
                if d.get("follow") and any(a and a.get("id") == tid for a in (d.get("anchors") or []))]

    def _on_follow_batch(self, tid, data, finished, reason):
        tr = self.project.tracks.get(tid)
        if tr is None:
            if finished:
                self._stop_follow(tid, wait=False)
            return
        if data:
            tr["data"].update({int(k): v for k, v in data.items()})
            ks = sorted(tr["data"])
            tr["from"], tr["to"] = ks[0], ks[-1]
        for d in self._follow_drawings(tid):
            if d.get("dur_fixed"):
                continue  # durata scelta a mano (linea del tempo o «Durata…»): non si allunga col tracciamento
            s = self.reader.idx_for_time(d["t"])
            tos = [self.project.tracks[a["id"]]["to"] for a in d["anchors"]
                   if a and a.get("type") == "track" and a["id"] in self.project.tracks]
            if tos:
                d["dur"] = max(d["dur"], round((min(tos) - s) / self.reader.fps + 0.04, 3))
        self.scene.invalidate()
        if finished and reason.startswith("doubt:"):
            f = self._followers.pop(tid, None)
            if f:
                f[0].quit()
            tr["lost_at"] = tr["to"]
            try:
                dbt = json.loads(reason[6:])
            except ValueError:
                dbt = None
            self.refresh_drawings()
            self.mark_dirty()
            if dbt and self._follow_drawings(tid):
                self._who_queue.append((tid, dbt))
                self._maybe_ask_who()
            self.view.update()
            return
        if finished:
            f = self._followers.pop(tid, None)
            if f:
                f[0].quit()
            tr["lost_at"] = tr["to"]
            tr["end_reason"] = reason or "?"   # «end» = arrivato alla fine richiesta: si può riprendere da lì
            secs = (tr["to"] - tr["from"]) / self.reader.fps
            if tr.get("ball"):
                PERF_EVENT(f"palla seguita per {secs:.1f} s, poi fermo per: {reason or '?'}")
                if reason == "lost":
                    self.statusBar().showMessage(
                        f"⚽ Palla seguita per {secs:.1f} s, poi persa (succede quando è tra i piedi o coperta). "
                        "Per continuare: vai dove la riperde e clicca di nuovo la palla con ⚽, oppure trascina "
                        "il pallino sulla palla.", 10000)
                elif reason.startswith("errore"):
                    self.statusBar().showMessage("⚽ " + reason, 10000)
                self.refresh_drawings()
                self.mark_dirty()
                self.view.update()
                return
            PERF_EVENT(f"giocatore seguito per {secs:.1f} s, poi fermo per: {reason or '?'}")
            why = {"cut": "cambio di inquadratura", "lost": "non più visibile per diversi secondi",
                   "end": "fine del video"}.get(reason, reason)
            if reason != "stop":
                self.statusBar().showMessage(f"Giocatore seguito per {secs:.1f} s (fino a: {why}). "
                                             f"Se in un punto ha preso un altro giocatore, trascina il cerchio "
                                             f"su quello giusto.", 9000)
            self.refresh_drawings()
            self.mark_dirty()
            if reason != "stop":
                QTimer.singleShot(0, lambda t=tid: self._fill_space_after_follow(t))
        self.view.update()

    # ---------- "chi è?": l'inseguimento non è sicuro e chiede ----------
    def _maybe_ask_who(self):
        """Il calcolo dei giocatori seguiti corre avanti rispetto a dove stai guardando: se trova un dubbio
        più avanti NON salta lì (ti porterebbe via da quello che stai facendo). Lo chiede quando ci arrivi."""
        if self.view.pick is not None or getattr(self, "_asking", False) or not self._who_queue or not self.reader:
            return
        k = next((j for j, (_t, dbt) in enumerate(self._who_queue) if int(dbt["idx"]) <= self.idx + 3), None)
        if k is None:
            dbt = min((q[1] for q in self._who_queue), key=lambda q: int(q["idx"]))
            self.statusBar().showMessage(
                f"🤔 Più avanti, a {fmt_time(int(dbt['idx']) / self.reader.fps)}, c'è un dubbio su un giocatore seguito: "
                "te lo chiedo quando ci arrivi.", 8000)
            return
        self._who_queue.insert(0, self._who_queue.pop(k))
        self._asking = True
        try:
            self._ask_who_next()
        finally:
            self._asking = False

    def _ask_who_next(self):
        while self._who_queue:
            tid, dbt = self._who_queue.pop(0)
            if tid in self.project.tracks and self._follow_drawings(tid):
                break
        else:
            self.view.pick = None
            self.view.update()
            return
        self.stop()
        idx = int(dbt["idx"])
        self.show_idx(idx)
        col = self._follow_drawings(tid)[0].get("color", "#ffeb3b")
        msg = ("🤔 Chi è? Si è perso tra più giocatori: clicca quello giusto" if dbt.get("why") != "contatto"
               else "🤔 Chi è? Due giocatori si sono incrociati: clicca quello giusto")
        self.view.pick = {"idx": idx, "boxes": dbt.get("boxes") or [], "color": col, "tid": tid,
                          "text": msg + "  ·  Esc = smetti di seguirlo",
                          "cb": lambda nx, ny, t=tid: self._answer_who(t, nx, ny)}
        self.statusBar().showMessage("L'app non era sicura di quale giocatore seguire e non ha tirato a indovinare. "
                                     "Puoi andare avanti o indietro di qualche fotogramma (← →) se serve, poi "
                                     "clicca il giocatore giusto.", 15000)
        self.view.update()

    def correct_here(self, d, near=None):
        self.act('correzione «è un altro» su ' + _dd(d))
        """L'anello è passato al giocatore sbagliato: clicchi quello giusto e si riparte da questo fotogramma
        (stesso meccanismo del «Chi è?», ma lo chiedi tu). Con più giocatori collegati si corregge quello
        più vicino al punto dove hai aperto il menu."""
        tids = [a["id"] for a in (d.get("anchors") or [])
                if a and a.get("type") == "track" and a["id"] in self.project.tracks]
        if not tids:
            return
        tid = tids[0]
        if near is not None and len(tids) > 1:
            def dist(t):
                v = self.scene.track_at(t, self.idx)
                return 9e9 if v is None else math.hypot(v[0] - near[0], (v[1] - v[2] / 2) - near[1])
            tid = min(tids, key=dist)
        self.stop()
        self.view.pick = {"idx": self.idx, "boxes": [], "color": d.get("color", "#ffeb3b"), "tid": tid,
                          "manual": True,
                          "text": "🔄 Clicca il giocatore giusto: riparto da qui  ·  Esc = annulla",
                          "cb": lambda nx, ny, t=tid: self._answer_who(t, nx, ny, resume=False, repair=True)}
        v = self.scene.track_at(tid, self.idx)
        if v is not None:
            self.view.pick["boxes"] = [[v[0] - v[2] * 0.22, v[1] - v[2], v[2] * 0.44, v[2]]]  # quello che sto correggendo
        self.statusBar().showMessage("Clicca il giocatore che doveva essere seguito. Sistemo anche gli ultimi "
                                     "secondi prima di questo momento.", 10000)
        self.view.update()

    def _repair_before(self, tid, box):
        """Correzione manuale: il giocatore giusto è `box` in questo fotogramma. Lo seguo ALL'INDIETRO per qualche
        secondo e sostituisco il tratto sbagliato (da dove le due strade si separano fino a qui): così scia,
        velocità e metri non restano attaccati all'errore. Ritorna quanti fotogrammi ha sistemato."""
        tr = self.project.tracks[tid]
        B = self.idx
        rd0 = self.reader
        lo = max(int(tr.get("from", B)), B - int(rd0.fps * 4.0))
        if B - lo < 4:
            return 0
        rd = VideoReader(rd0.path)
        try:
            cam = self.scene.cam
            cam.ensure(rd, lo, B)

            stride = max(1, int(math.ceil(rd.fps / 9.0)))
            # leggo il tratto una volta sola in avanti (andare all'indietro nel video è lento)
            # e tengo solo i fotogrammi che servono
            keep = {}
            for k in range(lo, B + 1):
                fr = rd.frame(k)
                if (B - k) % stride == 0 or k == lo:
                    keep[k] = fr.copy()

            class Rev:   # il video visto al contrario: fotogramma j = B - j
                width, height, fps = rd.width, rd.height, rd.fps
                frame_count = B - lo + 1

                def frame(_s, j):
                    k = B - max(0, min(B - lo, int(j)))
                    return keep[k] if k in keep else rd.frame(k)

            camr = type(cam)()
            for j in range(1, B - lo + 1):
                P = cam.pairs.get(B - j + 1)
                camr.pairs[j] = P if isinstance(P, str) else (np.linalg.inv(P) if P is not None else None)
            trk = tracking.PlayerTracker(Rev(), camr, 0, box, tracking.Detector.get(), stride=stride)
            back = {B: list(trk.first[:4])}
            j, merge, close = 0, None, 0
            while j < B - lo and not trk.finished:
                j = min(B - lo, j + stride)
                v = trk.step(j)
                if v is None:
                    continue
                k = B - j
                back[k] = list(v[:4])
                old = tr["data"].get(k)
                if old is not None:
                    dd = math.hypot((old[0] - v[0]) * rd.width, (old[1] - v[1]) * rd.height) / max(1.0, v[2] * rd.height)
                    close = close + 1 if dd < 0.35 else 0
                    if close >= 2:
                        merge = k   # qui la vecchia traccia era ancora sul giocatore giusto
                        break
        finally:
            rd.close()
        ks = sorted(back)
        first = merge if merge is not None else ks[0]
        new = {}
        for a, b in zip(ks, ks[1:]):
            if b <= first:
                continue
            va, vb = back[a], back[b]
            for k in range(a, b + 1):
                t = (k - a) / max(1, b - a)
                new[k] = [va[i] * (1 - t) + vb[i] * t for i in range(3)] + [1.0]
        for k in [k for k in tr["data"] if first < k < B]:
            del tr["data"][k]
        tr["data"].update({k: v for k, v in new.items() if first < k < B})
        if merge is None:
            # il giocatore giusto non coincide mai con la vecchia traccia in questi secondi:
            # la scia non deve collegare il pezzo vecchio (sbagliato) a quello nuovo
            tr.setdefault("breaks", []).append(int(first))
        return len(new)

    def _answer_who(self, tid, nx, ny, resume=True, repair=False):
        self.act(f'risposta «chi è?» giocatore {tid}' + (' con correzione all\'indietro' if repair else ''))
        self._click_pt = (nx, ny, self.idx)
        tr = self.project.tracks.get(tid)
        if tr is None:
            self.view.pick = None
            self._ask_who_next()
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            box = tracking.pick_player(self.reader.frame(self.idx), nx, ny)
        finally:
            QApplication.restoreOverrideCursor()
        if box is None:
            self.view.flash("Nessun giocatore lì: clicca proprio sul giocatore", "#ff5252", 2200)
            return
        W, H = self.reader.width, self.reader.height
        fixed = 0
        if repair:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                fixed = self._repair_before(tid, box)
            except Exception as e:  # noqa
                PERF_EVENT(f"correzione all'indietro non riuscita: {e}")
            finally:
                QApplication.restoreOverrideCursor()
        tr["data"] = {k: v for k, v in tr["data"].items() if k < self.idx}
        tr["data"][self.idx] = [float((box[0] + box[2] / 2) / W), float((box[1] + box[3]) / H),
                                float(box[3]) / H, 1.0]
        tr["from"], tr["to"] = min(tr["data"]), max(tr["data"])
        tr.pop("lost_at", None)
        ends = [d.get("follow_end") for d in self._follow_drawings(tid)]
        end = None if (not ends or any(e is None for e in ends)) else max(ends)
        if end is not None and end <= self.idx:
            end = self.idx + int(self.reader.fps)
        self.view.pick = None
        self.scene.invalidate()
        self._start_follow(tid, self.idx, box, end)
        self.mark_dirty()
        self.refresh_drawings()
        self.view.flash("👣 Ok, riprendo a seguirlo", "#2ecc71", 1500)
        self._maybe_ask_who()   # un altro dubbio qui vicino? (quelli più avanti aspettano che ci arrivi)
        if self.view.pick is None and resume:
            self.play()

    def start_reference(self):
        if not self.reader:
            QMessageBox.information(self, "Prova di riferimento", "Apri prima il video della partita.")
            return
        r = QMessageBox.question(
            self, "Prova di riferimento",
            "Serve a misurare quanto bene il programma segue i giocatori.\n\n"
            "Ti mostro 15 momenti della partita. In ognuno:\n"
            "1) clicca un giocatore vicino ad altri (contrasto, mischia); con ← → puoi scegliere un momento migliore;\n"
            "2) per 6 volte il video va avanti di 1 secondo: clicca sempre LO STESSO giocatore.\n\n"
            "Esc salta uno spezzone. Ci vogliono circa 10 minuti; puoi fermarti e riprendere dopo "
            "(gli spezzoni fatti restano salvati).\n\nIniziamo?")
        if r != QMessageBox.Yes:
            return
        from riferimento import RefSession
        self._ref = RefSession(self)
        self._ref.start()

    def _cancel_who(self):
        if self.view.pick is None:
            return False
        if self.view.pick.get("ghost"):
            self.view.pick = None
            self.statusBar().showMessage("Fantasma annullato.", 4000)
            self.view.update()
            return True
        if self.view.pick.get("ref") and getattr(self, "_ref", None):
            self._ref.skip()
            return True
        manual = self.view.pick.get("manual")
        self.view.pick = None
        self.statusBar().showMessage("Correzione annullata: non è cambiato niente." if manual else
                                     "Smesso di seguirlo nel punto del dubbio.", 6000)
        self._ask_who_next()
        self.view.update()
        return True

    def _follow_frontier(self):
        """Fin dove i giocatori seguiti sono già stati calcolati (per non superarli in riproduzione)."""
        lim = None
        for tid in self._followers:
            tr = self.project.tracks.get(tid)
            if not tr:
                continue
            if tr["from"] <= self.idx + 1:
                lim = tr["to"] if lim is None else min(lim, tr["to"])
        return lim

    def stop_following_here(self, d):
        for an in d.get("anchors") or []:
            if an and an["type"] == "track":
                self._stop_follow(an["id"])
                tr = self.project.tracks.get(an["id"])
                if tr:
                    tr["data"] = {k: v for k, v in tr["data"].items() if k <= self.idx}
                    if tr["data"]:
                        tr["to"] = max(tr["data"])
                    tr["lost_at"] = tr["to"]
        d["follow"] = False
        d["dur"] = max(0.2, round(self.t - d["t"] + 0.04, 3))
        self.scene.invalidate()
        self.mark_dirty()
        self.refresh_drawings()

    def _cleanup_followers(self):
        for tid in list(self._followers):
            if tid not in self.project.tracks:
                self._stop_follow(tid, wait=False)

    def _add_dynamic(self, d):
        self.project.add_drawing(d)
        self._paused_done.add(d["id"])
        self.undo.append(("drawing", d["id"]))
        # appena creato è già selezionato: le sue opzioni compaiono nella scheda «Disegni»
        self.view.selected_id = d["id"]
        self.on_view_drawing_selected(d["id"])

    def on_multi_created(self, kind, pts):
        if not self.reader:
            return
        if kind == "palla":
            self._start_ball(pts[0])
            return
        self.stop()
        W, H = self.reader.width, self.reader.height
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            frame = self.reader.frame(self.idx)
            boxes, _sc = tracking.Detector.get().detect(frame)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Errore", str(e))
            return
        QApplication.restoreOverrideCursor()
        anchors, points, starts = [], [], []
        d = {"kind": kind, "color": self.view.color, "width": self.view.width_px, "t": round(self.t, 3),
             "dur": 0.2, "pause": 0.0, "metrics": True, "follow": True,
             "follow_end": self._follow_end(self.idx)}
        if kind == "collega":
            self._apply_link_mode(d, self.link_cb.currentData())
        s = self.idx
        same_box = {}
        for nx, ny in pts:
            px, py = nx * W, ny * H
            best, bd = None, 1e9
            for (x, y, w, h) in boxes:
                inside = x - w * 0.25 <= px <= x + w * 1.25 and y - h * 0.1 <= py <= y + h * 1.25
                dist = float(np.hypot(px - (x + w / 2), py - (y + h)) / max(h, 1))
                if inside and dist < bd:
                    best, bd = (x, y, w, h), dist
            if best is not None:
                foot = [float((best[0] + best[2] / 2) / W), float((best[1] + best[3]) / H)]
                tid = same_box.get(tuple(best))
                if tid is not None:
                    # stesso giocatore cliccato due volte (es. triangolo che si chiude): un solo inseguimento
                    anchors.append({"type": "track", "id": tid})
                    points.append(foot)
                    continue
                tid = new_id()
                same_box[tuple(best)] = tid
                anchors.append({"type": "track", "id": tid})
                points.append(foot)
                self.project.tracks[tid] = {"from": s, "to": s, "data": {s: foot + [float(best[3]) / H, 1.0]}}
                starts.append((tid, best))
            else:
                anchors.append({"type": "field", "f": self.idx, "p": [nx, ny]})
                points.append([nx, ny])
        d["anchors"], d["points"] = anchors, points
        if not starts:
            d["follow"] = False
            d["dur"] = float(self.dur_sp.value())
        st_now = None if self.playing else self._still_here()
        if st_now:
            # dentro un FERMO IMMAGINE: il disegno sta nel fermo, come tutti gli altri disegni fatti lì
            d.update({"freeze": True, "pause": 0.0, "dur": round(1.0 / self.reader.fps, 4), "t": st_now["t"],
                      "follow": False})
            starts = []
        self._add_dynamic(d)
        self.refresh_drawings()
        if starts:
            # serve prima il movimento della telecamera per i punti fissi: lo calcola il primo inseguimento
            for tid, box in starts:
                self._start_follow(tid, s, box, d["follow_end"])
            self.view.flash("👣 Seguo i giocatori" + ("" if d["follow_end"] else " — tasto S per fermare"),
                            d["color"], 1800)
        else:
            self._ensure_dynamic(d)
        if not self.project.calibrations:
            self.statusBar().showMessage("Per vedere i metri calibra il campo (📐 Calibra campo).", 8000)

    def on_drawing_moved(self, did, i, info):
        d = self.project.drawing(did)
        if not d:
            return
        if i == -2:
            # spostata solo una scritta (es. metri tra i reparti): la posizione è già nel disegno
            self.act("spostata la scritta di " + _dd(d))
            self.mark_dirty()
            self.refresh_drawings()
            return
        if not d.get("anchors"):
            self.mark_dirty()
            self.refresh_drawings()
            return
        delta, res = info["delta"], info["res"]
        idxs = range(len(res)) if i < 0 else [i]
        jobs = []
        s, e = self._drawing_range(d)
        for j in idxs:
            an = d["anchors"][j]
            newp = [min(1, max(0, res[j][0] + delta[0])), min(1, max(0, res[j][1] + delta[1]))]
            if an is None:
                d["points"][j] = newp
            elif an["type"] == "field":
                M = self.scene.transform(self.idx, an["f"])
                if M is None:
                    an["f"], an["p"] = self.idx, newp
                else:
                    an["p"] = cam_apply(M, [newp])[0]
                d["points"][j] = an["p"]
            elif an.get("off"):
                # punto agganciato a un giocatore con scostamento: sposta solo lo scostamento
                v = self.scene.track_at(an["id"], self.idx)
                if v:
                    hh = v[2] * self.reader.height
                    an["off"] = [an["off"][0] + delta[0] * self.reader.width / hh,
                                 an["off"][1] + delta[1] * self.reader.height / hh]
                continue
            else:
                if d["kind"] == "palla":
                    # palla spostata a mano: da qui in avanti la segue di nuovo partendo dal punto giusto
                    tr = self.project.tracks.get(an["id"])
                    if tr is not None:
                        self._stop_follow(an["id"])
                        tr["data"] = {k: vv for k, vv in tr["data"].items() if k < self.idx}
                        tr["data"][self.idx] = [newp[0], newp[1], 0.012, 1.0]
                        tr["from"], tr["to"] = min(tr["data"]), max(tr["data"])
                        d["dur"] = max(0.2, round(self.t - d["t"] + 0.04, 3))
                        self.scene.invalidate()
                        self._start_ball_worker(an["id"], self.idx, newp)
                    continue
                v = self.scene.track_at(an["id"], self.idx)
                box = self._box_at(newp[0], newp[1], self.idx, v[2] if v else 0.1)
                self.project.tracks.get(an["id"], {}).pop("lost_at", None)
                if d.get("follow") or d["kind"] in ("spotlight", "distanza", "collega", "visuale"):
                    # riparte a seguirlo da qui, in sottofondo
                    tr = self.project.tracks.get(an["id"])
                    if tr is not None and box is not None:
                        self._stop_follow(an["id"])
                        tr["data"] = {k: vv for k, vv in tr["data"].items() if k < self.idx}
                        W, H = self.reader.width, self.reader.height
                        tr["data"][self.idx] = [float((box[0] + box[2] / 2) / W), float((box[1] + box[3]) / H),
                                                float(box[3]) / H, 1.0]
                        tr["from"], tr["to"] = min(tr["data"]), max(tr["data"])
                        d["follow"] = True
                        d["dur"] = max(0.2, round(self.t - d["t"] + 0.04, 3))
                        self.scene.invalidate()
                        self._start_follow(an["id"], self.idx, box, d.get("follow_end"))
                    continue
                jobs.append({"tid": an["id"], "start": self.idx, "end": e, "box": box})
        if not jobs:
            self.scene.invalidate()
            self.mark_dirty()
            self.refresh_drawings()
            self.view.update()
            return

        def done(r):
            for tid, (start, data) in r.items():
                self._store_track(tid, start, data)

        self._run_dynamic("Correggo il percorso", [], jobs, done)

    # ================= menu sul video (tasto destro) =================
    def _data_widget(self, d=None):
        """Caselle dei dati del giocatore, dentro un menu. d = disegno esistente o None (nuovo)."""
        from PySide6.QtWidgets import QWidgetAction
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(12, 6, 12, 6)
        lay.addWidget(QLabel("<b>Dati da mostrare</b>"))
        items = [("speed", "Velocità (km/h)"), ("goal", "Distanza dalla porta"), ("run", "Metri percorsi")]
        src = {"speed": self.speed_chk, "goal": self.goal_chk, "run": self.run_chk}
        for key, label in items:
            cb = QCheckBox(label)
            cb.setChecked(bool(d.get(key)) if d else src[key].isChecked())
            if d:
                cb.toggled.connect(lambda v, k=key: self._set_data(d, k, v))
            else:
                cb.toggled.connect(src[key].setChecked)
            lay.addWidget(cb)
        cb = QCheckBox("Scia del percorso")
        cb.setChecked((d.get("trail", 0) if d else self.trail_sp.value()) > 0)
        if d:
            cb.toggled.connect(lambda v: self._set_data(d, "trail", (self.trail_sp.value() or 3) if v else 0))
        else:
            cb.toggled.connect(lambda v: self.trail_sp.setValue((self.trail_sp.value() or 3) if v else 0))
        lay.addWidget(cb)
        if not self.project.calibrations:
            hint = QLabel("<span style='color:#ffb74d'>Per km/h e metri: Calibra campo</span>")
            lay.addWidget(hint)
        wa = QWidgetAction(self)
        wa.setDefaultWidget(box)
        return wa

    def _set_data(self, d, key, value):
        self.act(f'opzione {key} = {value} su ' + _dd(d))
        d[key] = value
        self.mark_dirty()
        self.refresh_drawings()
        if value and key in ("speed", "goal", "run"):
            self._ensure_dynamic(d)
        self.view.update()

    def on_video_context(self, did, nx, ny, gpos):
        if not self.reader:
            return
        menu = QMenu(self)
        d = self.project.drawing(did) if did else None
        tracked = d is not None and d["kind"] == "spotlight" and any(
            a and a["type"] == "track" for a in (d.get("anchors") or []))
        if d is not None:
            has_track = any(a and a.get("type") == "track" for a in (d.get("anchors") or []))
            self.view.selected_id = d["id"]
            self.on_view_drawing_selected(d["id"])
            self.view.update()
            menu.addAction("⚙ Opzioni di questo disegno (scheda «Disegni»)", lambda: self.show_props(d))
            if d["kind"] == "testo":
                menu.addAction("✏️ Modifica testo…", lambda: self.edit_text(d))
            if has_track:
                menu.addSeparator()
                if tracked:
                    menu.addAction("🔄 È un altro: correggi da qui (poi clicca quello giusto)",
                                   lambda: self.correct_here(d))
                    menu.addAction("Smetti di seguirlo da qui", lambda: self.stop_following_here(d))
                else:
                    menu.addAction("🔄 Il giocatore qui vicino è sbagliato: correggi da qui (poi clicca quello giusto)",
                                   lambda: self.correct_here(d, near=(nx, ny)))
                    menu.addAction("Smetti di seguirli da qui", lambda: self.stop_following_here(d))
            menu.addSeparator()
            menu.addAction("Elimina disegno", self.delete_selected_drawing)
        else:
            menu.addAction(self._data_widget(None))
            menu.addSeparator()
            act = menu.addAction("👣  Segui questo giocatore")
            act.triggered.connect(lambda: self.on_player_clicked(nx, ny))
        menu.exec(gpos)

    def on_drawing_double(self, did):
        d = self.project.drawing(did)
        if not d:
            return
        if d["kind"] == "testo":
            self.edit_text(d)
        else:
            self.show_props(d)

    def _set_space(self, d, v):
        self.act(f'spazio libero = {v} su ' + _dd(d))
        self._set_data(d, "space", bool(v))
        if v:
            self._fill_space(d)

    def _fill_space(self, d):
        """Misura la distanza dall'avversario più vicino lungo tutto l'inseguimento (5 misure al secondo,
        squadre riconosciute su tutto il pezzo, distanza ripulita e resa continua: vedi tracking.SpaceMeter)."""
        tid = next((a["id"] for a in (d.get("anchors") or []) if a and a.get("type") == "track"), None)
        tr = self.project.tracks.get(tid)
        if not tr or not self.reader or tid in self._followers:
            return   # se lo sta ancora seguendo, si misura alla fine
        keys_all = sorted(tr["data"])
        if not keys_all or all(len(tr["data"][k]) >= 10 for k in keys_all):
            return
        step = max(1, int(round(self.reader.fps / 5.0)))
        pick = [k for k in keys_all if (k - keys_all[0]) % step == 0]
        path, W, H = self.reader.path, self.reader.width, self.reader.height
        snap = {k: list(tr["data"][k][:3]) for k in pick}
        feet = {k: (tr["data"][k][0] * W, tr["data"][k][1] * H) for k in keys_all}

        def work(progress, cancelled):
            from video import VideoReader
            rd = VideoReader(path)
            meter = tracking.SpaceMeter()
            ks, scans = [], []
            try:
                for n, k in enumerate(pick):
                    if cancelled():
                        return None
                    progress(n / len(pick), f"Misuro lo spazio attorno al giocatore… {n + 1} di {len(pick)}")
                    fr = rd.frame(k)
                    if fr is None:
                        continue
                    x, y, h = snap[k]
                    ks.append(k)
                    scans.append(meter.scan(fr, (x * W, y * H), h * H))
            finally:
                rd.close()
            return tracking.SpaceMeter.series(ks, scans, feet, W, H)

        def done(out):
            n = 0
            for k, res in (out or {}).items():
                v = tr["data"].get(k)
                if v is not None:
                    base = list(v[:7]) if len(v) >= 7 else list(v[:4]) + [-1.0, -1.0, -1.0]
                    tr["data"][k] = base + list(res)
                    n += 1
            if n:
                self.mark_dirty()
            self.view.update()

        self._run_job("Spazio libero", work, done)

    def _fill_space_after_follow(self, tid):
        for d in self.project.drawings:
            if d.get("kind") == "spotlight" and d.get("space") and any(
                    a and a.get("type") == "track" and a.get("id") == tid for a in (d.get("anchors") or [])):
                self._fill_space(d)
                return

    def _set_ground_text(self, d, v):
        self._set_data(d, "ground", bool(v))
        if v and not self.project.calibrations:
            QMessageBox.information(self, "Testo sul campo", "Per stendere la scritta sul campo in prospettiva "
                                    "serve il campo calibrato (📐 Calibra campo). Finché non lo calibri resta dritta.")

    def edit_zone_label(self, d):
        self.stop()
        text, ok = QInputDialog.getText(self, "Scritta nella zona", "Scritta da mostrare dentro la zona "
                                        "(lascia vuoto per toglierla):", text=d.get("label", ""))
        if ok:
            self._set_data(d, "label", text.strip())

    def edit_text(self, d):
        from textdlg import TextDialog
        self.stop()
        dlg = TextDialog(self, d=d)
        if dlg.exec():
            v = dlg.values()
            if not v["text"].strip():
                return
            d.update(v)
            self.view.text_defaults = {k: v[k] for k in ("font", "fsize", "bold", "italic", "bg", "ground")}
            self.mark_dirty()
            self.refresh_drawings()

    def edit_cone(self, d):
        from textdlg import ConeDialog
        self.stop()
        dlg = ConeDialog(self, d, lambda: self.view.update())
        if dlg.exec():
            self.mark_dirty()
            self.remember_cone(d)
        self.refresh_drawings()
        self.props.refresh()

    def _name_drawing(self, d):
        from PySide6.QtWidgets import QInputDialog
        text, ok = QInputDialog.getText(self, "Nome", "Nome o numero da mostrare sopra il giocatore:",
                                        text=d.get("name", ""))
        if ok:
            self._set_data(d, "name", text.strip())

    # ================= calibrazione =================
    def calibrate(self):
        if not self.reader:
            return
        self.stop()
        frame = self.reader.frame(self.idx)
        existing = next((c for c in self.project.calibrations if c["idx"] == self.idx), None)
        replaced = existing
        near = self._nearest_calib(self.idx) if existing is None else None
        if near is not None:
            mb = QMessageBox(self)
            mb.setWindowTitle("Calibra campo")
            mb.setText("C'è già una calibrazione fatta su un'altra inquadratura.")
            mb.setInformativeText("«Completa» aggiunge i punti di questa inquadratura (es. l'altra metà campo) "
                                  "a quelli che hai già messo: una sola calibrazione, più precisa.")
            b_add = mb.addButton("Completa (aggiungi punti)", QMessageBox.AcceptRole)
            b_new = mb.addButton("Nuova calibrazione qui", QMessageBox.ActionRole)
            mb.addButton("Annulla", QMessageBox.RejectRole)
            mb.setDefaultButton(b_add)
            mb.exec()
            if mb.clickedButton() == b_add:
                QApplication.setOverrideCursor(Qt.WaitCursor)
                try:
                    lo, hi = sorted((int(near["idx"]), self.idx))
                    if hi - lo <= 900 and len(self.scene.cam.missing(lo, hi)) <= 900:
                        try:
                            self.scene.cam.ensure(self.reader, lo, hi)
                            self.project.camera = self.scene.cam.to_dict()
                        except Exception:
                            pass
                    M = self.scene.match_frames(int(near["idx"]), self.idx)
                finally:
                    QApplication.restoreOverrideCursor()
                if M is not None:
                    from calib import transfer_ok
                    fa = self.reader.frame(int(near["idx"]))
                    if fa is None or not transfer_ok(fa, frame, M, near["img"]):
                        M = None
                if M is None:
                    QMessageBox.warning(self, "Calibra campo",
                                        "Non riesco a collegare con sicurezza questa inquadratura a quella già "
                                        "calibrata, quindi non aggiungo i vecchi punti (finirebbero nel posto "
                                        "sbagliato).\n\nFai una «Nuova calibrazione qui»: quella dell'altra "
                                        "inquadratura resta valida e l'app usa sempre la più vicina.")
                    return
                existing = dict(near, img=cam_apply(M, near["img"]))
                replaced = near
                frame = self.reader.frame(self.idx)
            elif mb.clickedButton() != b_new:
                return
        dlg = CalibDialog(frame, (replaced or {}).get("pitch") or self.project.pitch, existing, self)
        if not dlg.exec():
            return
        res = dlg.result(self.idx)
        drop = {self.idx} | ({int(replaced["idx"])} if replaced else set())
        self.project.calibrations = [c for c in self.project.calibrations if int(c["idx"]) not in drop] + [res]
        self.project.pitch = res["pitch"]
        self.mark_dirty()
        self._update_calib_label()
        # i riconoscimenti automatici fatti con la calibrazione vecchia non valgono più
        self.project.pitch_refs = {}
        self.scene._failed = set()
        self.scene.invalidate()
        self.show_idx(self.idx)
        self.statusBar().showMessage(f"Campo calibrato (errore medio {res['err']:.2f} m). Vale per tutto il video: "
                                     f"dopo i cambi di scena l'app ritrova il campo da sola. Se in una scena non "
                                     f"compaiono le misure (altra telecamera), calibra anche lì.", 10000)

    def clear_calibrations(self):
        if not self.project.calibrations:
            return
        if QMessageBox.question(self, "Calibrazioni", "Eliminare tutte le calibrazioni del campo?") == QMessageBox.Yes:
            self.project.calibrations = []
            self.project.pitch_refs = {}
            self.scene.invalidate()
            self.mark_dirty()
            self._update_calib_label()
            self.view.update()

    def _toggle_lines(self, on):
        if on and not self.project.calibrations:
            self.statusBar().showMessage("Prima calibra il campo (📐 Calibra campo).", 5000)
        self.view.lines_fn = (lambda idx: self.scene.pitch_overlay(idx)) if on and hasattr(self, "scene") else None
        self.view.update()

    def _update_calib_label(self):
        n = len(self.project.calibrations)
        self.calib_lbl.setText(f"<span style='color:#69f0ae'>📐 campo calibrato ({n})</span>" if n else
                               "<span style='color:#8a93a3'>campo non calibrato</span>")

    # ================= lista eventi =================
    def _on_event_selection(self):
        self.timeline.selected = set(self.selected_event_ids())
        self.timeline.update()
        self.refresh_fields()

    def _on_event_double(self, r, c):
        eid = self.ev_table.item(r, 0).data(Qt.UserRole)
        ev = self.project.event(eid)
        if ev:
            self.stop()
            self.seek_time(ev["start"])
            self.playlist = ([(ev["start"], ev["end"])], 0)
            self.play()

    def play_selected(self):
        evs = self.selected_events() or self.filtered_events()
        if not evs or not self.reader:
            return
        clips = [(e["start"], e["end"]) for e in sorted(evs, key=lambda e: e["t"])]
        self.stop()
        self._paused_done = set()
        self.show_idx(self.reader.idx_for_time(clips[0][0]))
        self.playlist = (clips, 0)
        self.play()
        self.statusBar().showMessage(f"Revisione di {len(clips)} clip…", 3000)

    def edit_selected_event(self):
        evs = self.selected_events()
        if not evs:
            return
        dlg = EventDialog(self.project, evs[0], self)
        if dlg.exec():
            dlg.apply(self.reader.duration if self.reader else 0)
            self.mark_dirty()
            self.refresh_filters()
            self.refresh_events()
            self.refresh_stats()

    def delete_selected_events(self):
        evs = self.selected_events()
        if not evs:
            return False
        if len(evs) > 1:
            r = QMessageBox.question(self, "Elimina", f"Eliminare {len(evs)} eventi?")
            if r != QMessageBox.Yes:
                return True
        for e in evs:
            self.project.remove_event(e["id"])
        self.mark_dirty()
        self.refresh_filters()
        self.refresh_events()
        self.refresh_stats()
        return True

    def _events_menu(self, pos):
        m = QMenu(self)
        m.addAction("▶︎ Rivedi", self.play_selected)
        m.addAction("Modifica…", self.edit_selected_event)
        m.addAction("Elimina", self.delete_selected_events)
        m.addSeparator()
        m.addAction("Esporta playlist (un unico video)…", lambda: self.export_videos(True))
        m.addAction("Esporta clip separate…", lambda: self.export_videos(False))
        m.addAction("Esporta foto…", self.export_photos_events)
        m.exec(self.ev_table.viewport().mapToGlobal(pos))

    def _on_stat_click(self, r, c):
        if r >= len(self._stat_rows):
            return
        team, n = self._stat_rows[r]
        self.f_team.setCurrentIndex(max(0, self.f_team.findData(team)))
        if c < len(self._stat_cols):
            self.f_type.setCurrentIndex(max(0, self.f_type.findData(self._stat_cols[c])))
        else:
            self.f_type.setCurrentIndex(0)
        if n == "TOT":
            self.f_player.setCurrentIndex(0)
        elif n is None:
            self.f_player.setCurrentIndex(max(0, self.f_player.findData(-1)))
        else:
            self.f_player.setCurrentIndex(max(0, self.f_player.findData(int(n))))
        self.refresh_events()
        self.ev_table.selectAll()
        self.tabs.setCurrentIndex(0)

    # ================= pannello =================
    def _load_last_panel(self):
        try:
            self._last_panel = json.loads(self.settings.value("last_panel", "") or "{}")
        except Exception:
            self._last_panel = {}
        if self._last_panel:
            self.project.apply_panel(self._last_panel)

    def _remember_panel(self):
        self._last_panel = self.project.panel_dict()
        self.settings.setValue("last_panel", json.dumps(self._last_panel, ensure_ascii=False))

    def edit_panel(self):
        dlg = PanelDialog(self.project, self)
        if dlg.exec():
            self.project.apply_panel(dlg.result_data)
            self._remember_panel()
            self.mark_dirty()
            self.refresh_all()
            self._update_player_label()

    def export_panel(self):
        if not self._license_ok():
            return
        self.act('apro Esporta')
        d = self.settings.value("last_dir", os.path.expanduser("~/Desktop"))
        path, _ = QFileDialog.getSaveFileName(self, "Esporta pannello", os.path.join(d, "Pannello analisi.json"),
                                              "Pannello (*.json)")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.project.panel_dict(), f, ensure_ascii=False, indent=1)
            self.statusBar().showMessage("Pannello esportato: mandalo agli altri allenatori e lo importano dal menu File.", 6000)

    def import_panel(self):
        d = self.settings.value("last_dir", os.path.expanduser("~/Desktop"))
        path, _ = QFileDialog.getOpenFileName(self, "Importa pannello", d, "Pannello (*.json)")
        if not path:
            return
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            if not data.get("event_types"):
                raise ValueError("il file non contiene un pannello di eventi")
        except Exception as e:
            QMessageBox.warning(self, "Errore", f"File non valido: {e}")
            return
        self.project.apply_panel(data)
        self._remember_panel()
        self.mark_dirty()
        self.refresh_all()
        self._update_player_label()
        self._refresh_prog()

    # ================= salvataggio / annulla =================
    def save_project(self):
        if not self.reader or not self.project.path:
            return
        if hasattr(self, "scene"):
            self.project.camera = self.scene.cam.to_dict()
        try:
            self.project.save()
            self._dirty = False
        except Exception:
            alt = self._fallback_project_path(self.project.video_path)
            try:
                self.project.save(alt)
                self._dirty = False
            except Exception as e:
                QMessageBox.critical(self, "Salvataggio non riuscito", str(e))
                return
        if self.prog:
            try:
                self.prog.save()
            except OSError:
                pass
            self._refresh_prog()
        self._update_title()
        self.statusBar().showMessage(f"Analisi salvata: {self.project.path}", 5000)

    def undo_last(self):
        self.act('annulla ultima azione')
        while self.undo:
            item = self.undo.pop()
            if item[0] == "event" and self.project.event(item[1]):
                self.project.remove_event(item[1])
                self.view.flash("Annullato ultimo tag", "#8a93a3", 900)
                break
            if item[0] == "still" and self.project.still(item[1]):
                self.project.remove_still(item[1])
                self.view.flash("Tolto il fermo immagine", "#8a93a3", 900)
                break
            if item[0] == "drawing" and self.project.drawing(item[1]):
                self.project.remove_drawing(item[1])
                self._cleanup_followers()
                self.view.flash("Annullato ultimo disegno", "#8a93a3", 900)
                break
            if item[0] == "pos" and self.project.event(item[1]):
                self.project.event(item[1])["pos"] = item[2]
                self.view.flash("Annullata posizione", "#8a93a3", 900)
                break
        self.mark_dirty()
        self.refresh_filters()
        self.refresh_events()
        self.refresh_drawings()
        self.refresh_stats()

    # ================= tastiera =================
    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.KeyPress and obj.isWidgetType() and QApplication.activeWindow() is self:
            fw = QApplication.focusWidget()
            if isinstance(fw, (QLineEdit, QTextEdit, QPlainTextEdit, QAbstractSpinBox)):
                return False
            if isinstance(fw, QComboBox) and fw.isEditable():
                return False
            if isinstance(fw, QAbstractItemView) and fw.state() == QAbstractItemView.EditingState:
                return False
            if self.handle_key(ev):
                return True
        return super().eventFilter(obj, ev)

    def handle_key(self, ev):
        mods = ev.modifiers()
        if mods & (Qt.ControlModifier | Qt.MetaModifier | Qt.AltModifier):
            return False
        k = ev.key()
        shift = bool(mods & Qt.ShiftModifier)
        if k == Qt.Key_Space:
            self.toggle_play()
            return True
        if k == Qt.Key_Left:
            self.seek_time(self.t - 5) if shift else self.step(-1)
            return True
        if k == Qt.Key_Right:
            self.seek_time(self.t + 5) if shift else self.step(1)
            return True

        if k in (Qt.Key_Return, Qt.Key_Enter) and self.view._multi:
            self.view._finish_multi()
            return True
        if k in (Qt.Key_Return, Qt.Key_Enter) and self.view._poly:
            self.view._finish_poly()
            return True
        if k == Qt.Key_Escape and self.view._poly:
            self.view.cancel_multi()
            self.view.update()
            return True
        if k == Qt.Key_Escape and self._cancel_who():
            return True
        if k == Qt.Key_Escape:
            self.view.cancel_multi()
            if self.isFullScreen() and not self.view.tool and self.player is None:
                self.toggle_focus()
                return True
            self.set_tool(None)
            self.view.selected_id = None
            self.set_player(None)
            self._digits = ""
            self.pending_pos = None
            self.mini_field.hint = ""
            self.mini_field.update()
            self.view.update()
            return True
        if k in (Qt.Key_Delete, Qt.Key_Backspace):
            if self.view.selected_id:
                self.delete_selected_drawing()
                return True
            if self.ev_table.hasFocus() or self.selected_event_ids():
                self.delete_selected_events()
                return True
            return True
        if k == Qt.Key_S and self._followers is not None:
            ds = [d for d in self.project.drawings if d.get("follow") and d["t"] <= self.t + 1e-3
                  and d["t"] + d["dur"] >= self.t - 0.1]
            if ds:
                for d in ds:
                    self.stop_following_here(d)
                self.view.flash("■ Misurazione fermata qui", "#8a93a3", 1200)
                return True
        if k == Qt.Key_F and not ev.modifiers():
            self.add_still()
            return True
        if k == Qt.Key_I:
            self.mark_in()
            return True
        if k == Qt.Key_O:
            self.mark_out()
            return True
        if k == Qt.Key_E:
            self.export_piece()
            return True
        if k == Qt.Key_X:
            self.clear_piece()
            return True
        if k == Qt.Key_BracketLeft:
            self.speed_cb.setCurrentIndex(max(0, self.speed_cb.currentIndex() - 1))
            return True
        if k == Qt.Key_BracketRight:
            self.speed_cb.setCurrentIndex(min(self.speed_cb.count() - 1, self.speed_cb.currentIndex() + 1))
            return True
        return False

    # ================= focus =================
    def toggle_focus(self):
        if self.isFullScreen():
            self.showNormal()
            self.tabs.show()
            self.full_btn.setText("⛶ Schermo intero")
        else:
            self.tabs.hide()
            self.showFullScreen()
            self.full_btn.setText("⛶ Esci da schermo intero")

    def _set_lens(self, v):
        self.act(f'lente = {v}')
        self.view.lens_on = bool(v)
        self.settings.setValue("lens", bool(v))
        for wdg in (getattr(self, "lens_chk", None), getattr(self, "_lens_act", None)):
            if wdg is not None and wdg.isChecked() != bool(v):
                wdg.blockSignals(True)
                wdg.setChecked(bool(v))
                wdg.blockSignals(False)
        self.view.update()

    def toggle_timeline(self):
        hide = self.tl_box.isVisible()
        self.tl_box.setVisible(not hide)
        self.settings.setValue("tl_hidden", hide)
        # lo spazio liberato (o ripreso) va al video
        sp = self.vsplit
        bottom = sp.widget(1)
        bottom.layout().activate()
        tot = sum(sp.sizes())
        bh = bottom.minimumSizeHint().height() if hide else max(bottom.sizeHint().height(), 200)
        sp.setSizes([max(100, tot - bh), bh])
        self.settings.setValue("split_video", sp.sizes())

    # ================= esportazioni =================
    # ---------- esportazione semplice di un pezzo ----------
    def mark_in(self):
        if not self.reader:
            return
        self.piece_in = self.t
        if getattr(self, "piece_out", None) is not None and self.piece_out <= self.piece_in:
            self.piece_out = None
        self._update_piece()

    def mark_out(self):
        if not self.reader:
            return
        self.piece_out = self.t
        if getattr(self, "piece_in", None) is not None and self.piece_in >= self.piece_out:
            self.piece_in = None
        self._update_piece()

    # ---------- raccolta di pezzi (anche da più video) ----------
    # ================= lavori (progetti) =================
    def _build_prog_tab(self):
        """Scheda «Lavoro»: solo il lavoro aperto e i suoi video. Tutti i lavori, con pezzi raccolti e
        disegni, stanno nella finestra «I tuoi lavori» (pulsante in alto)."""
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(6)
        self._sel_prog_dir = None
        self._sel_vid = None
        self._an_cache = {}
        b = QPushButton("🏠  I tuoi lavori…")
        b.setToolTip("Tutti i lavori: per ognuno i pezzi raccolti, i video e i disegni. Da lì apri, crei, rinomini, elimini.")
        b.setMinimumHeight(34)
        b.clicked.connect(self.show_projects)
        v.addWidget(b)
        self.prog_title = QLabel()
        self.prog_title.setWordWrap(True)
        v.addWidget(self.prog_title)
        self.vid_lbl = QLabel("<b>Video di questo lavoro</b> <span style='color:#8a93a3'>— doppio clic per "
                              "aprirlo</span>")
        self.vid_lbl.setWordWrap(True)
        v.addWidget(self.vid_lbl)
        self.prog_list = QListWidget()
        self.prog_list.setFocusPolicy(Qt.NoFocus)
        self.prog_list.itemClicked.connect(self._vid_clicked)
        self.prog_list.itemDoubleClicked.connect(lambda _it: self._open_sel_entry())
        v.addWidget(self.prog_list, 1)
        row = QHBoxLayout()
        b = QPushButton("Apri")
        b.setToolTip("Apre il video selezionato")
        b.clicked.connect(self._open_sel_entry)
        row.addWidget(b)
        b = QPushButton("+ Aggiungi video…")
        b.setToolTip("Aggiunge uno o più video a questo lavoro")
        b.clicked.connect(self.add_videos_to_project)
        row.addWidget(b)
        v.addLayout(row)
        row = QHBoxLayout()
        b = QPushButton("Sposta in un altro lavoro…")
        b.setToolTip("Sposta il video selezionato (con i suoi disegni e i suoi pezzi raccolti) in un altro lavoro,\n"
                     "per esempio quando è finito nel lavoro di un'altra partita")
        b.clicked.connect(self.move_video_to_project)
        row.addWidget(b)
        b = QPushButton("Togli video…")
        b.setToolTip("Toglie da questo lavoro il video selezionato")
        b.clicked.connect(self.remove_from_project)
        row.addWidget(b)
        v.addLayout(row)
        self.prog_clips_btn = QPushButton("Pezzi raccolti…")
        self.prog_clips_btn.setToolTip("Pezzi raccolti di questo lavoro, anche da video diversi: ordinali ed "
                                       "esportali insieme o separati")
        self.prog_clips_btn.clicked.connect(self.open_raccolta)
        v.addWidget(self.prog_clips_btn)
        b = QPushButton("Mostra nel Finder")
        b.clicked.connect(self._reveal_project)
        v.addWidget(b)
        for wdg in w.findChildren(QPushButton):
            wdg.setFocusPolicy(Qt.NoFocus)
        self._tab_prog = w
        self.tabs.insertTab(0, w, "Lavoro")
        self.tabs.setCurrentIndex(0)
        self._refresh_prog()

    def _refresh_prog(self):
        if not hasattr(self, "prog_list"):
            return
        p = self.prog
        self._sel_prog_dir = os.path.abspath(p.dir) if p else None
        self.prog_list.clear()
        if not p:
            self.prog_title.setText("<b>Nessun lavoro aperto.</b> Premi «I tuoi lavori» per aprirne uno o crearlo.")
            self.prog_clips_btn.setText("Pezzi raccolti…")
            return
        self.prog_title.setText(f"Lavoro aperto:<br><b style='font-size:15px'>{p.name}</b>")
        if self._sel_vid not in {e["id"] for e in p.videos}:
            self._sel_vid = None
        cur = os.path.abspath(self.reader.path) if self.reader else None
        for e in p.videos:
            vp = p.video_path(e)
            here = cur == os.path.abspath(vp)
            if here and self._sel_vid is None:
                self._sel_vid = e["id"]
            info = ["analisi salvata" if p.has_analysis(e) else "da analizzare",
                    "copiato nel lavoro" if e.get("copied") else "collegato"]
            miss = not os.path.exists(vp)
            added = time.strftime("%d/%m/%y", time.localtime(e["added"])) if e.get("added") else ""
            it = QListWidgetItem(("▶ " if here else "    ") + f"{self.prog_list.count() + 1}.  "
                                 + os.path.splitext(os.path.basename(vp))[0] + ("   ⚠ non trovato" if miss else ""))
            it.setToolTip(os.path.basename(vp) + (f"\naggiunto il {added}" if added else "") + "\n" + " · ".join(info))
            it.setData(Qt.UserRole, e["id"])
            if here:
                f = it.font()
                f.setBold(True)
                it.setFont(f)
            self.prog_list.addItem(it)
            if e["id"] == self._sel_vid:
                self.prog_list.setCurrentItem(it)
        self.prog_clips_btn.setText(f"Pezzi raccolti ({p.n_clips()})…")

    @staticmethod
    def _fit_list(lst, max_rows):
        """L'elenco è alto quanto le sue righe (fino a max_rows): niente spazio vuoto sotto."""
        n = max(1, min(max_rows, lst.count()))
        rh = lst.sizeHintForRow(0) if lst.count() else lst.fontMetrics().height() + 6
        lst.setFixedHeight(n * max(rh, 18) + 2 * lst.frameWidth() + 2)

    def _saved_drawings(self, path):
        """Disegni salvati nell'analisi di un video non aperto (letti dal file, con una piccola memoria)."""
        try:
            mt = os.path.getmtime(path)
        except OSError:
            return []
        c = self._an_cache.get(path)
        if c and c[0] == mt:
            return c[1]
        try:
            with open(path, encoding="utf-8") as f:
                ds = json.load(f).get("drawings", []) or []
        except (OSError, ValueError):
            ds = []
        self._an_cache[path] = (mt, ds)
        return ds

    def _refresh_prog_detail(self):
        pass   # pezzi e disegni dei lavori ora stanno nella finestra «I tuoi lavori» (home.py)

    def _prog_clicked(self, it):
        self._sel_prog_dir = it.data(Qt.UserRole)
        self._sel_vid = None
        self._refresh_prog()

    def _vid_clicked(self, it):
        self._sel_vid = it.data(Qt.UserRole)

    def _sel_is_open(self):
        return bool(self.prog and self._sel_prog_dir and os.path.abspath(self.prog.dir) == self._sel_prog_dir)

    def _open_sel_project(self, want=None):
        """Apre il lavoro selezionato (se non è già aperto). Ritorna True se alla fine è quello aperto."""
        if not self._sel_prog_dir:
            return False
        if not self._sel_is_open():
            keep_dir, keep_vid = self._sel_prog_dir, self._sel_vid
            self.open_project(self._sel_prog_dir, want=want)
            self._sel_prog_dir, self._sel_vid = keep_dir, keep_vid
            self._refresh_prog()
        return self._sel_is_open()

    def _sel_entry(self):
        if not self._sel_is_open() or self._sel_vid is None:
            return None
        return next((e for e in self.prog.videos if e["id"] == self._sel_vid), None)

    def _open_sel_entry(self):
        if not self._open_sel_project(want=self._sel_vid):
            return
        e = self._sel_entry()
        if e:
            self.open_entry(e)

    def _open_raccolta_sel(self):
        if self._sel_prog_dir and not self._open_sel_project():
            return
        self.open_raccolta()

    def _detail_open(self, it):
        """Doppio clic su un pezzo o su un disegno: apre lavoro e video (se serve) e va in quel punto."""
        data = it.data(0, Qt.UserRole)
        if not data:
            return
        if data[0] == "clip":
            _k, video, start = data
            if not self._open_sel_project():
                return
            e = self.prog.find(video)
            if e is None:
                QMessageBox.information(self, "Pezzo", "Il video di questo pezzo non è più nel lavoro.")
                return
            self.open_entry(e)
            if self.reader and os.path.abspath(self.reader.path) == os.path.abspath(self.prog.video_path(e)):
                self.stop()
                self.seek_time(start)
            return
        _k, vid, did, t = data
        if not self._open_sel_project(want=vid):
            return
        e = next((x for x in self.prog.videos if x["id"] == vid), None)
        if e is None:
            return
        self.open_entry(e)
        if not (self.reader and os.path.abspath(self.reader.path) == os.path.abspath(self.prog.video_path(e))):
            return
        self.stop()
        d = self.project.drawing(did) if did else None
        if d:
            self.view.selected_id = did
            self._fill_sel(d)
            self._show_style_of(d)
            self.seek_time(d["t"] + (0 if d.get("freeze") else 0.001))
            self.view.hold_ids = {did}
            self.refresh_drawings()
        else:
            self.seek_time(t)

    def _reveal_project(self):
        if not self.prog:
            return
        import subprocess
        try:
            subprocess.Popen(["open", self.prog.dir])
        except OSError:
            pass

    def show_projects(self):
        """Finestra «I tuoi lavori»: lavori a sinistra, pezzi / video / disegni del lavoro scelto a destra."""
        import progetti
        from home import HomeDialog
        self.stop()
        dlg = HomeDialog(self)
        ok = dlg.exec()
        if self.prog and os.path.isdir(self.prog.dir):  # magari rinominato
            try:
                self.prog.name = progetti.Progetto.load(self.prog.dir).name
            except (OSError, ValueError):
                pass
            self._refresh_prog()
            self._update_title()
        act = dlg.action if ok else None
        if not act:
            return
        kind, folder = act[0], os.path.abspath(act[1])
        self._sel_prog_dir = folder
        if kind in ("project", "addvideo", "raccolta"):
            was_open = self._sel_is_open()
            if not was_open:
                self.open_project(folder)
            if self._sel_is_open():
                if kind == "addvideo" and (was_open or self.prog.videos):
                    self.add_videos_to_project()   # (un lavoro vuoto appena aperto lo chiede già da solo)
                elif kind == "raccolta":
                    self.open_raccolta()
            return
        if kind == "video":
            self._sel_vid = act[2]
            self._open_sel_entry()
            return

        class _It:   # stesso formato delle righe che _detail_open sa aprire
            def __init__(self, d):
                self._d = d

            def data(self, *_a):
                return self._d
        self._detail_open(_It(("clip", act[2], act[3]) if kind == "clip" else ("draw", act[2], act[3], act[4])))

    def open_project(self, folder, want=None):
        if not self._license_ok():
            return
        import progetti
        import raccolta
        if self.prog and os.path.abspath(self.prog.dir) == os.path.abspath(folder):
            return
        if not self.maybe_save():
            return
        try:
            p = progetti.Progetto.load(folder)
        except (OSError, ValueError) as e:
            QMessageBox.critical(self, "Lavoro", f"Non riesco ad aprire il lavoro:\n{e}")
            return
        self._close_video()
        self.prog = p
        self._sel_prog_dir, self._sel_vid = os.path.abspath(p.dir), None
        raccolta.PATH = p.raccolta_path
        dlg = getattr(self, "_raccolta_dlg", None)
        if dlg is not None:
            dlg.close()
            self._raccolta_dlg = None
        self.tabs.setCurrentWidget(self._tab_prog)
        self._refresh_prog()
        self._update_title()
        PERF_EVENT(f"lavoro aperto: {len(p.videos)} video")
        e = (next((x for x in p.videos if x["id"] == want), None) if want else None) or \
            next((x for x in p.videos if x["id"] == p.last), None) or (p.videos[0] if p.videos else None)
        if e:
            self.open_entry(e)
        else:
            self.statusBar().showMessage("Lavoro nuovo: aggiungi uno o più video.", 8000)
            QTimer.singleShot(100, self.add_videos_to_project)

    def open_entry(self, e):
        p = self.prog
        vp = p.video_path(e)
        if not os.path.exists(vp):
            QMessageBox.information(self, "Video non trovato", f"Il video «{e.get('name', os.path.basename(vp))}» "
                                    "è stato spostato o cancellato. Indica dove si trova adesso.")
            d = os.path.dirname(vp) if os.path.isdir(os.path.dirname(vp)) else os.path.expanduser("~")
            np_, _ = QFileDialog.getOpenFileName(self, "Dov'è il video?", d, VIDEO_FILTER + ";;Tutti i file (*)")
            if not np_:
                return
            e["path"] = os.path.abspath(np_)
            e["copied"] = False
            p.save(touch=False)
            vp = np_
        if self.reader and os.path.abspath(self.reader.path) == os.path.abspath(vp):
            return
        p.last = e["id"]
        try:
            p.save(touch=False)
        except OSError:
            pass
        self.open_path(vp, analysis_path=p.analysis_path(e))
        self._refresh_prog()

    def add_videos_to_project(self):
        import progetti
        import shutil
        if not self.prog:
            self.show_projects()
            return
        d = self.settings.value("last_dir", os.path.expanduser("~/Movies"))
        paths, _ = QFileDialog.getOpenFileNames(self, f"Aggiungi video a «{self.prog.name}»", d,
                                                VIDEO_FILTER + ";;Tutti i file (*)")
        if not paths:
            return
        self.settings.setValue("last_dir", os.path.dirname(paths[0]))
        new = [x for x in paths if not self.prog.find(x)]
        if not new:
            self.open_entry(self.prog.find(paths[0]))
            return
        size = sum(os.path.getsize(x) for x in new)
        gb = f"{size / 1e9:.1f} GB" if size >= 1e9 else f"{size / 1e6:.0f} MB"
        mb = QMessageBox(self)
        mb.setIcon(QMessageBox.Question)
        mb.setWindowTitle("Aggiungi video")
        mb.setText(f"Come vuoi aggiungere {'il video' if len(new) == 1 else f'i {len(new)} video'}?")
        mb.setInformativeText(
            "• Usarli dove sono: non occupa spazio. Non spostarli e non cancellarli finché ci lavori "
            "(se li sposti, il programma ti chiede dove sono).\n\n"
            f"• Copiarli nel lavoro: restano dentro al lavoro anche se cancelli l'originale, ma occupano "
            f"{gb} in più sul Mac.")
        b_link = mb.addButton("Usali dove sono", QMessageBox.AcceptRole)
        b_copy = mb.addButton(f"Copiali nel lavoro (+{gb})", QMessageBox.ActionRole)
        mb.addButton("Annulla", QMessageBox.RejectRole)
        mb.setDefaultButton(b_link)
        mb.exec()
        if mb.clickedButton() == b_link:
            entries = [self.prog.add(x) for x in new]
            self._refresh_prog()
            self.open_entry(entries[0])
            return
        if mb.clickedButton() != b_copy:
            return
        try:
            free = shutil.disk_usage(self.prog.dir).free
        except OSError:
            free = None
        if free is not None and free < size * 1.05 + 2e9:
            QMessageBox.warning(self, "Spazio", f"Sul Mac restano {free / 1e9:.1f} GB liberi: non bastano per "
                                f"copiare {size / 1e9:.1f} GB. Usa i video dove sono.")
            return
        taken, pairs = set(), []
        for x in new:
            out = progetti.copy_target(self.prog, x, taken)
            taken.add(out)
            pairs.append((x, out))
        prog = self.prog

        def work(progress, cancelled):
            return progetti.copy_files(pairs, progress, cancelled)

        def done(res):
            if self.prog is not prog:
                return
            entries = [prog.add(dst, copied=True) for _s, dst in res]
            self._refresh_prog()
            if entries:
                self.open_entry(entries[0])

        self._run_job("Copia nel lavoro", work, done)

    def move_video_to_project(self):
        """Sposta il video selezionato in un altro lavoro, con la sua analisi e i suoi pezzi raccolti."""
        import progetti
        import shutil
        e = self._sel_entry()
        if not e:
            QMessageBox.information(self, "Sposta video", "Scegli prima, nell'elenco «2 · Video», un video del "
                                    "lavoro aperto.")
            return
        src = self.prog
        vp = src.video_path(e)
        others = [p for p in progetti.list_projects() if os.path.abspath(p.dir) != os.path.abspath(src.dir)]
        new_txt = "＋ Nuovo lavoro…"
        name, ok = QInputDialog.getItem(self, "Sposta video", f"Sposta «{os.path.basename(vp)}» nel lavoro:",
                                        [p.name for p in others] + [new_txt], 0, False)
        if not ok:
            return
        if name == new_txt:
            base = os.path.splitext(os.path.basename(vp))[0]
            nn, ok = QInputDialog.getText(self, "Nuovo lavoro", "Nome del nuovo lavoro:", text=base)
            if not ok or not nn.strip():
                return
            dst = progetti.Progetto.create(nn.strip())
        else:
            dst = next(p for p in others if p.name == name)
        if self.reader and os.path.abspath(self.reader.path) == os.path.abspath(vp):
            if not self.maybe_save():
                return
            self._dirty = False
            self._close_video()
        new_vp = vp
        try:
            if e.get("copied"):
                vdir = os.path.join(dst.dir, "video")
                os.makedirs(vdir, exist_ok=True)
                new_vp = os.path.join(vdir, os.path.basename(vp))
                k = 2
                while os.path.exists(new_vp):
                    b, x = os.path.splitext(os.path.basename(vp))
                    new_vp = os.path.join(vdir, f"{b} ({k}){x}")
                    k += 1
                shutil.move(vp, new_vp)
            ne = dst.add(new_vp, copied=bool(e.get("copied")))
            if e.get("added"):
                ne["added"] = e["added"]   # resta la data in cui l'avevi aggiunto
            if os.path.exists(src.analysis_path(e)) and not os.path.exists(dst.analysis_path(ne)):
                os.makedirs(os.path.dirname(dst.analysis_path(ne)), exist_ok=True)
                shutil.move(src.analysis_path(e), dst.analysis_path(ne))
            # pezzi raccolti di questo video: passano nella raccolta dell'altro lavoro

            def clips_of(path):
                try:
                    with open(path, encoding="utf-8") as f:
                        return json.load(f).get("clips", []) or []
                except (OSError, ValueError):
                    return []

            def write_clips(path, clips):
                with open(path + ".tmp", "w", encoding="utf-8") as f:
                    json.dump({"clips": clips}, f, ensure_ascii=False)
                os.replace(path + ".tmp", path)
            mine = clips_of(src.raccolta_path)
            moved = [c for c in mine if os.path.abspath(c.get("video", "")) == os.path.abspath(vp)]
            if moved:
                for c in moved:
                    c["video"] = new_vp
                write_clips(dst.raccolta_path, clips_of(dst.raccolta_path) + moved)
                write_clips(src.raccolta_path, [c for c in mine if c not in moved])
            src.remove(e)
            dst.save()
        except Exception as ex:  # noqa
            QMessageBox.warning(self, "Sposta video", f"Non sono riuscito a spostare il video:\n{ex}")
            self._refresh_prog()
            return
        self.act(f'video «{os.path.basename(vp)}» spostato nel lavoro «{dst.name}»')
        self._sel_vid = None
        self._refresh_prog()
        self._update_title()
        self.statusBar().showMessage(f"«{os.path.basename(vp)}» spostato nel lavoro «{dst.name}»"
                                     + (f" con {len(moved)} pezzi raccolti" if moved else "") + ".", 8000)

    def remove_from_project(self):
        import progetti
        e = self._sel_entry()
        if not e:
            QMessageBox.information(self, "Togli video", "Scegli prima, nell'elenco «2 · Video», un video del "
                                    "lavoro aperto.")
            return
        p = self.prog
        vp = p.video_path(e)
        what = ("La copia del video dentro il lavoro e la sua analisi vanno nel Cestino."
                if e.get("copied") else "L'analisi di questo video (in questo lavoro) va nel Cestino; "
                "il video originale non viene toccato.")
        if QMessageBox.question(self, "Togli dal lavoro", f"Togliere «{os.path.basename(vp)}» dal lavoro?\n\n"
                                f"{what}\nSi può recuperare dal Cestino.") != QMessageBox.Yes:
            return
        if self.reader and os.path.abspath(self.reader.path) == os.path.abspath(vp):
            self._dirty = False  # lo stai togliendo: niente domanda di salvataggio
            self._close_video()
        racc_clips = []
        try:
            import raccolta
            racc_clips = [c for c in raccolta.load() if os.path.abspath(c["video"]) == os.path.abspath(vp)]
        except Exception:
            pass
        p.remove(e)
        progetti.trash(p.analysis_path(e))
        if e.get("copied"):
            progetti.trash(vp)
        self._refresh_prog()
        self._update_title()
        if racc_clips:
            self.statusBar().showMessage(f"Attenzione: {len(racc_clips)} pezzi raccolti venivano da questo video.",
                                         8000)

    def _close_video(self):
        """Chiude il video aperto (dopo aver già chiesto se salvare)."""
        if not self.reader:
            return
        self.stop()
        self._who_queue = []
        self.view.pick = None
        for tid in list(self._followers):
            self._stop_follow(tid)
        if self._pf:
            self._pf.close()
            self._pf = None
        self.reader.close()
        self.reader = None
        self.audio.close()
        self.project = Project()
        self.undo = []
        self.piece_in = self.piece_out = None
        self.view.lines_fn = None
        self.view.clear()
        self.timeline.duration = 0
        self.statusBar().clearMessage()
        self._refresh_cuts()
        self.timeline.update()
        self._dirty = False
        self.refresh_all()
        self._update_title()
        self._refresh_prog()

    def add_to_raccolta(self):
        if not self.reader:
            return
        a, b = getattr(self, "piece_in", None), getattr(self, "piece_out", None)
        if a is None or b is None:
            QMessageBox.information(self, "Raccolta",
                                    "1. Porta il video all'inizio del pezzo e premi «[ Inizio» (tasto I).\n"
                                    "2. Porta il video alla fine e premi «Fine ]» (tasto O).\n"
                                    "3. Premi «➕ Raccolta».\n\nPuoi aggiungere pezzi di video diversi: poi da "
                                    "Raccolta → Apri la raccolta li metti in ordine e li esporti insieme o separati.")
            return
        import raccolta
        self.project.camera = self.scene.cam.to_dict()
        clips = raccolta.load()
        clips.append({"video": self.reader.path, "start": float(a), "end": float(b), "title": "",
                      "project": raccolta.snapshot(self.project, self.reader.fps, a, b)})
        try:
            raccolta.save(clips)
        except OSError as e:
            QMessageBox.critical(self, "Raccolta", f"Non riesco a salvare la raccolta:\n{e}")
            return
        self.piece_in = self.piece_out = None
        self._update_piece()
        self.statusBar().showMessage(f"Pezzo aggiunto alla raccolta ({len(clips)} pezzi). Per ordinarli ed "
                                     f"esportarli: Raccolta → Apri la raccolta.", 8000)
        self.view.flash(f"➕ In raccolta ({len(clips)})", "#2ecc71", 1500)
        self._refresh_prog()

    def open_raccolta(self):
        import raccolta
        dlg = getattr(self, "_raccolta_dlg", None)
        if dlg is None:
            dlg = raccolta.RaccoltaDialog(self)
            self._raccolta_dlg = dlg
        dlg.setWindowTitle("Pezzi raccolti" + (f" — {self.prog.name}" if self.prog else ""))
        dlg.refresh()
        dlg.show()
        dlg.raise_()

    # ---------- pezzi tolti (non distruttivo) ----------
    def cut_piece(self):
        if not self.reader:
            return
        a, b = getattr(self, "piece_in", None), getattr(self, "piece_out", None)
        if a is None or b is None:
            QMessageBox.information(self, "Togli pezzo",
                                    "1. Porta il video all'inizio del pezzo da togliere e premi «[ Inizio» (tasto I).\n"
                                    "2. Porta il video alla fine del pezzo e premi «Fine ]» (tasto O).\n"
                                    "3. Premi «✂ Togli pezzo».\n\n"
                                    "Il pezzo viene saltato in riproduzione e nei video esportati. Il file originale "
                                    "non viene toccato: per rimetterlo, tasto destro sul pezzo grigio nella barra "
                                    "del tempo.")
            return
        self.project.add_cut(a, b)
        self.piece_in = self.piece_out = None
        self._update_piece()
        self._refresh_cuts()
        self.mark_dirty()
        self.statusBar().showMessage(f"Pezzo tolto ({b - a:.0f} s): verrà saltato. Per rimetterlo: tasto destro "
                                     f"sul pezzo grigio nella barra del tempo.", 8000)

    def restore_all_cuts(self):
        if not self.project.cuts:
            return
        self.project.cuts = []
        self._refresh_cuts()
        self.mark_dirty()
        self.statusBar().showMessage("Tutti i pezzi tolti sono stati rimessi.", 4000)

    def _refresh_cuts(self):
        self.timeline.cuts = list(self.project.cuts)
        self.timeline.update()
        self._cut_hint()

    def _cut_hint(self):
        c = self.project.cut_at(self.t) if self.reader else None
        want = "✂ pezzo tolto (in riproduzione viene saltato)" if c and not self.playing else ""
        if self.view.overlay_hint in ("", "✂ pezzo tolto (in riproduzione viene saltato)") and \
                self.view.overlay_hint != want:
            self.view.overlay_hint = want
            self.view.update()

    def _cut_menu(self, t, gpos):
        c = self.project.cut_at(t)
        if not c:
            return
        menu = QMenu(self)
        act = menu.addAction(f"Rimetti questo pezzo ({fmt_time(c[0])} – {fmt_time(c[1])})")
        if menu.exec(gpos) == act:
            self.project.cuts = [x for x in self.project.cuts if x is not c]
            self._refresh_cuts()
            self.mark_dirty()

    def export_without_cuts(self):
        if not self._license_ok():
            return
        self.act('esporto senza pezzi tolti')
        if not self.reader:
            return
        if not self.project.cuts:
            QMessageBox.information(self, "Esporta", "Non hai tolto nessun pezzo: per togliere i tempi morti segna "
                                    "Inizio e Fine e premi «✂ Togli pezzo».")
            return
        self.piece_in, self.piece_out = 0.0, self.reader.duration
        try:
            self.export_piece(title="Video intero senza i pezzi tolti")
        finally:
            self.piece_in = self.piece_out = None
            self._update_piece()

    def clear_piece(self):
        had = getattr(self, "piece_in", None) is not None or getattr(self, "piece_out", None) is not None
        self.piece_in = self.piece_out = None
        self._update_piece()
        if had:
            self.statusBar().showMessage("Pezzo tolto.", 3000)

    def _tl_piece_edited(self, a, b):
        """Inizio o Fine spostati con il mouse sulla linea del tempo."""
        self.piece_in, self.piece_out = a, b
        self._update_piece()

    def _update_piece(self):
        a, b = getattr(self, "piece_in", None), getattr(self, "piece_out", None)
        self.clear_piece_btn.setVisible(a is not None or b is not None)
        self.timeline.piece = (a, b)
        self.timeline.update()
        self.in_btn.setText(f"[ {fmt_time(a)}" if a is not None else "[ Inizio")
        self.out_btn.setText(f"{fmt_time(b)} ]" if b is not None else "Fine ]")
        if a is not None and b is not None:
            self.statusBar().showMessage(f"Pezzo da {fmt_time(a, True)} a {fmt_time(b, True)} "
                                         f"({b - a:.1f} s): premi «💾 Esporta pezzo».", 6000)

    def export_piece(self, title="Esporta pezzo"):
        if not self._license_ok():
            return
        if not self.reader:
            return
        a, b = getattr(self, "piece_in", None), getattr(self, "piece_out", None)
        if a is None or b is None:
            QMessageBox.information(self, "Esporta pezzo",
                                    "1. Porta il video dove vuoi far iniziare il pezzo e premi «[ Inizio» (tasto I).\n"
                                    "2. Porta il video alla fine del pezzo e premi «Fine ]» (tasto O).\n"
                                    "3. Premi «💾 Esporta pezzo» (tasto E).\n\n"
                                    "Il video esportato contiene i disegni, i fermi immagine e i giocatori seguiti.")
            return
        dlg = ExportVideoDialog(title if isinstance(title, str) else "Esporta pezzo", 1, self)
        dlg.cb_cap.setChecked(False)
        if not dlg.exec():
            return
        opts = dlg.options()
        suffix = " (WhatsApp)" if opts["preset"] == "wa" else ""
        default = f"{self._video_base()} - {fmt_time(a).replace(':', 'm')}-{fmt_time(b).replace(':', 'm')}{suffix}.mp4"
        path, _ = QFileDialog.getSaveFileName(self, "Salva video", os.path.join(self._export_dir(), default),
                                              "Video MP4 (*.mp4)")
        if not path:
            return
        if not path.lower().endswith(".mp4"):
            path += ".mp4"
        self.settings.setValue("export_dir", os.path.dirname(path))
        self.project.camera = self.scene.cam.to_dict()
        snap = json.loads(json.dumps(self.project.to_dict()))
        vpath = self.reader.path
        # i pezzi tolti non finiscono nel video
        seg = [{"start": x, "end": y, "caption": "", "color": "#2ecc71"}
               for x, y in self.project.kept_segments(a, b)]
        if not seg:
            QMessageBox.information(self, "Esporta", "Il pezzo scelto è tutto dentro parti tolte dal video.")
            return

        def work(progress, cancelled):
            p = Project.from_dict(snap)
            rd = VideoReader(vpath)
            try:
                exp.export_video(rd, seg, path, p, progress=progress, cancel=cancelled, **opts)
            finally:
                rd.close()
            return [path]

        self._run_job("Esportazione pezzo", work, self._export_done)

    def _export_dir(self):
        d = self.settings.value("export_dir", "")
        if d and os.path.isdir(d):
            return d
        if self.reader:
            return os.path.dirname(self.reader.path)
        return os.path.expanduser("~/Desktop")

    def _video_base(self):
        return os.path.splitext(os.path.basename(self.reader.path))[0] if self.reader else "video"

    def _events_for_export(self):
        evs = self.selected_events()
        if evs:
            return sorted(evs, key=lambda e: e["t"])
        evs = self.filtered_events()
        if not evs:
            QMessageBox.information(self, "Nessun evento", "Non ci sono eventi da esportare. Tagga qualche azione prima.")
            return []
        r = QMessageBox.question(self, "Esporta", f"Nessun evento selezionato.\nEsportare tutti i {len(evs)} eventi "
                                 f"mostrati nella lista?")
        return evs if r == QMessageBox.Yes else []

    def export_videos(self, single):
        if not self._license_ok():
            return
        if not self.reader:
            return
        evs = self._events_for_export()
        if not evs:
            return
        dlg = ExportVideoDialog("Esporta video", len(evs), self, single_file=single)
        if not dlg.exec():
            return
        opts = dlg.options()
        suffix = " (WhatsApp)" if opts["preset"] == "wa" else ""
        if single or len(evs) == 1:
            if len(evs) == 1:
                what = exp.safe_name(f"{evs[0]['type']} {fmt_time(evs[0]['t']).replace(':', 'm')}")
            else:
                what = "playlist"
            default = f"{self._video_base()} - {what}{suffix}.mp4"
            path, _ = QFileDialog.getSaveFileName(self, "Salva video", os.path.join(self._export_dir(), default),
                                                  "Video MP4 (*.mp4)")
            if not path:
                return
            if not path.lower().endswith(".mp4"):
                path += ".mp4"
            self.settings.setValue("export_dir", os.path.dirname(path))
            jobs = [(path, [exp.segment_for_event(self.project, e) for e in evs])]
        else:
            folder = QFileDialog.getExistingDirectory(self, "Cartella dove salvare le clip", self._export_dir())
            if not folder:
                return
            self.settings.setValue("export_dir", folder)
            jobs = []
            for i, e in enumerate(evs, 1):
                pl = self.project.player_label(e.get("player"))
                name = f"{i:02d} - {fmt_time(e['t']).replace(':', 'm')} {e['type']}" + (f" {pl}" if pl else "")
                jobs.append((os.path.join(folder, exp.safe_name(name) + suffix + ".mp4"),
                             [exp.segment_for_event(self.project, e)]))
        self.project.camera = self.scene.cam.to_dict()
        project_snapshot = json.loads(json.dumps(self.project.to_dict()))
        vpath = self.reader.path

        def work(progress, cancelled):
            p = Project.from_dict(project_snapshot)
            rd = VideoReader(vpath)
            outs = []
            try:
                for k, (out, segs) in enumerate(jobs):
                    def pr(frac, msg, k=k):
                        progress((k + frac) / len(jobs), f"Video {k + 1} di {len(jobs)}…" if len(jobs) > 1 else msg)
                    exp.export_video(rd, segs, out, p, progress=pr, cancel=cancelled, **opts)
                    outs.append(out)
            finally:
                rd.close()
            return outs

        self._run_job("Esportazione video", work, self._export_done)

    def _run_job(self, title, fn, on_done):
        dlg = QProgressDialog(title + "…", "Annulla", 0, 1000, self)
        dlg.setWindowTitle(title)
        dlg.setWindowModality(Qt.WindowModal)
        dlg.setMinimumDuration(0)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.setValue(0)
        th = QThread(self)
        wk = Worker(fn)
        wk.moveToThread(th)
        th.started.connect(wk.run)

        def on_prog(frac, msg):
            dlg.setValue(int(frac * 1000))
            dlg.setLabelText(msg)

        def cleanup():
            dlg.close()
            th.quit()
            th.wait()
            for item in list(self._threads):
                if item[0] is th:
                    self._threads.remove(item)

        def finish(res):
            cleanup()
            on_done(res)

        def fail(msg):
            cleanup()
            if msg != "__cancelled__":
                QMessageBox.critical(self, "Errore", f"{title}: non riuscito.\n{msg}")

        br = Bridge(on_prog, finish, fail, self)
        wk.progress.connect(br.prog, Qt.QueuedConnection)
        wk.finished.connect(br.done, Qt.QueuedConnection)
        wk.failed.connect(br.fail, Qt.QueuedConnection)
        dlg.canceled.connect(wk.cancel, Qt.DirectConnection)
        self._threads.append((th, wk, br))
        th.start()

    def _export_done(self, paths):
        if not paths:
            return
        self._offer_share(paths, "Video esportato." if len(paths) == 1 else f"Esportati {len(paths)} video.")

    def _offer_share(self, paths, msg):
        mb = QMessageBox(self)
        mb.setWindowTitle("Fatto")
        mb.setText(msg)
        mb.setInformativeText(os.path.dirname(paths[0]))
        b_share = mb.addButton("Condividi…", QMessageBox.ActionRole)
        b_show = mb.addButton("Mostra nel Finder", QMessageBox.ActionRole)
        mb.addButton("OK", QMessageBox.AcceptRole)
        mb.exec()
        if mb.clickedButton() == b_share:
            if not exp.share_files(self, paths):
                exp.reveal_in_finder(paths[0])
                self.statusBar().showMessage("Ho aperto il Finder: trascina il file su WhatsApp, Mail o AirDrop.", 6000)
        elif mb.clickedButton() == b_show:
            exp.reveal_in_finder(paths[0])

    def export_photo_current(self):
        if not self._license_ok():
            return
        self.act('foto del fotogramma')
        if not self.reader:
            return
        self.project._scene_cam = self.scene.cam
        default = f"{self._video_base()} {fmt_time(self.t).replace(':', 'm')}s.jpg"
        path, flt = QFileDialog.getSaveFileName(self, "Salva foto", os.path.join(self._export_dir(), default),
                                                "JPEG (*.jpg);;PNG (*.png)")
        if not path:
            return
        if not os.path.splitext(path)[1]:
            path += ".png" if "PNG" in flt else ".jpg"
        self.settings.setValue("export_dir", os.path.dirname(path))
        try:
            exp.export_photo(self.reader, self.project, self.t, path)
        except Exception as e:
            QMessageBox.critical(self, "Errore", str(e))
            return
        self._offer_share([path], "Foto salvata.")

    def export_photos_events(self):
        if not self._license_ok():
            return
        self.act('foto degli eventi')
        if not self.reader:
            return
        self.project._scene_cam = self.scene.cam
        evs = self._events_for_export()
        if not evs:
            return
        folder = QFileDialog.getExistingDirectory(self, "Cartella dove salvare le foto", self._export_dir())
        if not folder:
            return
        self.settings.setValue("export_dir", folder)
        outs = []
        for i, e in enumerate(evs, 1):
            pl = self.project.player_label(e.get("player"))
            name = exp.safe_name(f"{i:02d} - {fmt_time(e['t']).replace(':', 'm')} {e['type']}" + (f" {pl}" if pl else ""))
            out = os.path.join(folder, name + ".jpg")
            exp.export_photo(self.reader, self.project, e["t"], out, caption=self.project.event_caption(e),
                             caption_color=self.project.color_for(e["type"]))
            outs.append(out)
        self.show_idx(self.idx)
        self._offer_share(outs, f"Salvate {len(outs)} foto.")

    def export_excel(self):
        if not self._license_ok():
            return
        self.act('esporto Excel')
        if not self.project.events:
            QMessageBox.information(self, "Nessun evento", "Non ci sono eventi da esportare.")
            return
        default = f"{self._video_base()} - statistiche.xlsx"
        path, _ = QFileDialog.getSaveFileName(self, "Salva Excel", os.path.join(self._export_dir(), default),
                                              "Excel (*.xlsx)")
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        self.settings.setValue("export_dir", os.path.dirname(path))
        try:
            exp.export_excel(self.project, self.project.events, path)
        except Exception as e:
            QMessageBox.critical(self, "Errore", str(e))
            return
        self._offer_share([path], "File Excel salvato.")

    def export_field_png(self):
        if not self._license_ok():
            return
        default = f"{self._video_base()} - campo.png"
        path, _ = QFileDialog.getSaveFileName(self, "Salva immagine campo", os.path.join(self._export_dir(), default),
                                              "PNG (*.png)")
        if not path:
            return
        if not path.lower().endswith(".png"):
            path += ".png"
        self.settings.setValue("export_dir", os.path.dirname(path))
        fw = FieldWidget(interactive=False)
        fw.points = self.big_field.points
        fw.resize(1260, 860)
        pm = fw.grab()
        pm.save(path, "PNG")
        self._offer_share([path], "Immagine del campo salvata.")

    # ================= varie =================
    def show_help(self):
        keys = "<br>".join(f"<b>{et['key']}</b> = {et['name']}" for et in self.project.event_types if et.get("key"))
        QMessageBox.information(self, "Scorciatoie", f"""
<b>Spazio</b> play/pausa · <b>← →</b> fotogramma · <b>⇧← ⇧→</b> ±5 secondi · <b>[ ]</b> velocità<br>
<b>Tab</b> cambia squadra · <b>numeri</b> giocatore (es. 1 poi 0 = #10) · <b>Esc</b> azzera<br>
<b>Canc/⌫</b> elimina disegno o eventi selezionati · <b>⌘Z</b> annulla · <b>⌘E</b> foto · <b>⌘F</b> focus<br><br>
<b>Eventi</b><br>{keys}<br><br>
Per disegnare scegli uno strumento in alto e trascina sul video. Il disegno parte dal momento attuale e resta
visibile per i secondi indicati; con «Pausa» il video si ferma da solo quando appare.""")

    def closeEvent(self, ev):
        self.stop()
        if not self.maybe_save():
            ev.ignore()
            return
        for tid in list(self._followers):
            self._stop_follow(tid)
        for th, wk, _br in list(self._threads):
            wk.cancel()
            th.quit()
            th.wait(3000)
        if self._pf:
            self._pf.close()
        if getattr(self, "_anchor_pool", None) is not None:
            self._anchor_pool.shutdown(wait=False, cancel_futures=True)
        super().closeEvent(ev)


STYLE = """
QWidget { font-size: 13px; }
QFrame#tagbox { background: #1d2129; border: 1px solid #2c323d; border-radius: 8px; }
QToolButton#toolbtn { font-size: 16px; border: 1px solid #3a414d; border-radius: 6px; background: #262b34; color: #e8edf5; }
QToolButton#toolbtn:checked { background: #3d7eff; border-color: #6d9dff; }
QPushButton#teambtn { padding: 6px 10px; font-weight: 600; border-radius: 6px; border: 1px solid #3a414d; background:#262b34; }
QPushButton#mode_freeze { padding: 4px 14px; font-weight: 700; border-radius: 6px; border: 1px solid #ffb74d; background: #ff9100; color: #16191f; }
QPushButton#mode_freeze:hover { background: #ffa726; }
QPushButton#teambtn:checked { background: #3d7eff; color: white; border-color: #6d9dff; }
QLabel#timelbl { font-family: Menlo, monospace; font-size: 14px; }
QLabel#playerlbl { padding: 2px; }
QTableWidget { gridline-color: #2c323d; }
"""


def apply_dark(app):
    app.setStyle("Fusion")
    pal = QPalette()
    base = QColor("#16191f")
    win = QColor("#1f232b")
    txt = QColor("#e8edf5")
    pal.setColor(QPalette.Window, win)
    pal.setColor(QPalette.WindowText, txt)
    pal.setColor(QPalette.Base, base)
    pal.setColor(QPalette.AlternateBase, QColor("#20252e"))
    pal.setColor(QPalette.Text, txt)
    pal.setColor(QPalette.Button, QColor("#2a2f39"))
    pal.setColor(QPalette.ButtonText, txt)
    pal.setColor(QPalette.Highlight, QColor("#3d7eff"))
    pal.setColor(QPalette.HighlightedText, QColor("white"))
    pal.setColor(QPalette.ToolTipBase, QColor("#2a2f39"))
    pal.setColor(QPalette.ToolTipText, txt)
    pal.setColor(QPalette.PlaceholderText, QColor("#8a93a3"))
    pal.setColor(QPalette.Disabled, QPalette.Text, QColor("#6b7380"))
    pal.setColor(QPalette.Disabled, QPalette.ButtonText, QColor("#6b7380"))
    app.setPalette(pal)
    app.setStyleSheet(STYLE)


def autotest():
    """«--autotest»: controllo senza finestre, usato da «Crea applicazione.command» subito dopo la costruzione.
    Prova le parti che più facilmente mancano in un'app costruita: OpenCV, rilevatore giocatori, ffmpeg, SAM 2."""
    ok = True

    def step(name, fn):
        nonlocal ok
        try:
            r = fn()
            print(f"OK   {name}" + (f": {r}" if r else ""), flush=True)
        except Exception as e:  # noqa
            ok = False
            print(f"ERRORE {name}: {type(e).__name__}: {e}", flush=True)
    import cv2
    import numpy as np
    step("OpenCV", lambda: cv2.__version__)
    step("rilevatore giocatori", lambda: len(tracking.Detector.get().detect_crop(np.zeros((360, 640, 3), np.uint8), 320, 180, 320)[0]) * 0 or "caricato")
    def _ff():
        import subprocess
        exe = exp.ffmpeg_exe()
        if not os.path.exists(exe):
            raise RuntimeError("ffmpeg non incluso")
        if getattr(sys, "frozen", False):
            # nell'app ci deve essere SOLO la versione LGPL con il codificatore di Apple
            if "ffbin" not in exe or not exp.apple_encoder():
                raise RuntimeError("ffmpeg incluso non è la versione LGPL con il codificatore Apple: " + exe)
            conf = subprocess.run([exe, "-hide_banner", "-buildconf"], capture_output=True, text=True).stdout
            if "enable-gpl" in conf or "libx264" in conf or "nonfree" in conf:
                raise RuntimeError("ffmpeg incluso contiene parti GPL")
        return os.path.basename(exe) + (" (codificatore Apple)" if exp.apple_encoder() else "")
    step("ffmpeg (esporta pezzi)", _ff)
    import samfollow
    step("SAM 2 presente", lambda: "sì" if samfollow.available() else (_ for _ in ()).throw(RuntimeError("manca torch, sam2 o il modello")))
    step("SAM 2 si carica", lambda: type(samfollow._predictor()).__name__)
    import licenza
    step("attivazione", lambda: "chiave pubblica inserita" if licenza.PUBLIC_KEY != "__PUBLIC_KEY__" else (_ for _ in ()).throw(RuntimeError("chiave pubblica mancante")))

    def _net():
        import ssl
        orig = ssl.create_default_context
        ctx = licenza.ssl_context()
        # come su un Mac senza Homebrew: solo i certificati di sistema
        if not os.path.exists("/etc/ssl/cert.pem"):
            raise RuntimeError("mancano i certificati di sistema /etc/ssl/cert.pem")
        d = licenza.net_date()
        if d is None:
            raise RuntimeError("non riesco a collegarmi a internet in modo sicuro (serve internet durante la prova)")
        return f"ok, data {d.strftime('%d/%m/%Y')}"
    step("collegamento sicuro (chiave, Segnala, aggiornamenti)", _net)
    import aggiorna

    def _ver():
        v = aggiorna.current_version()
        if v == "sviluppo":
            raise RuntimeError("numero di versione mancante nell'app")
        return v
    step("numero di versione", _ver)
    print("TUTTO A POSTO" if ok else "CI SONO ERRORI", flush=True)
    sys.exit(0 if ok else 1)


def licenza_needed():
    import licenza
    return licenza.needed()


def _quit_now(code):
    """Chiude il programma senza far smontare a Python le finestre una per una: a volte Qt va in crash proprio
    lì (dopo che tutto è già stato salvato) e il Mac mostra «si è chiuso inaspettatamente»."""
    for s in (sys.stdout, sys.stderr):
        try:
            s.flush()
        except Exception:
            pass
    os._exit(int(code or 0))


def main():
    if "--autotest" in sys.argv:
        autotest()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    _ico = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icona.png")
    if not os.path.exists(_ico):
        _ico = os.path.join(getattr(sys, "_MEIPASS", ""), "icona.png")
    if os.path.exists(_ico):
        app.setWindowIcon(QIcon(_ico))   # icona nel Dock anche quando si avvia da Python
    apply_dark(app)
    import licenza
    if not licenza.ensure(app):   # nell'applicazione costruita: funziona solo sul Mac attivato
        _quit_now(0)
    import segnala
    import aggiorna
    crashed = segnala.crashed_last_time()
    segnala.mark_running()
    app.aboutToQuit.connect(segnala.mark_clean_exit)
    w = MainWindow()
    w.show()
    QTimer.singleShot(1500, cleanup_once)
    QTimer.singleShot(6000, aggiorna.confirm_started)
    import threading
    threading.Thread(target=segnala.flush_queue, daemon=True).start()
    QTimer.singleShot(4000, w.check_updates)
    ut = QTimer(w)
    ut.timeout.connect(lambda: w.check_updates(quiet=True))
    ut.start(3 * 3600 * 1000)   # a programma aperto: ogni 3 ore, solo avviso discreto
    if licenza.needed():
        lt = QTimer(w)
        lt.timeout.connect(w._license_ok)
        lt.start(30 * 60 * 1000)   # ogni 30 minuti
    QTimer.singleShot(2000, w.show_whats_new)
    if crashed:
        def ask_crash():
            mb = QMessageBox(w)
            mb.setWindowTitle("Chiusura inattesa")
            mb.setText("L'ultima volta il programma si è chiuso da solo. Vuoi segnalarlo ad Andrea?")
            yes = mb.addButton("Segnala", QMessageBox.AcceptRole)
            mb.addButton("No", QMessageBox.RejectRole)
            mb.exec()
            if mb.clickedButton() == yes:
                w.open_report(0, "Il programma si è chiuso da solo mentre lo usavo. Stavo facendo: ")
        QTimer.singleShot(2500, ask_crash)
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if args and os.path.exists(args[0]):
        w.open_path(args[0])
    else:
        QTimer.singleShot(200, w.show_projects)
    _quit_now(app.exec())


if __name__ == "__main__":
    main()
