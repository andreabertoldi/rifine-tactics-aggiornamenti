"""Raccolta: pezzi presi da uno o più video (con i loro disegni) da esportare insieme o separati.

Ogni pezzo conserva una copia dell'analisi di quel momento (disegni, giocatori seguiti, calibrazione,
pezzi tolti), così l'esportazione non dipende da cosa è stato salvato dopo.
Il file della raccolta è in Documenti → Analisi Video → raccolta.json.
"""
import json
import os
import subprocess
import tempfile

import cv2
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QFileDialog, QHBoxLayout, QInputDialog, QLabel, QListWidget,
                               QListWidgetItem, QMessageBox, QPushButton, QVBoxLayout)

import export as exp
from model import Project, fmt_time

PATH = os.path.join(os.path.expanduser("~/Documents"), "Analisi Video", "raccolta.json")


def load(path=None):
    try:
        with open(path or PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d.get("clips", [])
    except (OSError, ValueError):
        return []


def save(clips, path=None):
    path = path or PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"clips": clips}, f, ensure_ascii=False)
    os.replace(tmp, path)


def snapshot(project, fps, a, b):
    """Copia dell'analisi limitata al pezzo [a, b] (secondi): disegni e giocatori seguiti che c'entrano."""
    d = project.to_dict()
    ia, ib = int(a * fps) - 2, int(b * fps) + 2
    d["drawings"] = [x for x in d["drawings"] if x["t"] < b + 0.05 and x["t"] + x.get("dur", 0) + x.get("pause", 0) > a - 0.05]
    used = {an.get("id") for x in d["drawings"] for an in (x.get("anchors") or []) if an}
    tracks = {}
    for tid, t in d["tracks"].items():
        if tid in used:
            data = {k: v for k, v in t["data"].items() if ia <= int(k) <= ib}
            tracks[tid] = dict(t, data=data)
    d["tracks"] = tracks
    d["events"] = []
    d["stills"] = [x for x in d.get("stills", []) if a - 0.05 <= x["t"] <= b + 0.05]
    d["pitch_refs"] = {k: v for k, v in (d.get("pitch_refs") or {}).items() if ia - 300 <= int(k) <= ib + 300}
    return d


def clip_label(i, c):
    name = os.path.splitext(os.path.basename(c["video"]))[0]
    t = f"{i + 1}. {fmt_time(c['start'])}–{fmt_time(c['end'])}  ({c['end'] - c['start']:.0f} s)  ·  {name}"
    if c.get("title"):
        t += f"  ·  «{c['title']}»"
    if not os.path.exists(c["video"]):
        t += "  ⚠ video non trovato"
    return t


def _duration(path):
    cap = cv2.VideoCapture(path)
    n, fps = cap.get(cv2.CAP_PROP_FRAME_COUNT), cap.get(cv2.CAP_PROP_FPS) or 25
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    cap.release()
    return (n / fps if n > 0 else 0.0), fps, w, h


def export_clip(c, out, opts, progress=None, cancel=None):
    from video import VideoReader
    p = Project.from_dict(c["project"])
    segs = [{"start": x, "end": y, "caption": c.get("title") or "", "color": "#2ecc71"}
            for x, y in p.kept_segments(c["start"], c["end"])]
    if not segs:
        return None
    rd = VideoReader(c["video"])
    try:
        exp.export_video(rd, segs, out, p, progress=progress, cancel=cancel, **opts)
    finally:
        rd.close()
    return out


def export_all(clips, out_path, opts, progress=None, cancel=None):
    """Tutti i pezzi, nell'ordine, in un unico MP4 (anche da video di misure diverse)."""
    tmpdir = tempfile.mkdtemp(prefix="raccolta_")
    parts = []
    try:
        n = len(clips)
        for k, c in enumerate(clips):
            def pr(frac, msg, k=k):
                if progress:
                    progress((k + frac * 0.9) / n, f"Pezzo {k + 1} di {n}: {msg}")
            o = export_clip(c, os.path.join(tmpdir, f"p{k:03d}.mp4"), opts, pr, cancel)
            if o:
                parts.append(o)
        if not parts:
            return None
        if progress:
            progress(0.95, "Unisco i pezzi…")
        _, fps, W, H = _duration(parts[0])
        W, H = W - W % 2, H - H % 2
        cmd = [exp.ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y"]
        for pth in parts:
            cmd += ["-i", pth]
        flt, cat = [], ""
        for i, pth in enumerate(parts):
            dur, _f, _w, _h = _duration(pth)
            flt.append(f"[{i}:v]scale={W}:{H}:force_original_aspect_ratio=decrease,"
                       f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps:.3f}[v{i}]")
            if exp.has_audio(pth):
                flt.append(f"[{i}:a]aresample=44100,aformat=channel_layouts=stereo[a{i}]")
            else:
                flt.append(f"anullsrc=r=44100:cl=stereo,atrim=duration={max(0.1, dur):.3f}[a{i}]")
            cat += f"[v{i}][a{i}]"
        flt.append(f"{cat}concat=n={len(parts)}:v=1:a=1[v][a]")
        crf = "20" if opts.get("preset") != "wa" else "28"
        cmd += (["-filter_complex", ";".join(flt), "-map", "[v]", "-map", "[a]"] + exp.video_args(crf, W, H, fps)
                + exp.audio_args("128k") + ["-movflags", "+faststart", out_path])
        r = subprocess.run(cmd, capture_output=True)
        if r.returncode != 0:
            raise RuntimeError("ffmpeg ha restituito un errore:\n" + r.stderr.decode("utf-8", "replace")[-1500:])
        if progress:
            progress(1.0, "Fatto")
        return out_path
    finally:
        for fn in os.listdir(tmpdir):
            try:
                os.remove(os.path.join(tmpdir, fn))
            except OSError:
                pass
        try:
            os.rmdir(tmpdir)
        except OSError:
            pass


def safe(s):
    return "".join(ch for ch in s if ch not in '/\\:*?"<>|').strip() or "pezzo"


class RaccoltaDialog(QDialog):
    """Elenco dei pezzi raccolti: ordine, titoli, esportazione."""

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.setWindowTitle("Raccolta di pezzi")
        self.resize(760, 460)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Pezzi raccolti, anche da video diversi. Per aggiungerne: segna «[ Inizio» e «Fine ]» "
                             "e premi «➕ Raccolta». Doppio clic su un pezzo per dargli un titolo."))
        self.list = QListWidget()
        self.list.setSelectionMode(QListWidget.ExtendedSelection)   # ⌘ o ⇧ per sceglierne più di uno
        self.list.itemDoubleClicked.connect(lambda _it: self.rename())
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        for txt, fn in (("▲ Su", lambda: self.move(-1)), ("▼ Giù", lambda: self.move(1)),
                        ("Titolo…", self.rename), ("Vai al pezzo", self.goto), ("Togli", self.remove),
                        ("Svuota", self.clear)):
            b = QPushButton(txt)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch()
        lay.addLayout(row)
        row3 = QHBoxLayout()
        b = QPushButton("📋 Copia in un altro lavoro…")
        b.setToolTip("I pezzi scelti restano qui e compaiono anche nell'altro lavoro.\n"
                     "Per sceglierne più di uno tieni premuto ⌘ (o ⇧ per un gruppo) mentre clicchi.")
        b.clicked.connect(lambda: self.to_other(False))
        row3.addWidget(b)
        b = QPushButton("➡️ Sposta in un altro lavoro…")
        b.setToolTip("I pezzi scelti passano nell'altro lavoro e qui non ci sono più.\n"
                     "Per sceglierne più di uno tieni premuto ⌘ (o ⇧ per un gruppo) mentre clicchi.")
        b.clicked.connect(lambda: self.to_other(True))
        row3.addWidget(b)
        row3.addStretch()
        lay.addLayout(row3)
        row2 = QHBoxLayout()
        b = QPushButton("💾 Esporta tutto in un unico video")
        b.clicked.connect(self.export_one)
        row2.addWidget(b)
        b = QPushButton("💾 Esporta ogni pezzo separato")
        b.clicked.connect(self.export_sep)
        row2.addWidget(b)
        b = QPushButton("💾 Esporta solo questo pezzo")
        b.setToolTip("Esporta solo il pezzo selezionato nell'elenco")
        b.clicked.connect(self.export_single)
        row2.addWidget(b)
        row2.addStretch()
        b = QPushButton("Chiudi")
        b.clicked.connect(self.close)
        row2.addWidget(b)
        lay.addLayout(row2)
        self.refresh()

    def clips(self):
        return load()

    def refresh(self, sel=None):
        cl = self.clips()
        self.list.clear()
        for i, c in enumerate(cl):
            it = QListWidgetItem(clip_label(i, c))
            self.list.addItem(it)
        if cl:
            self.list.setCurrentRow(min(len(cl) - 1, sel if sel is not None else 0))
        if hasattr(self.win, "_refresh_prog"):
            self.win._refresh_prog()

    def _row(self):
        r = self.list.currentRow()
        return r if 0 <= r < self.list.count() else None

    def move(self, d):
        r = self._row()
        cl = self.clips()
        if r is None or not (0 <= r + d < len(cl)):
            return
        cl[r], cl[r + d] = cl[r + d], cl[r]
        save(cl)
        self.refresh(r + d)

    def _sel_rows(self):
        rows = sorted({self.list.row(it) for it in self.list.selectedItems()})
        if not rows and self._row() is not None:
            rows = [self._row()]
        return rows

    def to_other(self, move):
        """Copia o sposta i pezzi scelti nella raccolta di un altro lavoro."""
        import copy
        import progetti
        verbo = "Sposta" if move else "Copia"
        rows = self._sel_rows()
        if not rows:
            QMessageBox.information(self, f"{verbo} in un altro lavoro", "Scegli prima uno o più pezzi nell'elenco.")
            return
        here = os.path.abspath(PATH)
        others = [p for p in progetti.list_projects() if os.path.abspath(p.raccolta_path) != here]
        new_txt = "＋ Nuovo lavoro…"
        n = len(rows)
        cosa = "il pezzo scelto" if n == 1 else f"i {n} pezzi scelti"
        name, ok = QInputDialog.getItem(self, f"{verbo} in un altro lavoro", f"{verbo} {cosa} nel lavoro:",
                                        [p.name for p in others] + [new_txt], 0, False)
        if not ok:
            return
        try:
            if name == new_txt:
                nn, ok = QInputDialog.getText(self, "Nuovo lavoro", "Nome del nuovo lavoro:")
                if not ok or not nn.strip():
                    return
                dst = progetti.Progetto.create(nn.strip())
            else:
                dst = next(p for p in others if p.name == name)
            cl = self.clips()
            picked = [copy.deepcopy(cl[r]) for r in rows]
            save(load(dst.raccolta_path) + picked, dst.raccolta_path)
            if move:
                save([c for i, c in enumerate(cl) if i not in rows])
        except Exception as e:  # noqa
            QMessageBox.warning(self, f"{verbo} in un altro lavoro", f"Non ci sono riuscito:\n{e}")
            return
        if hasattr(self.win, "act"):
            self.win.act(f'{n} pezzi {"spostati" if move else "copiati"} nel lavoro «{dst.name}»')
        self.refresh(rows[0] if not move else max(0, rows[0] - 1))
        fatto = ("spostato" if move else "copiato") if n == 1 else ("spostati" if move else "copiati")
        msg = f"{n} {'pezzo' if n == 1 else 'pezzi'} {fatto} nel lavoro «{dst.name}»."
        missing = [c for c in picked if not os.path.exists(c.get("video", ""))]
        if missing:
            msg += (f"\n\nAttenzione: il video di {len(missing)} di questi pezzi non si trova più sul Mac: "
                    "finché non lo rimetti al suo posto non si possono esportare.")
        else:
            msg += ("\n\nIl pezzo usa sempre il video originale: se lo cancelli o lo togli dal lavoro da cui "
                    "viene, il pezzo non si può più esportare.")
        QMessageBox.information(self, f"{verbo} in un altro lavoro", msg)

    def rename(self):
        r = self._row()
        if r is None:
            return
        cl = self.clips()
        t, ok = QInputDialog.getText(self, "Titolo del pezzo", "Titolo (compare in sovrimpressione se lo scegli "
                                     "all'esportazione):", text=cl[r].get("title", ""))
        if ok:
            cl[r]["title"] = t.strip()
            save(cl)
            self.refresh(r)

    def remove(self):
        r = self._row()
        if r is None:
            return
        cl = self.clips()
        del cl[r]
        save(cl)
        self.refresh(r)

    def clear(self):
        if not self.clips():
            return
        if QMessageBox.question(self, "Svuota", "Togliere tutti i pezzi dalla raccolta? (i video non vengono "
                                "toccati)") == QMessageBox.Yes:
            save([])
            self.refresh()

    def goto(self):
        r = self._row()
        if r is None:
            return
        c = self.clips()[r]
        w = self.win
        if not w.reader or os.path.abspath(w.reader.path) != os.path.abspath(c["video"]):
            if not os.path.exists(c["video"]):
                QMessageBox.warning(self, "Video non trovato", "Il video di questo pezzo è stato spostato o "
                                    "cancellato:\n" + c["video"])
                return
            w.open_path(c["video"])
        if w.reader and os.path.abspath(w.reader.path) == os.path.abspath(c["video"]):
            w.seek_time(c["start"])

    def _check(self):
        cl = self.clips()
        if not cl:
            QMessageBox.information(self, "Raccolta vuota", "Non ci sono pezzi: segna «[ Inizio» e «Fine ]» e "
                                    "premi «➕ Raccolta».")
            return None
        miss = [c for c in cl if not os.path.exists(c["video"])]
        if miss:
            QMessageBox.warning(self, "Video non trovati", "Alcuni video sono stati spostati o cancellati:\n" +
                                "\n".join(c["video"] for c in miss[:5]))
            return None
        return cl

    def _opts(self, title):
        from dialogs import ExportVideoDialog
        dlg = ExportVideoDialog(title, len(self.clips()), self)
        if not dlg.exec():
            return None
        return dlg.options()

    def export_one(self):
        cl = self._check()
        if cl is None:
            return
        opts = self._opts("Esporta la raccolta in un unico video")
        if opts is None:
            return
        default = os.path.join(self.win._export_dir(), "Raccolta.mp4")
        path, _ = QFileDialog.getSaveFileName(self, "Salva video", default, "Video MP4 (*.mp4)")
        if not path:
            return
        if not path.lower().endswith(".mp4"):
            path += ".mp4"

        def work(progress, cancelled):
            return [export_all(cl, path, opts, progress, cancelled)]

        self.win._run_job("Esportazione raccolta", work, self.win._export_done)

    def export_single(self):
        cl = self._check()
        if cl is None:
            return
        r = self._row()
        if r is None:
            QMessageBox.information(self, "Esporta pezzo", "Seleziona prima un pezzo nell'elenco.")
            return
        c = cl[r]
        opts = self._opts("Esporta questo pezzo")
        if opts is None:
            return
        name = f"{r + 1:02d} - " + safe(c.get("title") or
                                         os.path.splitext(os.path.basename(c["video"]))[0] +
                                         f" {fmt_time(c['start']).replace(':', 'm')}") + ".mp4"
        default = os.path.join(self.win._export_dir(), name)
        path, _ = QFileDialog.getSaveFileName(self, "Salva pezzo", default, "Video MP4 (*.mp4)")
        if not path:
            return
        if not path.lower().endswith(".mp4"):
            path += ".mp4"

        def work(progress, cancelled):
            o = export_clip(c, path, opts, progress, cancelled)
            return [o] if o else []

        self.win._run_job("Esportazione pezzo", work, self.win._export_done)

    def export_sep(self):
        cl = self._check()
        if cl is None:
            return
        opts = self._opts("Esporta ogni pezzo separato")
        if opts is None:
            return
        folder = QFileDialog.getExistingDirectory(self, "Cartella dove salvare i pezzi", self.win._export_dir())
        if not folder:
            return

        def work(progress, cancelled):
            out = []
            n = len(cl)
            for k, c in enumerate(cl):
                name = f"{k + 1:02d} - " + safe(c.get("title") or
                                                 os.path.splitext(os.path.basename(c["video"]))[0] +
                                                 f" {fmt_time(c['start']).replace(':', 'm')}") + ".mp4"
                o = export_clip(c, os.path.join(folder, name), opts,
                                lambda f, m, k=k: progress((k + f) / n, f"Pezzo {k + 1} di {n}: {m}"), cancelled)
                if o:
                    out.append(o)
            return out

        self.win._run_job("Esportazione pezzi", work, self.win._export_done)
